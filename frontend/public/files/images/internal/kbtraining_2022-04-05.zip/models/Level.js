'use strict';
const mongoose = require('mongoose');

const { Schema } = mongoose;

const levelSchema = new Schema(
  {
    level: { type: Number, default: 0 },
    coins: { type: Number, default: 0 },
    image: { type: String, default: '' },
    user: { type: Schema.Types.ObjectId, ref: 'User' },
    status: { type: Number, default: 1 },
    completedUsers: [{ type: Schema.Types.ObjectId, ref: 'User' }],
  },
  {
    timestamps: true,
  },
);

module.exports = mongoose.model('Level', levelSchema);

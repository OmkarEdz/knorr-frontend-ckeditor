'use strict';
const bcrypt = require('bcrypt-nodejs');
const mongoose = require('mongoose');

const { Schema } = mongoose;

const userSchema = new Schema(
  {
    userName: { type: String, default: '' },
    email: {
      type: String, lowercase: true, unique: true, trim: true,
    },
    password: { type: String, min: 8 },
    dateOfBirth: {
      date: { type: String, default: 'dd' },
      month: { type: String, default: 'mm' },
      year: { type: String, default: 'yyyy' },
    },
    image: { type: String, default: '' },
    about: { type: String, default: ''},
    telephoneNumber: { type: String, default: null },
    forgotPasswordOtp: { type: Number, default: null },
    language: { type: String, enum: ['en', 'de'], default: 'de' },
    status: { type: Number, default: 1 },
    isVerified: { type: Boolean, default: true},
    isNotificationEnabled: { type: Boolean, default: true},
    fcmToken: { type: String, default: '' },
    loginType: { type: Number, default: 3 },
    location: {
      type: { type: String, default: 'Point' },
      coordinates: { type: [Number], index: '2dsphere', default: [0, 0] },
    },
    onlineStatus: { type: Boolean, default: false},
    totalCoinsEarned: { type: Number, default: 0 },
    currentCoins: { type: Number, default: 0 },
    currentLevel: { type: Number, default: 0 },
    currentLevelImage: { type: String, default: '' },
    drivenKilometers: { type: Number, default: 0.0 },
    coinValue: { type: Number, default: 1 },
    deviceId: { type: String, default: '' },
    system: { type: String, default: '' },
    version: { type: String, default: '' },
    model: { type: String, default: '' },
    homezone: [{
      place: { type: String, default: '' },
      city: { type: String, default: ''},
      state: { type: String, default: ''},
      country: { type: String, default: '' },
      location: {
        type: { type: String, default: 'Point' },
        coordinates: { type: [Number], default: [0, 0] },
      },
      radiusVisibility: { type: Number, default: 0 },
      index: { type: Number },
    }],
    inHomeZone: { type: Boolean, default: false},
    isHomeZoneAdded: { type: Boolean, default: false},
    followers: {
      count: { type: Number, default: 0 },
      users: [{ type: Schema.Types.ObjectId, ref: 'User' }],
    },

    following: {
      count: { type: Number, default: 0 },
      users: [{ type: Schema.Types.ObjectId, ref: 'User' }],
    },

    trackStatus: {
      _id: false,
      status: { type: Boolean, default: false},
      trip: { type: Schema.Types.ObjectId, ref: 'Trips' },
      event: { type: Schema.Types.ObjectId, ref: 'Events' },
      type: { type: String, default: '' },
      startPointCoordinates: { type: [Number], default: [0, 0] },
    },
  },
  {
    timestamps: true,
  },
);

// do not return password
userSchema.set('toJSON', {
  transform(doc, ret, opt) {
    delete ret['password'];
    return ret;
  },
});

// on save hook
userSchema.pre('save', function(next) {
  const user = this;

  if (!this.isModified('password')) {
    console.log('password not modified');
    return next();
  }

  console.log('password modified');
  bcrypt.genSalt(10, (err, salt) => {
    if (err) {
      return next(err);
    }

    bcrypt.hash(user.password, salt, null, (error, hash) => {
      if (error) {
        return next(error);
      }

      user.password = hash;
      next();
    });
  });
  return next();
});

userSchema.methods.comparePassword = function(candidatePassword, callback) {
  bcrypt.compare(candidatePassword, this.password, (err, isMatch) => {
    if (err) {
      return callback(err);
    }

    callback(null, isMatch);
  });
};

module.exports = mongoose.model('User', userSchema);

'use strict';
const mongoose = require('mongoose');
const { Schema } = mongoose;

const autoSchema = new Schema(
  {
    user: { type: Schema.Types.ObjectId, ref: 'User' },
    brand: { type: String, default: '' },
    model: { type: String, default: '' },
    year: { type: String, default: '' },
    vedioLink: { type: String, default: '' },
    description: { type: String, default: '' },
    galleryImages: [
      {
        _id: false,
        url: { type: String, default: '' },
        height: { type: Number, default: 0 },
        width: { type: Number, default: 0 },
      },
    ],
    status: { type: Number, default: 1 },
  },
  {
    timestamps: true,
  },
);

module.exports = mongoose.model('Auto', autoSchema);

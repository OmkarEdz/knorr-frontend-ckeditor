'use strict';
const mongoose = require('mongoose');
const { Schema } = mongoose;

const userBlockedSchema = new Schema(
  {
    user: { type: Schema.Types.ObjectId, ref: 'User' },
    blockedUser: { type: Schema.Types.ObjectId, ref: 'User' },
    isBlocked: { type: Boolean, default: true },
  },
  {
    timestamps: true,
  },
);

module.exports = mongoose.model('UsersBlocked', userBlockedSchema);

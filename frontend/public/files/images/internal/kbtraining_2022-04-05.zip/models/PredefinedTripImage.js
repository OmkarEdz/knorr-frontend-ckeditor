'use strict';
const mongoose = require('mongoose');

const { Schema } = mongoose;

const predefinedTripImageSchema = new Schema(
  {
    image: { type: String, default: '' },
    user: { type: Schema.Types.ObjectId, ref: 'User' },
    status: { type: Number, default: 1 },
  },
  {
    timestamps: true,
  },
);

module.exports = mongoose.model('PredefinedTripImage', predefinedTripImageSchema);

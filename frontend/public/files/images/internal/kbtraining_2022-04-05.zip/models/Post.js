'use strict';
const mongoose = require('mongoose');
const { Schema } = mongoose;

const postSchema = new Schema(
  {
    user: { type: Schema.Types.ObjectId, ref: 'User' },
    description: { type: String, default: '' },
    galleryImages: [
      {
        _id: false,
        url: { type: String, default: '' },
        height: { type: Number, default: 0 },
        width: { type: Number, default: 0 },
      },
    ],
    address: {
      _id: false,
      place: { type: String, default: '' },
      city: { type: String, default: ''},
      state: { type: String, default: ''},
      country: { type: String, default: '' },
      location: {
        type: { type: String, default: 'Point' },
        coordinates: { type: [Number], index: '2dsphere', default: [0, 0] },
      },
    },
    likes: {
      count: { type: Number, default: 0 },
      users: [{ type: Schema.Types.ObjectId, ref: 'User' }],
    },
    status: { type: Number, default: 1 },
  },
  {
    timestamps: true,
  },
);

module.exports = mongoose.model('Post', postSchema);

'use strict';
const mongoose = require('mongoose');

const { Schema } = mongoose;

const rewardHistorySchema = new Schema(
  {
    user: { type: Schema.Types.ObjectId, ref: 'User' },
    reward: { type: Schema.Types.ObjectId, ref: 'Reward' },
    userName: { type: String, default: '' },
    email: { type: String, default: '' },
    address: { type: String, default: '' },
    status: { type: Number, default: 1 },
    rewardSent: { type: Boolean, default: false },
  },
  {
    timestamps: true,
  },
);

module.exports = mongoose.model('RewardHistory', rewardHistorySchema);

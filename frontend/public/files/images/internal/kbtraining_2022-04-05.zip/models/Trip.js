'use strict';
const mongoose = require('mongoose');

const { Schema } = mongoose;

const TripSchema = new Schema(
  {
    category: { type: String, enum: ['1 point', '2 point', 'custom'] },
    title: { type: String, default: '' },
    description: {type: String, default: ''},
    tripDate: { type: Date, default: new Date },
    image: { type: String, default: '' },
    user: { type: Schema.Types.ObjectId, ref: 'User' },
    startPointAddress: {
      _id: false,
      place: { type: String, default: '' },
      city: { type: String, default: ''},
      state: { type: String, default: ''},
      country: { type: String, default: '' },
      location: {
        type: { type: String, default: 'Point' },
        coordinates: { type: [Number], index: '2dsphere', default: [0, 0] },
      },
    },
    endPointAddress: {
      _id: false,
      place: { type: String, default: '' },
      city: { type: String, default: ''},
      state: { type: String, default: ''},
      country: { type: String, default: '' },
      location: {
        type: { type: String, default: 'Point' },
        coordinates: { type: [Number], default: [0, 0] },
      },
    },
    totalTripDistance: { type: Number, default: 0},
    stopOvers: [
      {
        _id: false,
        place: { type: String, default: '' },
        location: {
          type: { type: String, default: 'Point' },
          coordinates: { type: [Number], default: [0, 0] },
        },
      },
    ],
    tripStatus: { type: Number, default: 1 },
    maxParticipants: {type: Number, default: 0 },

    participants: {
      count: { type: Number, default: 0 },
      users: [{ type: Schema.Types.ObjectId, ref: 'User' }],
    },

    ongoingUsers: {
      count: { type: Number, default: 0 },
      users: [{ type: Schema.Types.ObjectId, ref: 'User' }],
    },

    completedUsers: {
      count: { type: Number, default: 0 },
      users: [{ type: Schema.Types.ObjectId, ref: 'User' }],
    },
  },
  {
    timestamps: true,
  },
);


module.exports = mongoose.model('Trips', TripSchema);

'use strict';
const mongoose = require('mongoose');

const { Schema } = mongoose;

const rewardSchema = new Schema(
  {
    title: { type: String, default: '' },
    image: { type: String, default: '' },
    coins: { type: Number, default: 0 },
    quantity: { type: Number },
    type: { type: String, enum: ['address', 'email'] },
    category: { type: String, default: '' },
    redeemedUsers: [{ type: Schema.Types.ObjectId, ref: 'User' }],
    user: { type: Schema.Types.ObjectId, ref: 'User' },
    status: { type: Number, default: 1 },
  },
  {
    timestamps: true,
  },
);

module.exports = mongoose.model('Reward', rewardSchema);

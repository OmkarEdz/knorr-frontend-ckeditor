'use strict';
const mongoose = require('mongoose');
const { Schema } = mongoose;

const carManufacturer = new Schema(
  {
    make: { type: String, default: '' },
    model: { type: String, default: '' },
    models: [
      {
        _id: false,
        name: { type: String, default: '' },
      },
    ],
  },
  {
    timestamps: true,
  },
);

module.exports = mongoose.model('CarManufacturer', carManufacturer);

'use strict';
const mongoose = require('mongoose');

const { Schema } = mongoose;

const presetTripSchema = new Schema(
  {
    title: { type: String, default: '' },
    image: { type: String, default: '' },
    user: { type: Schema.Types.ObjectId, ref: 'User' },
    status: { type: Number, default: 1 },
  },
  {
    timestamps: true,
  },
);

module.exports = mongoose.model('PresetTrip', presetTripSchema);

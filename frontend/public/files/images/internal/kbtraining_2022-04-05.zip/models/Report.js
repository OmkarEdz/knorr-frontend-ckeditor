'use strict';
const mongoose = require('mongoose');
const { Schema } = mongoose;

const reportSchema = new Schema(
  {
    user: { type: Schema.Types.ObjectId, ref: 'User' },
    type: { type: String, enum: ['user', 'post', 'trip'] },
    reportedUser: { type: Schema.Types.ObjectId, ref: 'User' },
    reportedPost: { type: Schema.Types.ObjectId, ref: 'Post' },
    reportedTrip: { type: Schema.Types.ObjectId, ref: 'Trip' },
    status: { type: Boolean, default: 1 },
    reason: { type: String, default: '' },
  },
  {
    timestamps: true,
  },
);

module.exports = mongoose.model('Report', reportSchema);

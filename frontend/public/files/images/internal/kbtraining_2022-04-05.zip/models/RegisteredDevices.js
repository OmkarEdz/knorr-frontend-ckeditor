'use strict';
const mongoose = require('mongoose');
const { Schema } = mongoose;

const registeredDevices = new Schema(
  {
    deviceId: { type: String, default: '' },
  },
  {
    timestamps: true,
  },
);

module.exports = mongoose.model('RegisteredDevices', registeredDevices);

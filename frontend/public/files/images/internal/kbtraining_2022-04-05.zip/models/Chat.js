'use strict';
/* eslint-disable func-names */
const mongoose = require('mongoose');

const { Schema } = mongoose;

const ChatSchema = new Schema(
  {
    chatId: { type: String, default: '' },
    senderId: { type: Schema.Types.ObjectId, ref: 'User' },
    receiverId: { type: Schema.Types.ObjectId, ref: 'User' },
    message: { type: String, default: '' },
    deletedBy: { type: String, default: '' },
    isSharedPost: { type: Boolean, default: false },
    post: { type: Schema.Types.ObjectId, ref: 'Post' },
  },
  {
    timestamps: true,
  },
);


module.exports = mongoose.model('Chat', ChatSchema);

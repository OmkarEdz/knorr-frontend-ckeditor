
'use strict';
const mongoose = require('mongoose');
const { Schema } = mongoose;

const notificationSchema = new Schema(
  {
    type: { type: String, enum: ['chat', 'follow', 'trip', 'comment'] },
    userName: {type: String},
    fromUser: { type: Schema.Types.ObjectId, ref: 'User' },
    toUser: { type: Schema.Types.ObjectId, ref: 'User' },
    action: { type: Schema.Types.ObjectId },
    content: { type: String },
    newNotification: { type: Boolean, default: true },
    status: { type: Number, default: 1 },
  },
  {
    timestamps: true,
  },
);

module.exports = mongoose.model('Notification', notificationSchema);

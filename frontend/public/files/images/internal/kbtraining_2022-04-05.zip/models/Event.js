'use strict';
const mongoose = require('mongoose');

const { Schema } = mongoose;

const EventSchema = new Schema(
  {
    title: { type: String, default: '' },
    description: {type: String, default: ''},
    eventDate: { type: Date, default: new Date },
    image: { type: String, default: '' },
    user: { type: Schema.Types.ObjectId, ref: 'User' },
    eventAddress: {
      _id: false,
      place: { type: String, default: '' },
      city: { type: String, default: ''},
      state: { type: String, default: ''},
      country: { type: String, default: '' },
      location: {
        type: { type: String, default: 'Point' },
        coordinates: { type: [Number], index: '2dsphere', default: [0, 0] },
      },
    },
    status: { type: Number, default: 1 },
    participants: {
      count: { type: Number, default: 0 },
      users: [{ type: Schema.Types.ObjectId, ref: 'User' }],
    },

    ongoingUsers: {
      count: { type: Number, default: 0 },
      users: [{ type: Schema.Types.ObjectId, ref: 'User' }],
    },

    completedUsers: {
      count: { type: Number, default: 0 },
      users: [{ type: Schema.Types.ObjectId, ref: 'User' }],
    },
  },
  {
    timestamps: true,
  },
);

module.exports = mongoose.model('Events', EventSchema);

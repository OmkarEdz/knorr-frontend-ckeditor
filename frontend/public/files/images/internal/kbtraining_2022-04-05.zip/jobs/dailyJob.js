'use strict';
// core modules
const schedule = require('node-schedule');
const Chat = require('../models/Chat');
const User = require('../models/User');
const AWS = require('aws-sdk');
const trans = require('../helpers/constants');
const { sendPushNotification } = require('../helpers/notification');
const {
  convertLocaleMessage,
} = require('../helpers/utils');

const s3bucket = new AWS.S3({
  signatureVersion: 'v4',
  accessKeyId: process.env.AWS_ACCESS_KEY_ID,
  secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  region: 'eu-central-1',
});

const saveDeletedFileMessage = async(messageId, senderId, objectUrl) => {
  const senderLanguage = await User.findOne({_id: senderId}).select('language');
  const newMessage = convertLocaleMessage(senderLanguage, trans.chat.FILE_DELETED);
  await Chat.updateOne({ _id: messageId }, {
    $set: { message: newMessage },
  });
  console.log('File ' + objectUrl + ' deleted');
};

const deleteChatImages = async() => {
  var dateToCheck = new Date();
  dateToCheck.setHours(-96);

  const chatMessages = await Chat.find({ message: { $regex: '(ETS-IMAGE)|(ETS-VIDEO)' }, createdAt: { $lt: dateToCheck } });
  if (chatMessages.length === 0){
    console.log('No Files to delete');
  } else {
    console.log('Trying to delete ' + chatMessages.length + ' Files');
  }
  for (var i = 0; i < chatMessages.length; i++) {
    const message = chatMessages[i].message;
    const messageId = chatMessages[i]._id;
    const senderId = chatMessages[i].senderId;
    const objectUrl = message.replace('ETS-IMAGE=', '').replace('ETS-VIDEO=', '');
    const params = {
      Bucket: process.env.AWS_BUCKET,
      Key: 'street/' + objectUrl,
    };
    s3bucket.deleteObject(params, function(error, data){
      if (error){
        console.error(error);
      } else {
        // Successful Delete of File on AWS, now save to Database
        saveDeletedFileMessage(messageId, senderId, objectUrl);
      }
    });
  }
};

const sendNotificationToUsers = async(admin, users, message) => {
  for (let i = 0; i < users.length; i++){
    const otherUserDetails = users[i];
    const language = otherUserDetails.language;
    const details = {
      token: otherUserDetails.fcmToken,
      body: {
        userName: 'Admin',
        type: 'follow',
        fromUser: admin._id,
        toUser: otherUserDetails._id,
        action: null,
        content: convertLocaleMessage(language, message),
      },
    };
    if (otherUserDetails.isNotificationEnabled){
      await sendPushNotification(details);
      console.log('Anonymous User with ID ' + otherUserDetails._id + ' has been notified.');
    }
  }
};

const deleteOrNotifyAnonymousUsers = async() => {
  var fourteenDaysAgo = new Date(); // Delete User
  fourteenDaysAgo.setDays(-14);

  var thirteenDaysAgo = new Date(); // Notify User
  thirteenDaysAgo.setDays(-12);

  var twelveDaysAgo = new Date(); // Notify User
  twelveDaysAgo.setDays(-12);

  var sevenDaysAgo = new Date(); // Notify User
  sevenDaysAgo.setDays(-7);

  // Get Admin User
  const admin = await User.find({userName: 'admin' }, '_id fcmToken userName language');

  const usersToNotifySevenDays = await User.find({ userName: 'anonymous', createdAt: { $lt: sevenDaysAgo } }, '_id fcmToken userName language');
  const usersToNotifyThirteenDays = await User.find({ userName: 'anonymous', createdAt: { $lt: thirteenDaysAgo } }, '_id fcmToken userName language');
  const usersToNotifyTwelveDays = await User.find({ userName: 'anonymous', createdAt: { $lt: twelveDaysAgo } }, '_id fcmToken userName language');
  const usersToDelete = await User.find({ userName: 'anonymous', createdAt: { $lt: fourteenDaysAgo } }, '_id fcmToken userName language');

  var allUsersToNotifySoon = [];
  // Push all Users from One Array
  if (usersToNotifySevenDays !== undefined){
    for (let i = 0; i < usersToNotifySevenDays.length; i++){
      const userToNotify = usersToNotifySevenDays[i];
      allUsersToNotifySoon.push(userToNotify);
    }
  }

  // Push Users from second Array and check if already added
  if (usersToNotifyTwelveDays !== undefined){
    for (let i = 0; i < usersToNotifyTwelveDays.length; i++){
      const userToNotify = usersToNotifyTwelveDays[i];
      let found = false;
      for (let p = 0; p < allUsersToNotifySoon.length; p++) {
        const user = allUsersToNotifySoon[p];
        if (user._id === userToNotify._id){
          found = true;
          break;
        }
      }
      if (found) continue;
      allUsersToNotifySoon.push(userToNotify);
    }
  }

  sendNotificationToUsers(admin, allUsersToNotifySoon, trans.global.ANONYMOUS_USER_EXPIRES_SOON);

  // Der folgende Code soll erst 2 Tage nach Veröffentlichung aktiviert werden, damit die anonymen User eine Chance haben zu reagieren.
  // if (usersToNotifyThirteenDays !== undefined){
  //   sendNotificationToUsers(admin, usersToNotifyTwelveDays, trans.global.ANONYMOUS_USER_EXPIRES_TOMORROW);
  // }
  // if (usersToDelete !== undefined){
  //   for (let i = 0; i < usersToDelete.length; i++) {
  //     const userToDelete = usersToDelete[i];
  //     const id = userToDelete._id;
  //     await User.deleteOne({ _id: id });
  //     console.log('Anonymous User with ID ' + id + ' has been deleted.');
  //   }
  // }
};

// Task which is executed daily
const executeTask = async() => {
  deleteChatImages();
  deleteOrNotifyAnonymousUsers();
};

exports.start = () => {
  schedule.scheduleJob('* * */24 * * *', function(){
    executeTask();
  });
  return true;
};


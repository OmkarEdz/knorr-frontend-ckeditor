'use strict';
// models
const User = require('../models/User');
const { updateOnlineStatus, updateHomeZoneStatusAndLocation, getAllOnlineUsers, allChatList, updateTypingStatus, getChatAndNotificationCount, followUser, allTripsOnMap, getUserDetails, ongoingTrackingDetail, getTripParticipantCount } = require('../controllers/v1/socketController');
const { newMessage, newSharedPostMessage } = require('../controllers/v1/chatController');
const { saveDrivenKilometers } = require('../controllers/v1/userController');

module.exports = function(io, Global, _) {
  const clients = new Global();

  const userLocationRequestsMap = {};

  io.on('connection', (socket) => {
    const userUniqId = socket.handshake.query.userId;
    const userUniqUsername = socket.handshake.query.userName;
    const userGlobRoom = socket.handshake.query.userId;
    if (userUniqId !== undefined && userUniqId !== null && userUniqId !== 'NaN' && userUniqId !== 'null') {
      console.log('socketid:', socket.id, userGlobRoom, userUniqId, userUniqUsername);
      clients.checkSocketIdOfUser(socket.id, userUniqId, userGlobRoom);
    }

    socket.on('globalRoom', (global) => {
      const { userId, latitude, longitude, filter } = global;

      const room = userId;
      socket.join(room);

      clients.EnterRoom(socket.id, userId, room);

      const userDetail = { userId, latitude, longitude, filter };

      clients.UpdateUserLatLng(userDetail);

      const nameProp = clients.GetRoomList(room);
      const arr = _.uniqBy(nameProp, 'userId');

      socket.emit('loggedInUser', arr);
    });

    socket.on('requestLocation', async(data) => {
      const { userId, latitude, longitude, filter, maxDistance, drivenKilometers } = data;
      console.log('requestLocation', data);
      const room = userId;

      clients.EnterRoom(socket.id, userId, room);

      // Add driven Distance to user
      if (drivenKilometers && drivenKilometers < 0.5){
        await saveDrivenKilometers(userId, drivenKilometers);
      }

      const userDetail = { userId, latitude, longitude, filter, maxDistance };

      await updateOnlineStatus(userId, true);
      await updateHomeZoneStatusAndLocation(userDetail);
      await clients.UpdateUserLatLng(userDetail);

      const getAllUserLatLngList = await clients.getAllUserLatLng();

      // TODO Hier Anpassung wegen Performance Issue#120

      // getAllUsers kriegt Erweiterung um UserID und jeder Client hat eine Socket-Anlaufstelle getAllUsers#<UserID>
      // Die Liste getAllOnlineUsers(userDetail) wird nach Entfernung sortiert
      // Bei mehr als x Nutzern in der Liste wird nach y Einträgen abgebrochen
      // Bei mehr als 20km Distanz wird abgebrochen

      // Issue#120 Count Requests for each User
      if (userLocationRequestsMap[userId] === undefined){
        userLocationRequestsMap[userId] = 1;
      } else {
        userLocationRequestsMap[userId]++;
      }

      console.log('User ' + userId + ' ' + userLocationRequestsMap[userId]);

      // Issue#120 First Part: Only return all User Positions every 10th request
      const getAllUserDetails = await getAllOnlineUsers(userDetail);
      const moduloValue = getAllUserDetails.length < 500 ? 10 : (getAllUserDetails.length + 500) / 100;

      if ((userLocationRequestsMap[userId] - 1) % moduloValue === 0) {
        socket.emit('getAllUsers', getAllUserDetails);
        console.log('Sent getAllUsers back to Client');
      }

      // Issue#120 Second Part: Update Position for near Users
      const nearUsersRequest = {
        userId: userDetail.userId,
        latitude: userDetail.latitude,
        longitude: userDetail.longitude,
        filter: 4, // All Users
        maxDistance: 20,
      };
      const nearUsers = await getAllOnlineUsers(nearUsersRequest, undefined);
      console.log('Near Users: ' + nearUsers.length);
      for (let i = 0; i < nearUsers.length; i++){
        if (i > 100) break;
        const nearUser = nearUsers[i];
        const userLatLngLst = getAllUserLatLngList.filter(u => u.userId === nearUser.userId);
        if (userLatLngLst.length === 0) continue; // User not active
        const userLatLng = userLatLngLst[0];


        const userDetail1 = {
          userId: userLatLng.userId,
          latitude: userLatLng.latitude,
          longitude: userLatLng.longitude,
          filter: userLatLng.filter,
          maxDistance: userLatLng.maxDistance,
        };
        const getAllOtherUserDetails = await getAllOnlineUsers(userDetail1);
        const userSockets = clients.GetUserSocketId(userLatLng.userId);
        if (userSockets) {
          socket.to(userSockets.id).emit('getAllUsers', getAllOtherUserDetails);
        }
      }

      // Code für alle anderen Nutzer
      // --> Diese Anfrage interessiert die anderen nur im Umkreis von 20km
      // Der folgende Code macht eigentlich keinen Sinn, da jeder Client auch einfach selber anfragen kann. Ein Auslösen dessen ist nicht notwendig!
      // for (let userCount = 0; userCount < getAllUserLatLngList.length; userCount++) {
      //   if (getAllUserLatLngList[userCount].userId === userId) continue;
      //   if (userCount > 100) break;

      //   const userDetail1 = {
      //     userId: getAllUserLatLngList[userCount].userId,
      //     latitude: getAllUserLatLngList[userCount].latitude,
      //     longitude: getAllUserLatLngList[userCount].longitude,
      //     filter: getAllUserLatLngList[userCount].filter,
      //     maxDistance: 20,
      //   };
      //   const getAllOtherUserDetails = await getAllOnlineUsers(userDetail1);
      //   const userSockets = clients.GetUserSocketId(getAllUserLatLngList[userCount].userId);
      //   if (userSockets) {
      //     socket.to(userSockets.id).emit('getAllUsers', getAllOtherUserDetails);
      //   }
      // }
    });

    socket.on('requestTripsOnMap', async(data) => {
      console.log('requestTripsOnMap', data);
      let getAllTripsOnMapDetails = await allTripsOnMap(data);
      socket.emit('getAllTripsOnMap', getAllTripsOnMapDetails);
    });

    socket.on('followUser', async(data) => {
      const { otherUserId } = data;
      await followUser(data);
      const getChatAndNotificationCountDetails = await getChatAndNotificationCount(otherUserId);
      const userSocketsData = clients.GetUserSocketId(otherUserId);
      if (userSocketsData) {
        socket.to(userSocketsData.id).emit('getChatAndNotificationCount', getChatAndNotificationCountDetails);
      }
    });

    socket.on('requestChatAndNotificationCount', async(data) => {
      const { userId } = data;
      const getChatAndNotificationCountDetails = await getChatAndNotificationCount(userId);
      socket.emit('getChatAndNotificationCount', getChatAndNotificationCountDetails);
    });


    // User online status
    socket.on('onlineStatus', async function(data) {
      const { userId, status } = data;
      const room = userId;

      await updateOnlineStatus(userId, status);

      if (status === true) {
        socket.join(room);
        clients.EnterRoom(socket.id, userId, room);

        const myChats = await allChatList(userId);

        for (let chat = 0; chat < myChats.length; chat++) {
          if (String(myChats[chat].user._id) !== String(userId)) {
            const userSockets = clients.GetUserSocketId(String(myChats[chat].user._id));
            if (userSockets) {
              let chatData = await allChatList(userSockets.userId);
              socket.to(userSockets.id).emit('chatList', chatData);
            }
          } else {
            const userSockets = clients.GetUserSocketId(String(myChats[chat].matchedUser._id));
            if (userSockets) {
              let chatData = await allChatList(userSockets.userId);
              socket.to(userSockets.id).emit('chatList', chatData);
            }
          }
        }
      }
      if (status === false) {
        socket.leave(room);
        const user = await clients.RemoveUser(socket.id, userId);

        if (user) {
          const getAllUserLatLngList = await clients.getAllUserLatLng();

          for (let userCount = 0; userCount < getAllUserLatLngList.length; userCount++) {
            if (getAllUserLatLngList[userCount].userId !== userId) {
              const userDetail1 = {
                userId: getAllUserLatLngList[userCount].userId,
                latitude: getAllUserLatLngList[userCount].latitude,
                longitude: getAllUserLatLngList[userCount].longitude,
                filter: getAllUserLatLngList[userCount].filter,
                maxDistance: getAllUserLatLngList[userCount].maxDistance,
              };
              const getAllOtherUserDetails = await getAllOnlineUsers(userDetail1);
              const userSockets = clients.GetUserSocketId(getAllUserLatLngList[userCount].userId);
              if (userSockets) {
                socket.to(userSockets.id).emit('getAllUsers', getAllOtherUserDetails);
              }
            }
          }

          const myChats = await allChatList(userId);

          for (let chat = 0; chat < myChats.length; chat++) {
            if (String(myChats[chat].user._id) !== String(userId)) {
              const userSockets = clients.GetUserSocketId(String(myChats[chat].user._id));
              if (userSockets) {
                let chatData = await allChatList(userSockets.userId);
                socket.to(userSockets.id).emit('chatList', chatData);
              }
            } else {
              const userSockets = clients.GetUserSocketId(String(myChats[chat].matchedUser._id));
              if (userSockets) {
                let chatData = await allChatList(userSockets.userId);
                socket.to(userSockets.id).emit('chatList', chatData);
              }
            }
          }

          const getTrackDetail = await User.findById(userId).select('trackStatus');
          if (getTrackDetail.trackStatus.status) {
            let getTrackRoomList = null;
            let trackDetail = null;
            if (getTrackDetail.trackStatus.type === 'trip'){
              getTrackRoomList = await clients.GetTrackRoomList(getTrackDetail.trackStatus.trip);
              trackDetail = await ongoingTrackingDetail(getTrackDetail.trackStatus.type, getTrackDetail.trackStatus.trip);
            }
            if (getTrackDetail.trackStatus.type === 'event'){
              getTrackRoomList = await clients.GetTrackRoomList(getTrackDetail.trackStatus.event);
              trackDetail = await ongoingTrackingDetail(getTrackDetail.trackStatus.type, getTrackDetail.trackStatus.event);
            }
            const activeParticipants = getTrackRoomList.users;

            for (let userCount = 0; userCount < activeParticipants.length; userCount++) {
              if (activeParticipants[userCount] !== userId) {
                const getAllOtherUserDetails = await getUserDetails(activeParticipants[userCount], activeParticipants);
                const userSockets = clients.GetUserSocketId(activeParticipants[userCount]);
                if (userSockets) {
                  socket.to(userSockets.id).emit('getAlltripUsers', { trackDetail, getAllOtherUserDetails });
                }
              }
            }
          }
        }
      }
    });

    socket.on('privateMessage', async(data) => {

      const { senderId, receiverId } = data;

      const messageDetails = await newMessage(data);

      const userChatData = await allChatList(senderId);
      const otherUserChatData = await allChatList(receiverId);

      const getChatAndNotificationCountDetails = await getChatAndNotificationCount(receiverId);

      const receiverSockets = clients.GetUserSocketId(receiverId);
      if (receiverSockets) {
        socket.to(receiverSockets.id).emit('newMessage', messageDetails);
        socket.to(receiverSockets.id).emit('chatList', otherUserChatData);
        socket.to(receiverSockets.id).emit('getChatAndNotificationCount', getChatAndNotificationCountDetails);
      }

      const senderSockets = clients.GetUserSocketId(senderId);
      console.log('senderSockets', senderSockets);
      if (senderSockets) {
        socket.emit('chatList', userChatData);
        socket.emit('newMessage', messageDetails);
      }
    });

    socket.on('sharePost', async(data) => {

      const { senderId, receiverId } = data;

      const messageDetails = await newSharedPostMessage(data);

      const userChatData = await allChatList(senderId);
      const otherUserChatData = await allChatList(receiverId);

      const getChatAndNotificationCountDetails = await getChatAndNotificationCount(receiverId);

      const receiverSockets = clients.GetUserSocketId(receiverId);
      console.log('receiverSockets', receiverSockets);
      if (receiverSockets) {
        socket.to(receiverSockets.id).emit('newMessage', messageDetails);
        socket.to(receiverSockets.id).emit('chatList', otherUserChatData);
        socket.to(receiverSockets.id).emit('getChatAndNotificationCount', getChatAndNotificationCountDetails);
      }

      const senderSockets = clients.GetUserSocketId(senderId);
      if (senderSockets) {
        socket.to(senderSockets.room).emit('chatList', userChatData);
        socket.to(senderSockets.room).emit('newMessage', messageDetails);
      }
    });

    socket.on('typing', async(data) => {
      const { chatId, receiverId, isTyping } = data;

      await updateTypingStatus(chatId, receiverId, isTyping);

      const otherUserChatData = await allChatList(receiverId);
      const receiverSockets = clients.GetUserSocketId(receiverId);

      if (receiverSockets) {
        socket.to(receiverSockets.id).emit('chatList', otherUserChatData);
      }
    });

    socket.on('requestChatList', async(data) => {
      const { userId } = data;
      const chatData = await allChatList(userId);
      socket.emit('chatList', chatData);
    });

    socket.on('requestTripParticipantCount', async(data) => {
      const { tripId } = data;
      const participantCount = await getTripParticipantCount(tripId);
      io.sockets.emit('tripParticipantCount', {participantCount, tripId});
    });

    socket.on('liveTrack', async(data) => {
      console.log('liveTrack', data);
      const { userId, latitude, longitude, type, trackId, drivenKilometers } = data;

      socket.emit('requestLocation', data);

      // Add driven Distance to user
      if (drivenKilometers && drivenKilometers < 0.5){
        await saveDrivenKilometers(userId, drivenKilometers);
      }

      const userDetail = { userId, latitude, longitude, type, trackId };

      await updateHomeZoneStatusAndLocation(userDetail);
      await clients.EnterTrackRoom(userDetail);

      const getTrackRoomList = await clients.GetTrackRoomList(trackId);
      const activeParticipants = getTrackRoomList.users;

      const getUserDetail = await getUserDetails(userId, activeParticipants);
      const trackDetail = await ongoingTrackingDetail(type, trackId);

      socket.emit('getAlltripUsers', { trackDetail, getUserDetail });

      for (let userCount = 0; userCount < activeParticipants.length; userCount++) {
        if (activeParticipants[userCount] !== userId) {
          const getAllOtherUserDetails = await getUserDetails(activeParticipants[userCount], activeParticipants);
          const userSockets = clients.GetUserSocketId(activeParticipants[userCount]);
          if (userSockets) {
            socket.to(userSockets.id).emit('getAlltripUsers', { trackDetail, getAllOtherUserDetails });
          }
        }
      }
    });

    socket.on('blockUser', async(data) => {
      const { userId, blockstatus } = data;

      const receiverSockets = clients.GetUserSocketId(userId);

      if (receiverSockets) {
        socket.to(receiverSockets.id).emit('blockUserSuccess', {userId, blockstatus});
      }
    });

    socket.on('disconnect', async() => {
      console.log('disconnected socketid:', socket.id, socket.handshake.query.room, socket.handshake.query.userId, socket.handshake.query.userName);
      const userId = socket.handshake.query.userId;
      if (userId !== undefined && userId !== null && userId !== 'NaN' && userId !== 'null') {
        await updateOnlineStatus(userId, false);
        clients.RemoveUser(socket.id, userId);
      }
    });
  });
};

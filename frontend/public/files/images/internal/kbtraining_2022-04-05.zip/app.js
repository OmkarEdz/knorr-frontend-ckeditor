'use strict';
require('dotenv').config();
// node modules
const http = require('http');
const _ = require('lodash');
// npm modules
const chalk = require('chalk');
const cors = require('cors');
const morgan = require('morgan');
const helmet = require('helmet');
const express = require('express');
// app modules
const winston = require('./config/winston');
const mongoose = require('./database/mongoose');
const { urlNotFound } = require('./helpers/response');
const { requireApiKey } = require('./middlewares/apiRequest');
// helpers
const socketIO = require('socket.io');
const { Global } = require('./helpers/Global');
const dailyJob = require('./jobs/dailyJob');

// express instance
const app = express();

// cors options
const corsOptions = {
  origin: '*',
  exposedHeaders: 'Content-Type, X-Auth-Token',
  methods: 'GET, HEAD, PUT, PATCH, POST, DELETE',
  preflightContinue: false,
};

// Database setup
mongoose.connect();

// middlewares
app.use(helmet());
app.use(morgan('combined', { stream: winston.stream }));
app.use(cors(corsOptions));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use('/logs', express.static('logs'));
app.use('/uploads', express.static('uploads'));

app.get('/', (req, res, next) => {
  res.send('Greetings From Street Test Server.');
});

// routes
app.use('/api/v1', requireApiKey, require('./routes/V1'));

// error handler
app.use((req, res, next) => {
  return next(urlNotFound());
});

app.use((err, req, res, next) => {
  const error = err;
  const status = err.status || 500;

  res.status(status).json({
    success: false,
    message: error.message ? error.message : err,
  });

  console.log(chalk.red('Error:', err));
});

// server setup
const port = process.env.PORT || 4000;
const server = http.createServer(app);
const io = socketIO(server);
server.listen(port, (err) => {
  if (err) {
    console.log(chalk.red(`Error : ${err}`));
    process.exit(-1);
  }
  console.log(chalk.blue(`${process.env.APP} is running on ${port}`));
});
require('./socket/globalroom')(io, Global, _);

dailyJob.start();

module.exports = app;


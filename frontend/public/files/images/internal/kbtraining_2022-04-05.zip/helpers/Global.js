'use strict';
const mongoose = require('mongoose');
const { ObjectId } = mongoose.Types;
class Global {
  constructor() {
    this.globalRoom = [];
    this.activeUsers = [];
    this.liveUsers = [];
  }

  checkSocketIdOfUser(socketId, userId, room) {
    console.log('check socket hit', this.globalRoom);
    const roomDetail = { id: socketId, userId, room };

    const checkSocket = this.globalRoom.map(function(item) {
      return item.userId;
    }).indexOf(userId);
    if (checkSocket !== -1) {
      console.log('inside replace', this.globalRoom[checkSocket].id, socketId);
      if (this.globalRoom[checkSocket].id !== socketId) {
        console.log('socketId replaced');
        this.globalRoom[checkSocket].id = socketId;
      }
    } else {
      console.log('user pushed to room');
      this.globalRoom.push(roomDetail);
    }

    return checkSocket;
  }

  EnterRoom(id, userId, room) {
    var roomDetail = { id, userId, room };

    var checkSocket = this.globalRoom.map(function(item) {
      return item.userId;
    }).indexOf(userId);
    if (checkSocket === -1) {
      this.globalRoom.push(roomDetail);
    }
    return roomDetail;
  }

  RemoveUser(id, userId) {
    let temp = [];
    var userDetail = this.GetUser(id);
    if (userDetail) {
      temp = this.globalRoom.filter((user) => user.id !== id);
      var removeIndex = this.globalRoom.map(function(item) {
        return item.userId;
      }).indexOf(userId);
      if (removeIndex !== -1) {
        this.globalRoom.splice(removeIndex, 1);
      }

      var removeIndex1 = this.activeUsers.map(function(item) {
        return item.userId;
      }).indexOf(userId);
      if (removeIndex1 !== -1) {
        this.activeUsers.splice(removeIndex1, 1);
      }

      var removeIndex2 = this.liveUsers.map(function(item) {
        return item.userId;
      }).indexOf(userId);
      if (removeIndex2 !== -1) {
        this.liveUsers.splice(removeIndex2, 1);
      }
    }
    return temp;
  }

  GetUser(id) {
    return this.globalRoom.filter((user) => {
      return user.id === id;
    })[0];
  }

  GetUserSocketId(userId) {
    return this.globalRoom.filter((room) => {
      return room.userId === userId;
    })[0];
  }

  GetRoomList(room) {
    return this.globalRoom.filter((user) => user.room === room);
  }

  UpdateUserLatLng(details) {
    const { userId } = details;
    if (!this.activeUsers.find(o => o.userId === userId)) {
      this.activeUsers.push(details);
    } else {
      this.activeUsers.forEach((obj, i) => {
        if (userId === obj.userId) {
          this.activeUsers[i] = details;
        }
      });
    }
    return this.activeUsers;
  }

  getAllUserLatLng() {
    return this.activeUsers;
  }

  EnterTrackRoom(details) {
    const { userId } = details;

    if (!this.liveUsers.find(o => o.userId === userId)) {
      this.liveUsers.push(details);
    } else {
      this.liveUsers.forEach((obj, i) => {
        if (userId === obj.userId) {
          this.liveUsers[i] = details;
        }
        return obj;
      });
    }
    return this.liveUsers;
  }

  GetTrackRoomList(trackId) {
    var liveUsers = this.liveUsers.filter((track) => track.trackId === trackId);
    const users = [];
    liveUsers.forEach(user => {
      users.push(ObjectId(user.userId));
      return user;
    });
    return { liveUsers, users };
  }
}

module.exports = { Global };

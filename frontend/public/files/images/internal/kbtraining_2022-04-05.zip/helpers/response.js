'use strict';
const generalLogger = require('../config/winston');

module.exports = {
  respondSuccess: (res, message, data) => {
    if (!data) {
      return res.status(200).json({
        success: true,
        message: !message ? 'query was successfull' : message,
      });
    }
    generalLogger.log('info', `message ${message}`);
    return res.status(200).json({
      success: true,
      message: !message ? 'query was successfull' : message,
      data,
    });
  },

  respondFailure: (res, message) => {
    generalLogger.log('info', `message ${message}`);
    res.status(200).json({
      success: false,
      message: !message ? 'something went wrong' : message,
    });
  },

  respondError: (status, message) => {
    const error = new Error(`message ${message}`);
    error.status = status;
    generalLogger.log('error', message);
    return error;
  },

  urlNotFound: (res, data) => {
    generalLogger.log('warn', 'url not found, please check the documentation');
    const error = new Error('url not found, please check the documentation');
    error.status = 404;

    return error;
  },
};

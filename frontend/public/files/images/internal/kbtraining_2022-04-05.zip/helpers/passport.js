'use strict';
const passport = require('passport');
const JwtStrategy = require('passport-jwt').Strategy;
const { ExtractJwt } = require('passport-jwt');
const LocalStrategy = require('passport-local');
// models
const User = require('../models/User');

// helpers
const { convertLocaleMessage } = require('./utils');
const trans = require('./constants');

// Create local strategy
const localOptions = { usernameField: 'email', passReqToCallback: true };
const localLogin = new LocalStrategy(localOptions, (req, email, password, done) => {
  User.findOne({ email: email.toLowerCase() }, (err, user) => {
    if (err) {
      return done(err);
    }
    if (!user) {
      return done(convertLocaleMessage(req.language, trans.auth.PLEASE_REGISTER), false);
    }

    user.comparePassword(password, (error, isMatch) => {
      if (error) {
        return done(error);
      }
      if (!isMatch) {
        return done(convertLocaleMessage(req.language, trans.auth.WRONG_PASSWORD), false);
      }

      return done(null, user);
    });
  });
  return false;
});

// Setup options for JWT Strategy
const jwtOptions = {
  jwtFromRequest: ExtractJwt.fromHeader('authorization'),
  secretOrKey: process.env.JWT_SECRET,
  passReqToCallback: true,
};

// Create JWT strategy
const jwtLogin = new JwtStrategy(jwtOptions, (req, payload, done) => {
  User.findById(payload.sub, async(err, user) => {
    if (err) {
      return done(err, false);
    }

    if (user) {
      user.language = req.language;
      await User.updateOne({_id: user._id}, { $set: { language: user.language }});
      done(null, user);
    } else {
      done(convertLocaleMessage(req.language, trans.auth.PLEASE_LOGIN), false);
    }
  });
});

// Tell passport to use this strategy
passport.use(jwtLogin);
passport.use(localLogin);

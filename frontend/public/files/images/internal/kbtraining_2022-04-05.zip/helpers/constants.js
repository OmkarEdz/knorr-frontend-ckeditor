'use strict';
const path = require('path');

module.exports = {
  // logic
  localization: {
    langFile: path.join(__dirname, 'locale.json'),
  },

  logger: {
    log: (message) => {
      console.log(message);
    },
  },

  LoginTypes: {
    ADMIN: 1,
    HR: 2,
    USER: 3,
  },

  userStatus: {
    ACTIVE: 1,
    DEACTIVE: 2,
  },

  tripStatus: {
    ACTIVE: 1,
    DEACTIVE: 2,
  },

  status: {
    ACTIVE: 1,
    DEACTIVE: 2,
  },

  auth: {
    PLEASE_REGISTER: 'User not found, Please register',
    WRONG_PASSWORD: 'Wrong password entered',
    PLEASE_LOGIN: 'Please login',
    EMAIL_ALREADY_EXISTS: 'The email address you have entered is already registered',
    TELEPHONE_NUMBER_ALREADY_EXISTS: 'The phone number you have entered is already being used',
    USERNAME_ALREADY_EXISTS: 'The Username you have entered is already being used',
    USER_REGISTERED_SUCCESSFULLY: 'User registered successfully',
    LOG_IN_SUCCESSFULLY: 'Logged in successfully',
    LOG_OUT_SUCCESSFULLY: 'Logged out successfully',
    USER_NOT_FOUND: 'User not found',
    ERROR_UPDATING_USER: 'Error updating the user',
    EMAIL_VERIFICATION_FAILED: 'Could not send verification email',
    EMAIL_SENT_SUCCESSFULLY: 'Reset password OTP is sent succesfully for registered email',
    WRONG_OTP: 'Wrong OTP',
    OTP_VERIFIED: 'OTP Verified',
    CHANGE_PASSWORD_SUCCESSFUL: 'Password changed successfully',
    DUPLICATE_HOMEZONE: 'Two home zones can not remain the same',
    DEVICE_ID_IN_USE: 'There is already a User with the same device',
  },

  global: {
    UPDATED_SUCCESSFULLY: 'Updated successfully',
    DELETED_SUCCESSFULLY: 'Deleted successfully',
    ADDED_SUCCESSFULLY: 'Added successfully',
    NOT_FOUND: 'Not Found',
    UPDATE_FALIED: 'Update failed',
    REQUEST_WAS_SUCCESSFULL: 'Request Was Successfull',
    INVALID_REQUEST: 'The Request was invalid',
    LEVEL_ALREADY_EXISTS_WITH_THE_COIN: 'Level already exists with the coins',
    LEVEL_ALREADY_ACTIVE: 'Level is active',
    PLEASE_UPLOAD_FILE: 'Please upload file',
    ANONYMOUS_USER_EXPIRES_SOON: 'Your Guest User expires soon. Please register or your account will be deleted soon.',
    ANONYMOUS_USER_EXPIRES_TOMORROW: 'Your Guest User expires tomorrow. Please register or your account will be deleted tomorrow.',
  },

  trip: {
    ERROR_UPDATING_TRIP: 'Error updating the trip',
    MAX_PARTICIPANTS_LIMIT_REACHED: 'Max participants reached for the trip',
    ALREADY_IN_OTHER_TRIP: 'Already in other trip',
    PLEASE_PARTICIPATE_IN_TRIP_BEFORE_STARTING_THE_TRIP: 'Please participate in trip before starting the trip',
    TRIP_NOT_FOUND: 'Trip not found',
  },

  ANONYMOUS: 'anonymous',

  match: {
    CANNOT_SELF_MATCH: 'Cannot self match',
  },

  follow: {
    CANNOT_FOLLOW_YOURSELF: 'Cannot follow yourself',
  },

  chat: {
    SENT_IMAGE: 'Sent an Image',
    SENT_VIDEO: 'Sent a Video',
    FILE_DELETED: 'This File has been deleted',
  },

  userAction: {
    CANNOT_SELF_REPORT: 'Cannot Self Report',
    ALREADY_REPORTED: 'Already Reported',
    USER_ALREADY_REPORTED: 'The User has already been reported',
    CANNOT_SELF_BLOCK: 'Cannot Self Block',
    REPORTED: 'Reported',
    ANONYMOUS: 'Action not allowed as a unregistered User',
  },

  coinsAndRewards: {
    Not_ENOUGH_COINS: 'Not enough coins to redeem',
    ALREADY_REDEEMED: 'Reward already redeemed',
  },

  TODAY: 'Today',
  YESTERDAY: 'Yesterday',
  OLDER: 'older',
  NUMBER_ALREADY_IN_USE: 'Number Already in use',
  VALID: 'Valid',

  FOLLOW_NOTIFY: 'Follows you now',
  COMMENT_NOTIFY: 'Commented your Post',

  TRIP_ADDED_NEAR_TO_YOU: 'Trip added near to you',
  TRIP_ALREADY_ADDED: 'The Trip has already been added',

  timeFormat: {
    SECOND: 'sec',
    MINUTE: 'min',
    HOUR: 'hour',
    WEEK: 'week',
    DAY: 'day',
    MONTH: 'month',
    YEAR: 'year',

    SECONDS: 'secs',
    MINUTES: 'mins',
    HOURS: 'hours',
    WEEKS: 'weeks',
    DAYS: 'days',
    MONTHS: 'months',
    YEARS: 'years',
  },

  emailContent: {

    passwordChange: (language) => {
      const content = {
        en: '<br><br>Your password has been changed successfully.<br>',
        de: '<br><br>Ihr Passwort wurde erfolgreich geändert.<br>',
      };

      const subject = {
        en: 'Street: Password Change',
        de: 'Street: Passwort ändern',
      };
      return {
        content: content[language],
        subject: subject[language],
      };
    },

    forgotPassword: (language, otp) => {
      const content = {
        en: `<br><br>Change your password. By entering following OTP:<br><b>${otp}</b>`,
        de: `<br><br>Ändern Sie Ihr Passwort. Durch Eingabe des folgenden OTP:<br><b>${otp}</b>`,
      };

      const subject = {
        en: 'Street: Forgot Password',
        de: 'Street: Passwort vergessen',
      };
      return {
        content: content[language],
        subject: subject[language],
      };
    },

    emailDeletedProfile: (options) => {
      return {
        content: `<br><br>Der Benutzer ${options.user.userName} mit der ID ${options.user._id} und der E-Mail-Adresse ${options.user.email} hat den eigenen Account gelöscht.<br><br>Grund: ${options.reason}`,
        subject: 'Ein Benutzer hat den eigenen Account gelöscht',
      };
    },

    emailReport: (detail) => {
      const { reportedBy, reportDetails, type, language, reason } = detail;

      let subject = '';
      let content = '';
      if (type === 'user'){

        content = {
          en: `<br><br>${reportedBy} has reported ${reportDetails} <br/>
              Reason for Report: ${reason}<br/> `,
          de: `<br><br>${reportedBy} hat ${reportDetails} gemeldet <br/>
              Grund für das Melden: ${reason}<br/> `,
        };

        subject = {
          en: 'A user has been reported',
          de: 'Ein Benutzer wurde gemeldet',
        };

      } else if (type === 'post') {

        content = {
          en: `<br><br>${reportedBy} has reported the following Post<br/>.
          Description of the post: ${reportDetails.description}<br/>
          Reason for Report: ${reason}<br/>
          Owner of the post: ${reportDetails.user.userName}(${reportDetails.user.email}) `,

          de: `<br><br>${reportedBy} hat folgenden Beitrag gemeldet<br/>
          Beschreibung des Beitrags: ${reportDetails.description}<br/>
          Grund für das Melden: ${reason}<br/>
          Besitzer des Beitrags: ${reportDetails.user.userName}(${reportDetails.user.email})`,
        };

        subject = {
          en: 'A Post was reported',
          de: 'Ein Beitrag wurde gemeldet',
        };

      } else if (type === 'trip') {

        content = {
          en: `<br><br>${reportedBy} has reported the following trip<br/>.
          Title of the trip: ${reportDetails.title}<br/>
          Description of the trip: ${reportDetails.description}<br/>
          Reason for Report: ${reason}<br/>
          Owner of the trip: ${reportDetails.user.userName}(${reportDetails.user.email})`,

          de: `<br><br>${reportedBy} hat folgenden trip gemeldet<br/>
          Titel der trip: ${reportDetails.title}<br/>
          Beschreibung der trip: ${reportDetails.description}<br/>
          Grund für das Melden: ${reason}<br/>
          Besitzer der trip: ${reportDetails.user.userName}(${reportDetails.user.email})`,
        };

        subject = {
          en: 'A trip was reported',
          de: 'Ein trip wurde gemeldet',
        };

      }

      return {
        content: content[language],
        subject: subject[language],
      };
    },

    redeemReward: (detail) => {
      const { rewards, newRewardHistory, userName, language } = detail;
      const emailPrefix = language === 'en' ? 'To email: ' : 'Zur E-Mail-Adresse: ';
      const addressPrefix = language === 'en' ? 'To Address: ' : 'Zur Anschrift: ';
      const rewardSendVia = rewards.type === 'email' ? emailPrefix + newRewardHistory.email : addressPrefix + newRewardHistory.address;

      const content = {
        en: `<br><br>
        Rewards Name: ${rewards.title}<br/>
        Coins: ${rewards.coins}<br/>
        Type: ${rewards.type}<br/>
        Category: ${rewards.category}<br/>
        To username: ${newRewardHistory.userName}<br/>
        ${rewardSendVia}<br/>`,

        de: `<br><br>
        Name der Belohnung: ${rewards.title}<br/>
        Coins: ${rewards.coins}<br/>
        Type: ${rewards.type}<br/>
        Kategorie: ${rewards.category}<br/>
        Name der Person: ${newRewardHistory.userName}<br/>
        ${rewardSendVia}<br/>`,
      };

      const subject = {
        en: `New reward redeemed by ${userName}`,
        de: `Neue Prämien eingelöst durch ${userName}`,
      };
      return {
        content: content[language],
        subject: subject[language],
      };
    },
  },
};

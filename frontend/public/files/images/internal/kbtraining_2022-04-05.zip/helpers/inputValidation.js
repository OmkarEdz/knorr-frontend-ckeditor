'use strict';
const Joi = require('joi');

function validateAddress() {
  return Joi.object({
    place: Joi.string().required(),
    city: Joi.string().required(),
    state: Joi.string().required(),
    country: Joi.string().required(),
    location: Joi.object({
      type: Joi.string().optional(),
      coordinates: Joi.array().min(2).max(2).required(),
    }).required(),
  });
}

function validateStopOverAddress() {
  return Joi.object({
    place: Joi.string().required(),
    location: Joi.object({
      type: Joi.string().optional(),
      coordinates: Joi.array().min(2).max(2).required(),
    }).required(),
  });
}

function validateHomezoneAddress() {
  return Joi.object({
    place: Joi.string().required(),
    city: Joi.string().required(),
    state: Joi.string().required(),
    country: Joi.string().required(),
    location: Joi.object({
      type: Joi.string().optional(),
      coordinates: Joi.array().min(2).max(2).required(),
    }).required(),
    radiusVisibility: Joi.number().required(),
    index: Joi.number().required(),
  });
}

function validateTripOrEventSearch() {
  return Joi.object().keys({
    location: Joi.object({
      coordinates: Joi.array().min(2).max(2).required(),
    }).required(),
    timezoneOffset: Joi.number().optional(),
  });
}


module.exports = {

  // auth controller
  validateSignUp: (input) => {
    const homezoneSchema = validateHomezoneAddress();

    const schema = Joi.object().keys({
      userName: Joi.string().required(),
      email: Joi.string().email({ minDomainAtoms: 2 }).required(),
      dateOfBirth: Joi.object().optional().allow(null).allow({
        date: Joi.string().required(),
        month: Joi.string().required(),
        year: Joi.string().required(),
      }),
      // dateOfBirth: {
      //   date: Joi.string().required(),
      //   month: Joi.string().required(),
      //   year: Joi.string().required(),
      // },
      password: Joi.string().min(8).max(16).required(),
      about: Joi.string().required(),
      telephoneNumber: Joi.string().optional().allow('').allow(null),
      homezone: Joi.array()
        .items(homezoneSchema)
        .optional(),
      isHomeZoneAdded: Joi.boolean().required(),
      loginType: Joi.number().required(),
      fcmToken: Joi.string().optional().allow('').allow(null),
    });

    return Joi.validate(input, schema);
  },

  validateSignIn: (input) => {
    const schema = Joi.object().keys({
      email: Joi.string().email({ minDomainAtoms: 2 }).required(),
      password: Joi.string().min(8).max(16).required(),
      fcmToken: Joi.string().optional().allow('').allow(null),
    });
    return Joi.validate(input, schema);
  },

  // trip controller
  validateAllTripList: (input) => {
    const schema = validateTripOrEventSearch();
    return Joi.validate(input, schema);
  },

  validateAllTripPagination: (input) => {
    const schema = Joi.object().keys({
      location: Joi.object({
        coordinates: Joi.array().min(2).max(2).required(),
      }).required(),
      type: Joi.string().required(),
      skip: Joi.number().required(),
      limit: Joi.number().required(),
    });
    return Joi.validate(input, schema);
  },

  validatePresetTrip: (input) => {
    const schema = Joi.object().keys({
      title: Joi.string().required(),
      image: Joi.string().required(),
    });

    return Joi.validate(input, schema);
  },

  validateUpdatePresetTrip: (input) => {
    const schema = Joi.object().keys({
      presetTripId: Joi.string().required(),
      title: Joi.string().required(),
      image: Joi.string().required(),
    });

    return Joi.validate(input, schema);
  },

  validateOnePointTrip: (input) => {

    const addressSchema = validateAddress();

    const schema = Joi.object().keys({
      category: Joi.string().required(),
      title: Joi.string().required(),
      description: Joi.string().required(),
      tripDate: Joi.date().required(),
      image: Joi.string().required(),
      user: Joi.string().required(),
      startPointAddress: addressSchema.required(),
      maxParticipants: Joi.number().optional(),
    });
    return Joi.validate(input, schema);
  },

  validateTwoPointTrip: (input) => {

    const startAddressSchema = validateAddress();
    const endAddressSchema = validateAddress();

    const schema = Joi.object().keys({
      category: Joi.string().required(),
      title: Joi.string().required(),
      description: Joi.string().required(),
      tripDate: Joi.date().required(),
      image: Joi.string().required(),
      user: Joi.string().required(),
      startPointAddress: startAddressSchema.required(),
      endPointAddress: endAddressSchema.required(),
      totalTripDistance: Joi.number().required(),
      maxParticipants: Joi.number().optional(),
    });
    return Joi.validate(input, schema);
  },

  validatecustomTrip: (input) => {

    const startAddressSchema = validateAddress();
    const endAddressSchema = validateAddress();
    const stopOverSchema = validateStopOverAddress();

    const schema = Joi.object().keys({
      category: Joi.string().required(),
      title: Joi.string().required(),
      description: Joi.string().required(),
      tripDate: Joi.date().required(),
      image: Joi.string().required(),
      user: Joi.string().required(),
      startPointAddress: startAddressSchema.required(),
      endPointAddress: endAddressSchema.required(),
      stopOvers: Joi.array()
        .items(stopOverSchema)
        .unique(),
      totalTripDistance: Joi.number().required(),
      maxParticipants: Joi.number().required(),
    });
    return Joi.validate(input, schema);
  },

  validateUpdateOnePointTrip: (input) => {

    const addressSchema = validateAddress();

    const schema = Joi.object().keys({
      tripId: Joi.string().required(),
      category: Joi.string().required(),
      title: Joi.string().required(),
      description: Joi.string().required(),
      tripDate: Joi.date().required(),
      image: Joi.string().required(),
      startPointAddress: addressSchema.required(),
      maxParticipants: Joi.number().optional(),
    });
    return Joi.validate(input, schema);
  },

  validateUpdateTwoPointTrip: (input) => {

    const startAddressSchema = validateAddress();

    const endAddressSchema = validateAddress();

    const schema = Joi.object().keys({
      tripId: Joi.string().required(),
      category: Joi.string().required(),
      title: Joi.string().required(),
      description: Joi.string().required(),
      tripDate: Joi.date().required(),
      image: Joi.string().required(),
      startPointAddress: startAddressSchema.required(),
      endPointAddress: endAddressSchema.required(),
      totalTripDistance: Joi.number().required(),
      maxParticipants: Joi.number().required(),
    });
    return Joi.validate(input, schema);
  },

  validateUpdatecustomTrip: (input) => {

    const startAddressSchema = validateAddress();
    const endAddressSchema = validateAddress();
    const stopOverSchema = validateStopOverAddress();

    const schema = Joi.object().keys({
      tripId: Joi.string().required(),
      category: Joi.string().required(),
      title: Joi.string().required(),
      description: Joi.string().required(),
      tripDate: Joi.date().required(),
      image: Joi.string().required(),
      startPointAddress: startAddressSchema.required(),
      endPointAddress: endAddressSchema.required(),
      stopOvers: Joi.array()
        .items(stopOverSchema)
        .unique(),
      totalTripDistance: Joi.number().required(),
      maxParticipants: Joi.number().required(),
    });
    return Joi.validate(input, schema);
  },

  validateUserLiveTracking: (input) => {
    const schema = Joi.object().keys({
      trackId: Joi.string().required(),
      type: Joi.string().required(),
      status: Joi.string().required(),
      totalDistanceTravelled: Joi.number().optional(),
      startPointCoordinates: Joi.array().min(2).max(2).optional(),
      hasReachedEndPoint: Joi.boolean().optional(),
    });

    return Joi.validate(input, schema);
  },

  // validateTripFilter: (input) => {
  //   const schema = Joi.object().keys({
  //     distance: Joi.number().optional().allow('').allow(null),
  //     city: Joi.string().optional().allow('').allow(null),
  //     state: Joi.string().optional().allow('').allow(null),

  //     location: Joi.object({
  //       coordinates: Joi.array().min(2).max(2).required(),
  //     }).optional(),

  //     startPoint: Joi.string().optional().allow('').allow(null),
  //     endPoint: Joi.string().optional().allow('').allow(null),

  //     user: Joi.array().optional(),
  //     auto: Joi.array().optional(),
  //   });
  //   return Joi.validate(input, schema);
  // },

  // match users
  validateCreateOrGetAMatch: input => {
    const schema = Joi.object().keys({
      userToMatch: Joi.string().required(),
    });

    return Joi.validate(input, schema);
  },

  validateMatchDetails: input => {
    const schema = Joi.object().keys({
      matchId: Joi.string().required(),
    });

    return Joi.validate(input, schema);
  },

  // chat controller
  validateNewMessage: input => {
    const schema = Joi.object().keys({
      chatId: Joi.string().required(),
      senderId: Joi.string().required(),
      receiverId: Joi.string().required(),
      message: Joi.string().required(),
    });

    return Joi.validate(input, schema);
  },

  validateAllChats: input => {
    const schema = Joi.object().keys({
      chatId: Joi.string().required(),
      otherUserId: Joi.string().required(),
    });

    return Joi.validate(input, schema);
  },

  // post controller
  validateAddNewPost: input => {
    const addressSchema = validateAddress();

    const schema = Joi.object().keys({
      user: Joi.string().required(),
      address: addressSchema.optional().allow('').allow(null),
      description: Joi.string().optional().allow('').allow(null),
      galleryImages: Joi.array().items(
        Joi.object({
          url: Joi.string().required(),
          height: Joi.number().required(),
          width: Joi.number().required(),
        }),
      ).required(),
    });

    return Joi.validate(input, schema);
  },

  validateUpdatePost: input => {
    const addressSchema = validateAddress();

    const schema = Joi.object().keys({
      postId: Joi.string().required(),
      address: addressSchema.optional().allow('').allow(null),
      description: Joi.string().optional().allow('').allow(null),
      galleryImages: Joi.array().items(
        Joi.object({
          url: Joi.string().required(),
          height: Joi.number().required(),
          width: Joi.number().required(),
        }),
      ),
      deletedImages: Joi.array().items(
        Joi.object({
          url: Joi.string().required(),
        }),
      ),
      existingImages: Joi.array().items(
        Joi.object({
          url: Joi.string().required(),
        }),
      ),
    });

    return Joi.validate(input, schema);
  },


  validateCommentOnAPost: input => {
    const schema = Joi.object().keys({
      postId: Joi.string().required(),
      comment: Joi.string().required(),
    });

    return Joi.validate(input, schema);
  },

  validateUpdateComment: input => {
    const schema = Joi.object().keys({
      commentId: Joi.string().required(),
      comment: Joi.string().required(),
    });

    return Joi.validate(input, schema);
  },

  // user controller

  validateUpdateProfile: input => {
    const homezoneSchema = validateHomezoneAddress();

    const schema = Joi.object().keys({
      userName: Joi.string().required(),
      email: Joi.string().email({ minDomainAtoms: 2 }).required(),
      dateOfBirth: {
        date: Joi.string().required(),
        month: Joi.string().required(),
        year: Joi.string().required(),
      },
      password: Joi.string().min(8).max(16).optional().allow('').allow(null),
      image: Joi.string().required().allow('').allow(null),
      about: Joi.string().required(),
      telephoneNumber: Joi.string().optional().allow('').allow(null),
      homezone: Joi.array()
        .items(homezoneSchema)
        .optional(),
      isHomeZoneAdded: Joi.boolean().required(),
      inHomeZone: Joi.boolean().required(),
    });

    return Joi.validate(input, schema);
  },

  // auto controller
  validateAddAuto: input => {
    const schema = Joi.object().keys({
      user: Joi.string().required(),
      brand: Joi.string().required(),
      model: Joi.string().required(),
      year: Joi.string().required(),
      vedioLink: Joi.string().optional(),
      description: Joi.string(),
      galleryImages: Joi.array().items(
        Joi.object({
          url: Joi.string().required(),
          height: Joi.number().required(),
          width: Joi.number().required(),
        }),
      ),
    });

    return Joi.validate(input, schema);
  },

  validateUpdateAuto: input => {
    const schema = Joi.object().keys({
      autoId: Joi.string().required(),
      brand: Joi.string().required(),
      model: Joi.string().required(),
      year: Joi.string().required(),
      vedioLink: Joi.string().optional().allow('').allow(null),
      description: Joi.string(),
      galleryImages: Joi.array().items(
        Joi.object({
          url: Joi.string().required(),
          height: Joi.number().required(),
          width: Joi.number().required(),
        }),
      ),
      deletedImages: Joi.array().items(
        Joi.object({
          url: Joi.string().required(),
          height: Joi.number().required(),
          width: Joi.number().required(),
        }),
      ),
      existingImages: Joi.array().items(
        Joi.object({
          url: Joi.string().required(),
          height: Joi.number().required(),
          width: Joi.number().required(),
        }),
      ),
    });

    return Joi.validate(input, schema);
  },

  // userAction controller

  validateBlockUnblockUser: input => {
    const schema = Joi.object().keys({
      isBlocked: Joi.boolean().required(),
      blockedUserId: Joi.string().required(),
    });

    return Joi.validate(input, schema);
  },

  validateReportUser: input => {
    const schema = Joi.object().keys({
      reportedUserId: Joi.string().required(),
      type: Joi.string().required(),
      reason: Joi.string().optional().allow('').allow(null),
    });

    return Joi.validate(input, schema);
  },


  validateReportPost: input => {
    const schema = Joi.object().keys({
      reportedPostId: Joi.string().required(),
      type: Joi.string().required(),
      reason: Joi.string().optional().allow('').allow(null),
    });

    return Joi.validate(input, schema);
  },

  validateReportTrip: input => {
    const schema = Joi.object().keys({
      reportedTripId: Joi.string().required(),
      type: Joi.string().required(),
      reason: Joi.string().optional().allow('').allow(null),
    });

    return Joi.validate(input, schema);
  },

  validateReportUserAction: input => {
    const schema = Joi.object().keys({
      id: Joi.string().required(),
      type: Joi.string().required(),
      reason: Joi.string().optional().allow('').allow(null),
    });

    return Joi.validate(input, schema);
  },

  // search
  validateSearch: input => {
    const schema = Joi.object().keys({
      type: Joi.string().required(),
      location: Joi.object({
        coordinates: Joi.array().min(2).max(2).required(),
      }).required(),
      keyword: Joi.string().optional().allow('').allow(null),
    });

    return Joi.validate(input, schema);
  },

  validateSearchStartAndEndPoint: input => {
    const schema = Joi.object().keys({
      type: Joi.string().required(),
      keyword: Joi.string().optional().allow('').allow(null),
    });

    return Joi.validate(input, schema);
  },

  validateSearchStateAndCity: input => {
    const schema = Joi.object().keys({
      type: Joi.string().required(),
      keyword: Joi.string().optional().allow('').allow(null),
      state: Joi.string().required().allow('').allow(null),
    });

    return Joi.validate(input, schema);
  },


  // event controller
  validateAddEvent: (input) => {

    const addressSchema = validateAddress();

    const schema = Joi.object().keys({
      title: Joi.string().required(),
      description: Joi.string().required(),
      eventDate: Joi.date().required(),
      image: Joi.string().required(),
      user: Joi.string().required(),
      eventAddress: addressSchema.required(),
    });
    return Joi.validate(input, schema);
  },

  validateUpdateEvent: (input) => {

    const addressSchema = validateAddress();

    const schema = Joi.object().keys({
      eventId: Joi.string().required(),
      title: Joi.string().required(),
      description: Joi.string().required(),
      eventDate: Joi.date().required(),
      image: Joi.string().required(),
      eventAddress: addressSchema.required(),
    });
    return Joi.validate(input, schema);
  },

  validateAllEventList: (input) => {
    const schema = validateTripOrEventSearch();
    return Joi.validate(input, schema);
  },

  validatePredefinedTripImage: (input) => {
    const schema = Joi.object().keys({
      user: Joi.string().required(),
      image: Joi.string().required(),
    });

    return Joi.validate(input, schema);
  },

  validateUpdatePredefinedTripImage: (input) => {
    const schema = Joi.object().keys({
      predefinedTripImageId: Joi.string().required(),
      image: Joi.string().required(),
    });

    return Joi.validate(input, schema);
  },

  // rewards

  validateReward: (input) => {
    const schema = Joi.object().keys({
      title: Joi.string().required(),
      image: Joi.string().required(),
      coins: Joi.number().required(),
      quantity: Joi.number().required(),
      type: Joi.string().required(),
      category: Joi.string().required(),
    });

    return Joi.validate(input, schema);
  },

  validateUpdateReward: (input) => {
    const schema = Joi.object().keys({
      rewardId: Joi.string().required(),
      title: Joi.string().required(),
      image: Joi.string().required(),
      coins: Joi.number().required(),
      quantity: Joi.number().required(),
      type: Joi.string().required(),
      category: Joi.string().required(),
    });

    return Joi.validate(input, schema);
  },

  validateRedeemReward: (input) => {
    const schema = Joi.object().keys({
      reward: Joi.string().required(),
      userName: Joi.string().required(),
      email: Joi.string().optional().allow('').allow(null),
      address: Joi.string().optional().allow('').allow(null),
    });

    return Joi.validate(input, schema);
  },

  // level

  validateLevel: (input) => {
    const schema = Joi.object().keys({
      level: Joi.number().required(),
      coins: Joi.number().required(),
      image: Joi.string().required(),
    });

    return Joi.validate(input, schema);
  },

  validateUpdateLevel: (input) => {
    const schema = Joi.object().keys({
      levelId: Joi.string().required(),
      level: Joi.number().required(),
      coins: Joi.number().required(),
      image: Joi.string().allow('').allow(null).optional(),
    });

    return Joi.validate(input, schema);
  },
};

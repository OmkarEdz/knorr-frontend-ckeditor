'use strict';
const constants = require('./constants');
module.exports = {

  passwordChangeEmail: (userDetails) => {
    const emailTranslation = constants.emailContent.passwordChange(userDetails.language);
    return {
      from: process.env.AWS_SES_FROM_EMAIL,
      to: userDetails.email,
      subject: emailTranslation.subject,
      content: emailTranslation.content,
    };
  },

  forgotPasswordEmail: (emailOptions) => {
    const { email, otp, language } = emailOptions;
    const emailTranslation = constants.emailContent.forgotPassword(language, otp);
    return {
      from: process.env.AWS_SES_FROM_EMAIL,
      to: email,
      subject: emailTranslation.subject,
      content: emailTranslation.content,
    };
  },

  // ******** admin ******** //
  emailReport: (options) => {
    const emailTranslation = constants.emailContent.emailReport(options);

    return {
      from: process.env.AWS_SES_FROM_EMAIL,
      subject: emailTranslation.subject,
      to: process.env.ADMIN_EMAIL,
      content: emailTranslation.content,
    };
  },

  emailDeletedProfile: (options) => {
    const emailTranslation = constants.emailContent.emailDeletedProfile(options);

    return {
      from: process.env.AWS_SES_FROM_EMAIL,
      subject: emailTranslation.subject,
      to: process.env.ADMIN_EMAIL,
      content: emailTranslation.content,
    };
  },

  redeemRewardEmail: (options) => {
    const emailTranslation = constants.emailContent.redeemReward(options);

    return {
      from: process.env.AWS_SES_FROM_EMAIL,
      subject: emailTranslation.subject,
      to: process.env.ADMIN_EMAIL,
      content: emailTranslation.content,
    };
  },
};

'use strict';
const mongoose = require('mongoose');
const { ObjectId } = mongoose.Types;
// core modules
const AWS = require('aws-sdk');
const I18nModule = require('i18n-nodejs');

// helpers
const { respondFailure } = require('../helpers/response');

// models
const UsersBlocked = require('../models/UsersBlocked');
const Post = require('../models/Post');
const User = require('../models/User');
const Trip = require('../models/Trip');
const Auto = require('../models/Auto');
const Report = require('../models/Report');
const Level = require('../models/Level');
const Reward = require('../models/Reward');

// helpers
const trans = require('./constants');

const s3bucket = new AWS.S3({
  signatureVersion: 'v4',
  accessKeyId: process.env.AWS_ACCESS_KEY_ID,
  secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
});

module.exports = {
  otp: () => Math.floor(100000 + Math.random() * 900000),

  getMessageFromValidationError: (error) => {
    const message = error.details[0].message.replace(/\"/g, '');
    const path = error.details[0].path.join().replace(/0,/g, '').replace(/,/g, '.');
    return `${message}, PATH: ${path}`;
  },

  convertLocaleMessage: (lang, message) => {
    const i18n = new I18nModule(lang, trans.localization.langFile);
    return i18n.__(message); // eslint-disable-line no-underscore-dangle
  },

  getNearestUserCurrentLocation: (req) => {
    const latitude = req.body.lat;
    const longitude = req.body.lng;
    return {
      latitude: latitude,
      longitude: longitude,
      minDistance: 0,
      // maxDistance: req.body.radiusVisibility * 1000,
    };
  },

  getUserCurrentLocation: (req) => {
    const latitude = req.body.location.coordinates[1];
    const longitude = req.body.location.coordinates[0];

    return {
      latitude: latitude,
      longitude: longitude,
      minDistance: 0,
      maxDistance: req.body.distance && req.body.distance !== 0 ? req.body.distance * 1000 : 500 * 1000, // min 500km distance
    };
  },

  // get distance between two coordinates
  getDistanceOfTwoPoints: async(lat1, lon1, lat2, lon2) => {
    const R = 6371; // km
    const dLat = module.exports.toRadians(lat2 - lat1);
    const dLon = module.exports.toRadians(lon2 - lon1);
    lat1 = module.exports.toRadians(lat1);
    lat2 = module.exports.toRadians(lat2);

    var a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
			Math.sin(dLon / 2) * Math.sin(dLon / 2) * Math.cos(lat1) * Math.cos(lat2);
    var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  },

  // Converts numeric degrees to radians
  toRadians: (value) => {
    return value * Math.PI / 180;
  },

  generateChatId: () => {
    const randSixDigit = Math.floor(100000 + Math.random() * 900000);
    const randStringDigit = Math.random().toString(36).substring(7).toUpperCase();
    return `CHID${randSixDigit}${randStringDigit}`;
  },

  getTimestamp: async(postDate, language) => {
    const current = new Date();
    const previous = new Date(postDate);

    const msPerMinute = 60 * 1000;
    const msPerHour = msPerMinute * 60;
    const msPerDay = msPerHour * 24;
    const msPerMonth = msPerDay * 30;
    const msPerYear = msPerDay * 365;

    const elapsed = current - previous;

    if (elapsed < msPerMinute) {
      const time = Math.round(elapsed / 1000);
      return time > 1 ? `${time} ${module.exports.convertLocaleMessage(language, trans.timeFormat.SECONDS)}` : `${time} ${module.exports.convertLocaleMessage(language, trans.timeFormat.SECOND)}`;
    } else if (elapsed < msPerHour) {
      const time = Math.round(elapsed / msPerMinute);
      return time > 1 ? `${time} ${module.exports.convertLocaleMessage(language, trans.timeFormat.MINUTES)}` : `${time} ${module.exports.convertLocaleMessage(language, trans.timeFormat.MINUTE)}`;
    } else if (elapsed < msPerDay) {
      const time = Math.round(elapsed / msPerHour);
      return time > 1 ? `${time} ${module.exports.convertLocaleMessage(language, trans.timeFormat.HOURS)}` : `${time} ${module.exports.convertLocaleMessage(language, trans.timeFormat.HOUR)}`;
    } else if (elapsed < msPerMonth) {
      let time = Math.round(elapsed / msPerDay);
      if (time / 7 >= 1) {
        time = Math.round(elapsed / (7 * msPerDay));
        return time > 1 ? `${time} ${module.exports.convertLocaleMessage(language, trans.timeFormat.WEEKS)}` : `${time} ${module.exports.convertLocaleMessage(language, trans.timeFormat.WEEK)}`;
      } else {
        return time > 1 ? `${time} ${module.exports.convertLocaleMessage(language, trans.timeFormat.DAYS)}` : `${time} ${module.exports.convertLocaleMessage(language, trans.timeFormat.DAY)}`;
      }
    } else if (elapsed < msPerYear) {
      const time = Math.round(elapsed / msPerMonth);
      return time > 1 ? `${time} ${module.exports.convertLocaleMessage(language, trans.timeFormat.MONTHS)}` : `${time} ${module.exports.convertLocaleMessage(language, trans.timeFormat.MONTH)}`;
    } else {
      const time = Math.round(elapsed / msPerYear);
      return time > 1 ? `${time} ${module.exports.convertLocaleMessage(language, trans.timeFormat.YEARS)}` : `${time} ${module.exports.convertLocaleMessage(language, trans.timeFormat.YEAR)}`;
    }
  },

  userBlockedBy: async(userId) => {
    return UsersBlocked.find({ blockedUser: userId, isBlocked: true }).distinct('user');
  },

  userReported: async(userId, type) => {
    let userReported = '';
    if (type === 'user') {
      userReported = await Report.find({ user: userId, type }).distinct('reportedUser');
    } else if (type === 'post') {
      userReported = await Report.find({ user: userId, type }).distinct('reportedPost');
    } else if (type === 'trip') {
      userReported = await Report.find({ user: userId, type }).distinct('reportedTrip');
    }
    return userReported;
  },

  uploadProfileImage: async(req, keyName) => {

    const file = req.file;
    var imageUrl = '';

    if (req.file !== undefined) {
      s3bucket.createBucket(function() {
        var params = {
          Bucket: process.env.AWS_BUCKET,
          Key: 'street/' + keyName,
          Body: file.buffer,
          ACL: 'public-read',
        };
        s3bucket.upload(params, function(err, data) {
          if (err) {
            console.log('Error Uploading a file', err);
          } else {
            imageUrl = keyName;
            return imageUrl;
          }
        });
        return imageUrl;
      });
    }
    return imageUrl;
  },

  getUserPosts: async(userId, match, skip, limit, language) => {

    const posts = await Post.aggregate([
      {
        $match: match,
      },
      {
        $lookup: {
          from: 'users',
          localField: 'user',
          foreignField: '_id',
          as: 'user',
        },
      },
      {
        $lookup: {
          from: 'postcomments',
          localField: '_id',
          foreignField: 'post',
          as: 'comments',
        },
      },
      { $unwind: '$user' },
      {
        $project: {
          _id: 1,
          description: 1,
          likes: 1,
          address: 1,
          galleryImages: 1,
          'user._id': 1,
          'user.image': 1,
          'user.userName': 1,
          createdAt: 1,
          updatedAt: 1,
          type: 'post',
          commentsCount: { $size: '$comments' },
        },
      },
      { $sort: { createdAt: -1 } },
      { $skip: Number(skip) },
      { $limit: Number(limit) },
    ]);
    if (posts.length > 0){
      const updatedPosts = posts.map(async(post) => {
        const isPostLiked = post.likes.users.some((user) => String(user) === String(userId));
        if (!isPostLiked) {
          post.like = false;
        } else {
          post.like = true;
        }
        post.time = await module.exports.getTimestamp(post.createdAt, language);
        return post;
      });

      return Promise.all(updatedPosts);
    } else {
      return posts;
    }
  },

  getUserDetails: async(req, res, userId) => {
    const { id, language } = req.user;
    const { skip, limit } = req.params;

    const currentDate = new Date();

    const YesterdayDate = new Date(currentDate.setDate(currentDate.getDate() - 1));

    const userDetails = await User.findOne({_id: userId, status: trans.userStatus.ACTIVE})
      .select('dateOfBirth isHomeZoneAdded homezone telephoneNumber followers.count following.count userName image about email currentCoins drivenKilometers currentLevel currentLevelImage totalCoinsEarned createdAt updatedAt');
    if (!userDetails){
      return respondFailure(res, module.exports.convertLocaleMessage(language, trans.auth.USER_NOT_FOUND));
    }

    const updatedUserDetails = userDetails.toObject();

    const userNextLevelDetail = await Level.findOne({ completedUsers: { $nin: userId } }).sort('coins').lean();
    if (userNextLevelDetail) {
      updatedUserDetails.coinsNeededForNextLevel = userNextLevelDetail.coins - userDetails.totalCoinsEarned;
      updatedUserDetails.nextLevelImage = userNextLevelDetail.image;
    }
    updatedUserDetails.myPosts = await Post.countDocuments({user: userId});

    const blockedBy = await UsersBlocked.findOne({ user: userId, blockedUser: id, isBlocked: true });
    const blockedByUser = await UsersBlocked.findOne({ blockedUser: userId, user: id, isBlocked: true });

    if (blockedBy || blockedByUser) {
      updatedUserDetails.posts = [];
      updatedUserDetails.trips = [];
      updatedUserDetails.autos = [];

      return updatedUserDetails;
    }

    const match = {
      user: ObjectId(userId),
      status: trans.status.ACTIVE,
    };

    updatedUserDetails.posts = await module.exports.getUserPosts(id, match, skip, limit, language);

    updatedUserDetails.trips = await Trip.aggregate([
      {
        $match: {
          user: ObjectId(userId),
          tripStatus: trans.tripStatus.ACTIVE,
          tripDate: { $gt: YesterdayDate },
        },
      },
      {
        $project: {
          _id: 1,
          title: 1,
          tripDate: 1,
          image: 1,
          totalTripDistance: 1,
          type: 'trip',
        },
      },
      {
        $sort: { tripDate: 1, totalTripDistance: 1},
      },
      { $skip: Number(skip) },
      { $limit: Number(limit) },
    ]);

    updatedUserDetails.autos = await Auto.aggregate([
      {
        $match: {
          user: ObjectId(userId),
          status: trans.status.ACTIVE,
        },
      },
      {
        $project: {
          _id: 1,
          brand: 1,
          model: 1,
          galleryImages: 1,
          updatedAt: 1,
          type: 'auto',
          createdAt: 1,
        },
      },
      {
        $sort: { createdAt: -1 },
      },
      { $skip: Number(skip) },
      { $limit: Number(limit) },
    ]);

    return updatedUserDetails;
  },

  getTrips: async(tripFilter, type) => {

    const { match, fields, geoNear } = tripFilter;

    return Trip.aggregate([
      {
        $geoNear: geoNear,
      },
      {
        $lookup: {
          from: 'users',
          localField: 'user',
          foreignField: '_id',
          as: 'user',
        },
      },
      {
        $unwind: { path: '$user' },
      },
      {
        $lookup: {
          from: 'autos',
          localField: 'user._id',
          foreignField: 'user',
          as: 'auto',
        },
      },
      {
        $match: match,
      },
      {
        $group: {
          _id: type,
          data: fields,
        },
      },
    ]);
  },

  getAllRewardDetails: async(match, userId) => {

    return Reward.aggregate([
      {
        $match: match,
      },
      {
        $project: {
          title: 1,
          image: 1,
          coins: 1,
          quantity: 1,
          type: 1,
          category: 1,
          userRedeemed: {$cond: [{$gt: [ {$size: {$setIntersection: ['$redeemedUsers', [ObjectId(userId)]]}}, 0]}, true, false]},
        },
      },
      { $sort: { userRedeemed: 1, title: 1 } },
    ]);
  },

  unfollowBlockedUser: async(userId, otherUserId) => {

    const userDetails = await User.findById(userId);

    const otherUserDetails = await User.findById(otherUserId);

    const isUserFollowed = userDetails.following.users.indexOf(otherUserId);
    if (isUserFollowed !== -1){
      await User.updateOne(
        { _id: userId },
        {
          $set: { 'following.count': userDetails.following.count - 1 },
          $pull: { 'following.users': otherUserId },
        },
      );
    }

    const isUserFollowing = userDetails.followers.users.indexOf(otherUserId);
    if (isUserFollowing !== -1){
      await User.updateOne(
        { _id: userId },
        {
          $set: { 'followers.count': userDetails.followers.count - 1 },
          $pull: { 'followers.users': otherUserId },
        },
      );
    }
    const isOtherUserFollowed = otherUserDetails.following.users.indexOf(userId);
    if (isOtherUserFollowed !== -1){
      await User.updateOne(
        { _id: otherUserId },
        {
          $set: { 'following.count': otherUserDetails.following.count - 1 },
          $pull: { 'following.users': userId },
        },
      );
    }
    const isOtherUserFollowing = otherUserDetails.followers.users.indexOf(userId);
    if (isOtherUserFollowing !== -1){
      await User.updateOne(
        { _id: otherUserId },
        {
          $set: { 'followers.count': otherUserDetails.followers.count - 1 },
          $pull: { 'followers.users': userId },
        },
      );
    }
    return true;
  },

  getBlockedUsers: async(userID) => {
    if (userID) {
      const blockedUsers = await UsersBlocked.find({ blockedUser: userID, isBlocked: true }).lean();
      return blockedUsers.map(usr => String(usr.user));
    }
    return [];
  },

  /**
   * Returns a random String with the given length
   * @param {*} length Length of the String
   * @returns the random String
   */
  getRandomString: (length) => {
    var result = '';
    var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    var charactersLength = characters.length;
    for (var i = 0; i < length; i++) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
  },

  /**
   * Checks if the User with the given ID is anonymous
   * @param {*} userId the ID to check
   * @returns true, if the user is anonymous, false otherwise
   */
  validateGuestUserAction: async(userId) => {
    const user = await User.findById(userId);
    return user.userName === 'anonymous';
  },
};

'use strict';
// models
const Auto = require('../../models/Auto');

// helpers
const { respondSuccess, respondFailure, respondError } = require('../../helpers/response');
const {
  getMessageFromValidationError,
  convertLocaleMessage,
} = require('../../helpers/utils');
const {
  validateAddAuto,
  validateUpdateAuto,
} = require('../../helpers/inputValidation');

const trans = require('../../helpers/constants');


module.exports = {

  allAutos: async(req, res, next) => {
    const autos = await Auto.find({status: trans.status.ACTIVE});
    if (!autos){
      return respondFailure(res, convertLocaleMessage(req.user.language, trans.global.NOT_FOUND));
    }
    return respondSuccess(res, null, autos);
  },

  myAutos: async(req, res, next) => {
    const userId = req.user.id;
    const autos = await Auto.find({ user: userId, status: trans.status.ACTIVE});
    if (!autos){
      return respondFailure(res, convertLocaleMessage(req.user.language, trans.global.NOT_FOUND));
    }
    return respondSuccess(res, null, autos);
  },

  autoDetails: async(req, res, next) => {
    const { autoId } = req.params;
    const auto = await Auto.findOne({ _id: autoId, status: trans.status.ACTIVE})
      .populate('user', ' _id userName email language');
    if (!auto){
      return respondFailure(res, convertLocaleMessage(req.user.language, trans.global.NOT_FOUND));
    }
    return respondSuccess(res, null, auto);
  },

  addAuto: async(req, res, next) => {
    const { body } = req;

    body.user = req.user.id;
    body.galleryImages = res.locals.galleryImages;

    const { error } = validateAddAuto(body);
    if (error) {
      return next(respondError(422, getMessageFromValidationError(error)));
    }

    const newAuto = new Auto(body);
    await newAuto.save();
    return respondSuccess(res, convertLocaleMessage(req.user.language, trans.global.ADDED_SUCCESSFULLY));

  },

  updateAuto: async(req, res, next) => {
    const { body } = req;
    const { autoId } = body;

    body.galleryImages = res.locals.galleryImages;
    body.existingImages = JSON.parse(body.existingImages);
    body.galleryImages = body.existingImages.concat(body.galleryImages);

    const { error } = validateUpdateAuto(body);
    if (error) {
      return next(respondError(422, getMessageFromValidationError(error)));
    }

    const auto = await Auto.findById(autoId);
    if (!auto) {
      return respondFailure(res, convertLocaleMessage(req.user.language, trans.global.NOT_FOUND));
    }

    auto.brand = body.brand;
    auto.model = body.model;
    auto.year = body.year;
    auto.vedioLink = body.vedioLink;
    auto.description = body.description;
    auto.galleryImages = body.galleryImages;

    await auto.save();

    return respondSuccess(res, convertLocaleMessage(req.user.language, trans.global.UPDATED_SUCCESSFULLY));
  },

  deleteAuto: async(req, res, next) => {
    const userId = req.user.id;
    const { autoId } = req.params;

    const deleteAuto = await Auto.deleteOne({_id: autoId, user: userId});
    if (!deleteAuto) {
      return respondFailure(res, convertLocaleMessage(req.user.language, trans.global.NOT_FOUND));
    }

    return respondSuccess(res, convertLocaleMessage(req.user.language, trans.global.DELETED_SUCCESSFULLY));
  },
};

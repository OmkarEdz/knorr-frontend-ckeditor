'use strict';
const mongoose = require('mongoose');
const { ObjectId } = mongoose.Types;
// node modules
const _ = require('lodash');
const jwt = require('jsonwebtoken');
// models
const User = require('../../models/User');
const RegisteredDevices = require('../../models/RegisteredDevices');

// helpers
const { respondSuccess, respondFailure, respondError } = require('../../helpers/response');
const { sendMail } = require('../../helpers/notification');
const {
  getMessageFromValidationError,
  otp,
  convertLocaleMessage,
  uploadProfileImage,
  getRandomString,
} = require('../../helpers/utils');
const {
  validateSignUp,
} = require('../../helpers/inputValidation');
const {
  forgotPasswordEmail,
  passwordChangeEmail,
} = require('../../helpers/emailTemplate');
const { userStatus, LoginTypes, auth, ANONYMOUS } = require('../../helpers/constants');


function tokenForUser(user) {
  const timestamp = new Date().getTime();
  return jwt.sign({
    sub: user.id,
    iat: timestamp,
    expiresIn: '4h',
  }, process.env.JWT_SECRET);
}

module.exports = {
  signUp: async(req, res, next) => {
    const { body, language } = req;
    const { email, telephoneNumber, userName } = body;

    // body.dateOfBirth = JSON.parse(body.dateOfBirth);
    body.isHomeZoneAdded = false;
    if (body.homezone) {
      body.homezone = JSON.parse(body.homezone);
      const set = new Set(body.homezone.map(JSON.stringify));
      const hasDuplicatesHomezone = set.size < body.homezone.length;
      console.log(hasDuplicatesHomezone);
      if (hasDuplicatesHomezone){
        return respondFailure(res, convertLocaleMessage(language, auth.DUPLICATE_HOMEZONE));
      }

      body.isHomeZoneAdded = true;
    }

    const { error } = validateSignUp(body);
    if (error) {
      return next(respondError(422, getMessageFromValidationError(error)));
    }

    const user = await User.findOne({ email: email.toLowerCase(), status: userStatus.ACTIVE });

    const regexUserName = new RegExp('^' + userName + '$', 'i');

    if (userName && userName !== '') {
      const checkUserName = await User.findOne({ userName: {$regex: regexUserName}, status: userStatus.ACTIVE });
      if (checkUserName || userName === ANONYMOUS) {
        return respondFailure(res, convertLocaleMessage(language, auth.USERNAME_ALREADY_EXISTS));
      }
    }

    // if (telephoneNumber && telephoneNumber !== '') {
    //   const checktelephoneNumber = await User.findOne({ telephoneNumber, status: userStatus.ACTIVE });
    //   if (checktelephoneNumber) {
    //     return respondFailure(res, convertLocaleMessage(language, auth.TELEPHONE_NUMBER_ALREADY_EXISTS));
    //   }
    // }

    if (user) {
      return respondFailure(res, convertLocaleMessage(language, auth.EMAIL_ALREADY_EXISTS));
    }
    const newUser = new User(body);
    await newUser.save();
    const userId = newUser._id;
    const keyName = `${userId}/gallery_${Date.now()}.jpg`;
    await uploadProfileImage(req, keyName);

    await User.updateOne({ _id: userId }, {
      $set: { image: keyName },
    });

    const update = await User.findOne({_id: ObjectId(userId)}, '_id userName image email');

    const tokenId = tokenForUser(newUser);
    return respondSuccess(res, convertLocaleMessage(language, auth.USER_REGISTERED_SUCCESSFULLY), {
      token: tokenId,
      data: update,
    });
  },

  signIn: async(req, res, next) => {
    const { body, language } = req;
    const { email, fcmToken } = body;

    // const user = await User.findOne({email: email.toLowerCase(), status: userStatus.ACTIVE, loginType: LoginTypes.USER});
    const user = await User.findOne({email: email.toLowerCase(), status: userStatus.ACTIVE});

    if (user) {
      const tokenId = tokenForUser(user);
      await User.updateOne({ _id: user.id }, {
        $set: { updatedAt: new Date(), forgotPasswordOtp: null, fcmToken: fcmToken },
      });

      return respondSuccess(res, convertLocaleMessage(language, auth.LOG_IN_SUCCESSFULLY), {
        token: tokenId,
        data: _.pick(user, [
          '_id',
          'userName',
          'image',
          'email',
        ]),
      });
    }
    return respondFailure(res, convertLocaleMessage(language, auth.USER_NOT_FOUND));
  },

  createAnonymousUser: async(req, res, next) => {
    const { language, body } = req;
    const deviceId = body.deviceId;

    const now = new Date().getTime();

    if (deviceId !== undefined && deviceId !== ''){
      const userByDeviceId = await User.findOne({deviceId: deviceId}, '_id userName image email');
      if (userByDeviceId){
        return respondFailure(res, convertLocaleMessage(language, auth.DEVICE_ID_IN_USE));
      }
      const registeredDevice = await RegisteredDevices.findOne({deviceId: deviceId}, 'deviceId');
      if (registeredDevice){
        return respondFailure(res, convertLocaleMessage(language, auth.DEVICE_ID_IN_USE));
      }
    }

    const userData = {
      userName: ANONYMOUS,
      email: 'anonymus_user_' + now + '@enjoythestreet.de',
      password: getRandomString(12),
      about: '',
      isHomeZoneAdded: false,
      deviceId: deviceId,
      loginType: 3,
      image: 'anonymous_user.png',
    };

    const newUser = new User(userData);
    await newUser.save();
    const userId = newUser._id;
    // const keyName = `${userId}/gallery_${Date.now()}.jpg`;
    // await uploadProfileImage(req, keyName);

    // await User.updateOne({ _id: userId }, {
    //   $set: { image: keyName },
    // });

    const newRegisteredDevice = new RegisteredDevices({deviceId: deviceId});
    await newRegisteredDevice.save();

    const update = await User.findOne({_id: ObjectId(userId)}, '_id userName image email');

    const tokenId = tokenForUser(newUser);
    return respondSuccess(res, convertLocaleMessage(language, auth.USER_REGISTERED_SUCCESSFULLY), {
      token: tokenId,
      data: update,
    });
  },

  signInDashboard: async(req, res, next) => {
    const { body, language } = req;
    const { email } = body;

    const user = await User.findOne({ email: email.toLowerCase(), status: userStatus.ACTIVE, loginType: LoginTypes.ADMIN });

    if (user) {
      const tokenId = tokenForUser(user);
      await User.updateOne({ _id: user.id }, {
        $set: { updatedAt: new Date() },
      });
      return respondSuccess(res, convertLocaleMessage(language, auth.LOG_IN_SUCCESSFULLY), {
        token: tokenId,
        data: _.pick(user, [
          '_id',
          'userName',
          'image',
          'email',
        ]),
      });
    }
    return respondFailure(res, convertLocaleMessage(language, auth.USER_NOT_FOUND));
  },

  changePasswordRequest: async(req, res, next) => {
    const { body, language } = req;
    const { email } = body;
    const userFromDb = await User.findOne({ email: email.toLowerCase(), status: userStatus.ACTIVE }).select('email language');
    if (!userFromDb) {
      return respondFailure(res, convertLocaleMessage(language, auth.USER_NOT_FOUND));
    }
    const otpNum = otp();
    process.env.OTP = otpNum;
    userFromDb.forgotPasswordOtp = otpNum;
    await userFromDb.save();
    const emailOptions = {
      email: email.toLowerCase(),
      otp: otpNum,
      language,
    };
    await sendMail(forgotPasswordEmail(emailOptions));

    return respondSuccess(res, convertLocaleMessage(language, auth.EMAIL_SENT_SUCCESSFULLY));
  },

  verifyOTP: async(req, res, next) => {
    const { body, language } = req;
    const { otpNum, email } = body;
    const userFromDb = await User.findOne({ email: email.toLowerCase(), forgotPasswordOtp: otpNum });
    if (!userFromDb) {
      return respondFailure(res, convertLocaleMessage(language, auth.WRONG_OTP));
    }
    userFromDb.forgotPasswordOtp = null;
    await userFromDb.save();

    return respondSuccess(res, convertLocaleMessage(language, auth.OTP_VERIFIED));
  },

  passwordChange: async(req, res, next) => {
    const { body, language } = req;
    const { email, password } = body;
    const userFromDb = await User.findOne({ email: email.toLowerCase() });
    if (!userFromDb) {
      return respondFailure(res, convertLocaleMessage(language, auth.USER_NOT_FOUND));
    }
    userFromDb.password = password;
    await userFromDb.save();

    await sendMail(passwordChangeEmail({ email: email.toLowerCase(), language }));

    return respondSuccess(res, convertLocaleMessage(language, auth.CHANGE_PASSWORD_SUCCESSFUL));
  },

  signOut: async(req, res, next) => {
    const { language } = req;
    const userId = req.user.id;

    await User.updateOne({ _id: userId }, {
      $set: { deviceToken: null, fcmToken: null },
    });
    return respondSuccess(res, convertLocaleMessage(language, auth.LOG_OUT_SUCCESSFULLY));
  },
};

'use strict';
const mongoose = require('mongoose');
const { ObjectId } = mongoose.Types;
// models
const User = require('../../models/User');
const Notification = require('../../models/Notification');
const UserMatch = require('../../models/UserMatch');
const Trip = require('../../models/Trip');
const Event = require('../../models/Event');

// helpers
const {
  getDistanceOfTwoPoints,
} = require('../../helpers/utils');

const trans = require('../../helpers/constants');
const { sendPushNotification } = require('../../helpers/notification');
const { convertLocaleMessage, getBlockedUsers } = require('../../helpers/utils');

module.exports = {

  updateHomeZoneStatusAndLocation: async(details) => {
    const { userId, latitude, longitude } = details;

    const user = await User.findById(userId);
    if (user) {
      user.homezone.map(async(homezone) => {
        if (homezone.location.coordinates[1] !== 0 && homezone.location.coordinates[0] !== 0) {
          var distance = await getDistanceOfTwoPoints(homezone.location.coordinates[1], homezone.location.coordinates[0], latitude, longitude);
          if (homezone.radiusVisibility > 10) {
            distance = Math.round(distance / 1000);
          }
          if (distance <= homezone.radiusVisibility){
            await User.updateOne({_id: userId}, { $set: {inHomeZone: true} });
          } else {
            await User.updateOne({_id: userId}, { $set: {inHomeZone: false} });
          }
        }
      });
      user.location.coordinates = [longitude, latitude];
      await user.save();
    }
    return user;
  },

  updateOnlineStatus: async(userId, status) => {
    return User.updateOne({_id: userId}, { $set: { onlineStatus: status}});
  },

  getAllNearOnlineUsersIgnoreHomeZone: async(userId, latitude, longitude, skip = 0, limit = 500) => {
    if (longitude === 0 || latitude === 0) return [];
    return User.aggregate([
      {
        $geoNear: {
          near: {
            type: 'Point',
            coordinates: [longitude, latitude],
          },
          distanceField: 'distance',
          distanceMultiplier: 0.001,
          minDistance: 0,
          maxDistance: 20000,
          spherical: true,
          query: { 'location.type': 'Point' },
        },
      },
      {
        $match: {
          _id: { $ne: ObjectId(userId)},
          userName: { $ne: 'anonymous'},
        },
      },
      { $skip: Number(skip) },
      { $limit: Number(limit) },
    ]);
  },

  getAllOnlineUsers: async(details, inHomeZone = false) => {
    var { userId, latitude, longitude, filter, maxDistance } = details;
    userId = ObjectId(userId);
    latitude = Number(latitude);
    longitude = Number(longitude);
    filter = Number(filter);

    const geoCondition = { near: { type: 'Point', coordinates: [longitude, latitude] }, distanceField: 'distance', distanceMultiplier: 0.001, minDistance: 0,
      spherical: true, query: { 'location.type': 'Point' } };
    if (maxDistance < 1050) {
      geoCondition['maxDistance'] = Number(maxDistance) * 1000;
    }

    if (filter === 1){ // following

      const allFollowing = await User.findOne({_id: userId}).select('following');

      return User.aggregate([
        {
          $geoNear: geoCondition,
        },
        {
          $match: {
            $and: [
              { _id: { $ne: ObjectId(userId) } },
              { _id: { $in: allFollowing.following.users } },
            ],
            onlineStatus: true,
            inHomeZone: inHomeZone === undefined ? undefined : inHomeZone,
          },
        },
        {
          $project: {
            _id: 1,
            userName: 1,
            image: 1,
            'location.coordinates': 1,
          },
        },
      ]);
    }
    if (filter === 2){ // followers

      const allFollowers = await User.findOne({_id: userId}).select('followers');

      return User.aggregate([
        {
          $geoNear: geoCondition,
        },
        {
          $match: {
            $and: [
              { _id: { $ne: ObjectId(userId) } },
              { _id: { $in: allFollowers.followers.users } },
            ],
            onlineStatus: true,
            inHomeZone: inHomeZone === undefined ? undefined : inHomeZone,
          },
        },
        {
          $project: {
            _id: 1,
            userName: 1,
            image: 1,
            'location.coordinates': 1,
          },
        },
      ]);
    }
    if (filter === 3){ // in trips

      return User.aggregate([
        {
          $geoNear: geoCondition,
        },
        {
          $match: {
            _id: { $ne: ObjectId(userId)},
            onlineStatus: true,
            inHomeZone: false,
            'trackStatus.status': true,
          },
        },
        {
          $project: {
            _id: 1,
            userName: 1,
            image: 1,
            'location.coordinates': 1,
          },
        },
      ]);
    }
    if (filter === 4) { // all

      return User.aggregate([
        {
          $geoNear: geoCondition,
        },
        {
          $match: {
            _id: { $ne: ObjectId(userId)},
            onlineStatus: true,
            inHomeZone: inHomeZone === undefined ? undefined : inHomeZone,
          },
        },
        {
          $project: {
            _id: 1,
            userName: 1,
            image: 1,
            'location.coordinates': 1,
          },
        },
        { $sort: { distance: 1 } },
      ]);
    }
  },

  allTripsOnMap: async(details) => {
    const { latitude, longitude, maxDistance } = details;

    var today = new Date();
    today.setHours(0, 0, 0, 0);

    return Trip.aggregate([
      {
        $geoNear: {
          near: {
            type: 'Point',
            coordinates: [longitude, latitude],
          },
          distanceField: 'distance',
          distanceMultiplier: 0.001,
          minDistance: 0,
          maxDistance: maxDistance && maxDistance !== 1050 ? maxDistance * 1000 : 999999999999,
          spherical: true,
          query: { 'startPointAddress.location.type': 'Point' },
        },
      },
      {
        $match: {
          tripStatus: trans.tripStatus.ACTIVE,
          tripDate: { $gt: today },
          // 'completedUsers.users': { $in: [ObjectId(userId)]},
        },
      },
      {
        $group: {
          _id: '$_id',
          title: { $first: '$title' },
          tripDate: { $first: '$tripDate' },
          image: { $first: '$image' },
          totalTripDistance: { $first: '$totalTripDistance' },
          startPointAddress: { $first: '$startPointAddress.location' },

        },
      },
      {
        $sort: { tripDate: 1, totalTripDistance: 1 },
      },
    ]);
  },

  updateTypingStatus: async(chatId, receiverId, isTyping) => {
    const checkChatId = await UserMatch.findOne({ chatId });
    if (String(checkChatId.user) === String(receiverId)) {
      await UserMatch.updateOne({ chatId }, { $set: { 'userChatDetail.isTyping': isTyping}});
    } else if (String(checkChatId.user) !== String(receiverId)) {
      await UserMatch.updateOne({ chatId }, { $set: { 'matchedUserChatDetail.isTyping': isTyping}});
    }

    return true;
  },

  allChatList: async(userId) => {

    const chatList = await UserMatch.find({
      $or: [
        { user: userId },
        { matchedUser: userId },
      ],
      deletedBy: { $ne: userId },
      latestMessage: { $ne: '' },
    }).populate('user', '_id image userName onlineStatus')
      .populate('matchedUser', '_id image userName onlineStatus')
      .sort({lastChatOn: -1});

    if (chatList.length === 0) {
      return chatList;
    }
    const updatedChatList = [];
    const updateChatList = chatList.map((chatData) => {
      if (chatData.user.id === userId) {
        const obj = {
          user: chatData.matchedUser,
          chatId: chatData.chatId,
          latestMessage: chatData.latestMessage,
          unreadCount: chatData.userChatDetail.unReadCount,
          lastMessageAt: chatData.lastChatOn,
          isTyping: chatData.userChatDetail.isTyping,
        };
        updatedChatList.push(obj);
      } else {
        const obj = {
          user: chatData.user,
          chatId: chatData.chatId,
          latestMessage: chatData.latestMessage,
          unreadCount: chatData.matchedUserChatDetail.unReadCount,
          lastMessageAt: chatData.lastChatOn,
          isTyping: chatData.matchedUserChatDetail.isTyping,
        };
        updatedChatList.push(obj);
      }
      return updatedChatList;
    });

    await Promise.all(updateChatList);
    const blockedUsers = await getBlockedUsers(userId);
    const activeChatList = updateChatList[0].filter(cht => !blockedUsers.includes(String(cht.user._id)));
    return activeChatList;
  },

  getChatAndNotificationCount: async(userId) => {

    const notificationCount = await Notification.countDocuments({toUser: ObjectId(userId), newNotification: true});
    let chatCount = 0;

    const chatList = await UserMatch.find({
      $or: [
        { user: userId },
        { matchedUser: userId },
      ],
      deletedBy: { $ne: userId },
      latestMessage: { $ne: '' },
    }).populate('user', '_id image userName')
      .populate('matchedUser', '_id image userName');

    const updateChatList = chatList.map((chatData) => {
      if (chatData.user.id === userId) {
        chatCount += chatData.userChatDetail.unReadCount;
      } else {
        chatCount += chatData.matchedUserChatDetail.unReadCount;
      }
      return chatCount;
    });

    await Promise.all(updateChatList);

    console.log('notificationCount:', notificationCount, 'chatCount:', chatCount);

    return {
      notificationCount,
      chatCount,
    };
  },

  followUser: async(followData) => {
    const { userId, otherUserId } = followData;

    if (userId === otherUserId){
      console.log(trans.follow.CANNOT_FOLLOW_YOURSELF);
    }
    let follow = false;

    const userDetails = await User.findById(userId);
    if (!userDetails) {
      console.log(trans.auth.USER_NOT_FOUND);
    }

    const otherUserDetails = await User.findById(otherUserId);
    if (!otherUserDetails) {
      console.log(trans.auth.USER_NOT_FOUND);
    }

    const isUserFollowed = userDetails.following.users.indexOf(otherUserId);
    let followingCount = 0;
    let followerCount = 0;
    if (isUserFollowed === -1) {
      followingCount = userDetails.following.count + 1;
      followerCount = otherUserDetails.followers.count + 1;

      await User.updateOne(
        { _id: userId },
        {
          $set: { 'following.count': followingCount },
          $push: { 'following.users': otherUserId },
        },
      );
      await User.updateOne(
        { _id: otherUserId },
        {
          $set: { 'followers.count': followerCount },
          $push: { 'followers.users': userId },
        },
      );
      follow = true;

      const details = {
        token: otherUserDetails.fcmToken,
        body: {
          userName: userDetails.userName,
          type: 'follow',
          fromUser: userId,
          toUser: otherUserId,
          action: userId,
          content: await convertLocaleMessage(otherUserDetails.language, trans.FOLLOW_NOTIFY),
        },
      };
      if (otherUserDetails.isNotificationEnabled){
        await sendPushNotification(details);
      }
      const newNotification = new Notification(details.body);
      await newNotification.save();

      return follow;

    } else {
      followingCount = userDetails.following.count - 1;
      followerCount = otherUserDetails.followers.count - 1;

      await User.updateOne(
        { _id: userId },
        {
          $set: { 'following.count': followingCount },
          $pull: { 'following.users': otherUserId },
        },
      );

      await User.updateOne(
        { _id: otherUserId },
        {
          $set: { 'followers.count': followerCount },
          $pull: { 'followers.users': userId },
        },
      );

      await Notification.deleteOne({fromUser: ObjectId(userId), toUser: ObjectId(otherUserId)});

      return follow;
    }
  },

  getUserDetails: async(userId, userIds) => {

    return User.aggregate([
      {
        $match: {
          $and: [
            { _id: { $ne: ObjectId(userId) } },
            { _id: { $in: userIds } },
          ],
          'trackStatus.status': true,
        },
      },
      {
        $project: {
          _id: 1,
          userName: 1,
          image: 1,
          'location.coordinates': 1,
        },
      },
    ]);
  },

  getTripParticipantCount: async(tripId) => {
    const tripDetail = await Trip.findOne({ _id: tripId, tripStatus: trans.status.ACTIVE}).select('participants.count').lean();
    return tripDetail.participants.count;
  },

  ongoingTrackingDetail: async(type, trackId) => {

    if (type === 'trip') {

      return Trip.aggregate([
        {
          $match: {
            _id: ObjectId(trackId),
          },
        },
        {
          $group: {
            _id: '$_id',
            title: { $first: '$title' },
            tripDate: { $first: '$tripDate' },
            image: { $first: '$image' },
            startPointAddress: { $first: '$startPointAddress.location' },
            endPointAddress: { $first: '$endPointAddress.location' },
            stopOvers: { $first: '$stopOvers'},
          },
        },
      ]);
    }
    if (type === 'event') {

      return Event.aggregate([
        {
          $match: {
            _id: ObjectId(trackId),
          },
        },
        {
          $group: {
            _id: '$_id',
            title: { $first: '$title' },
            eventDate: { $first: '$tripDate' },
            image: { $first: '$image' },
            eventAddress: { $first: '$eventAddress.location' },
          },
        },
      ]);
    }
  },
};



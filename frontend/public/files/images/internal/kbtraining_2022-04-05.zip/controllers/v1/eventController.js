'use strict';
// models
const Event = require('../../models/Event');
// helpers
const { respondSuccess, respondFailure, respondError } = require('../../helpers/response');
const {
  getMessageFromValidationError,
  convertLocaleMessage,
  getUserCurrentLocation,
  validateGuestUserAction,
} = require('../../helpers/utils');
const {
  validateAddEvent,
  validateUpdateEvent,
  validateAllEventList,
} = require('../../helpers/inputValidation');

const trans = require('../../helpers/constants');

const eventFields = 'title eventDate image';

module.exports = {

  allEvents: async(req, res, next) => {
    const currentDate = new Date();
    const YesterdayDate = new Date(currentDate.setDate(currentDate.getDate() - 1));

    const events = await Event
      .find({ status: trans.status.ACTIVE, eventDate: { $gt: YesterdayDate } }, eventFields)
      .sort({ eventDate: 1 });

    return respondSuccess(res, null, events);
  },

  myUpcomingEvents: async(req, res, next) => {
    const userId = req.user.id;

    const currentDate = new Date();
    const YesterdayDate = new Date(currentDate.setDate(currentDate.getDate() - 1));

    const events = await Event
      .find({ user: userId, status: trans.status.ACTIVE, eventDate: { $gt: YesterdayDate } }, eventFields)
      .sort({ eventDate: 1 });
    if (events && events.length === 0) {
      return respondFailure(res, convertLocaleMessage(req.user.language, trans.global.NOT_FOUND));
    }
    return respondSuccess(res, null, events);
  },

  myPastEvents: async(req, res, next) => {
    const userId = req.user.id;
    const events = await Event
      .find({ user: userId, status: trans.status.ACTIVE, eventDate: { $lt: new Date } }, eventFields)
      .sort({ eventDate: 1 });
    if (events && events.length === 0) {
      return respondFailure(res, convertLocaleMessage(req.user.language, trans.global.NOT_FOUND));
    }
    return respondSuccess(res, null, events);
  },

  allEventList: async(req, res, next) => {
    const { body } = req;

    const currentDate = new Date();
    const YesterdayDate = new Date(currentDate.setDate(currentDate.getDate() - 1));

    const { error } = validateAllEventList(body);
    if (error) {
      return next(respondError(422, getMessageFromValidationError(error)));
    }

    const { latitude, longitude, minDistance, maxDistance } = getUserCurrentLocation(req);

    const fields = {
      $push: {
        _id: '$_id',
        title: '$title',
        eventDate: '$eventDate',
        image: '$image',
        distance: '$distance',
      },
    };

    const match = {
      status: trans.status.ACTIVE,
      eventDate: { $gt: YesterdayDate },
    };

    const nearByEvents = await Event.aggregate([
      {
        $geoNear: {
          near: {
            type: 'Point',
            coordinates: [longitude, latitude],
          },
          distanceMultiplier: 0.001,
          distanceField: 'distance',
          minDistance: minDistance,
          maxDistance: maxDistance,
          spherical: true,
          query: { 'eventAddress.location.type': 'Point' },
        },
      },
      {
        $match: match,
      },
      {
        $group: {
          _id: 'deiner Nahe',
          data: fields,
        },
      },
      { $sort: { eventDate: 1 } },
    ]);

    const stateWiseEvents = await Event.aggregate([
      {
        $geoNear: {
          near: {
            type: 'Point',
            coordinates: [longitude, latitude],
          },
          distanceMultiplier: 0.001,
          distanceField: 'distance',
          minDistance: minDistance,
          spherical: true,
          query: { 'eventAddress.location.type': 'Point' },
        },
      },
      {
        $match: match,
      },
      {
        $group: {
          _id: '$eventAddress.state',
          data: fields,
        },
      },
    ]);

    const events = nearByEvents.concat(stateWiseEvents);

    return respondSuccess(res, null, events);
  },

  eventDetails: async(req, res, next) => {
    const userId = req.user.id;
    const { eventId } = req.params;
    const event = await Event.findOne({ _id: eventId, status: trans.status.ACTIVE })
      .populate('user', ' _id userName email language loginType');
    if (!event) {
      return respondFailure(res, convertLocaleMessage(req.user.language, trans.global.NOT_FOUND));
    }
    const updatedEventDetails = event.toObject();
    const isUserParticipated = event.participants.users.indexOf(userId);
    if (isUserParticipated === -1) {
      updatedEventDetails.participate = false;
    } else {
      updatedEventDetails.participate = true;
    }

    const isUserStartedEvent = event.ongoingUsers.users.indexOf(userId);
    updatedEventDetails.inEvent = true;
    if (isUserStartedEvent === -1) {
      updatedEventDetails.inEvent = false;
    }

    const isUserCompletedEvent = event.completedUsers.users.indexOf(userId);
    updatedEventDetails.isEventCompleted = true;
    if (isUserCompletedEvent === -1) {
      updatedEventDetails.isEventCompleted = false;
    }
    return respondSuccess(res, null, updatedEventDetails);
  },

  addEvent: async(req, res, next) => {
    const { body } = req;
    body.user = req.user.id;

    if (res.locals.imageUrl !== '') {
      body.image = res.locals.imageUrl;
    }

    body.eventAddress = JSON.parse(body.eventAddress);
    const { error } = validateAddEvent(body);
    if (error) {
      return next(respondError(422, getMessageFromValidationError(error)));
    }

    const newTrip = new Event(body);
    await newTrip.save();

    return respondSuccess(res, convertLocaleMessage(req.user.language, trans.global.ADDED_SUCCESSFULLY));

  },

  updateEvent: async(req, res, next) => {
    const { body } = req;
    const { eventId } = body;

    if (res.locals.imageUrl !== '') {
      body.image = res.locals.imageUrl;
    }

    body.eventAddress = JSON.parse(body.eventAddress);
    const { error } = validateUpdateEvent(body);
    if (error) {
      return next(respondError(422, getMessageFromValidationError(error)));
    }

    const event = await Event.findById(eventId);
    if (!event) {
      return respondFailure(res, convertLocaleMessage(req.user.language, trans.global.NOT_FOUND));
    }
    event.title = body.title;
    event.description = body.description;
    event.eventDate = body.eventDate;
    event.image = body.image;
    event.eventAddress = body.eventAddress;
    await event.save();

    return respondSuccess(res, convertLocaleMessage(req.user.language, trans.global.UPDATED_SUCCESSFULLY));
  },

  eventParticipate: async(req, res, next) => {
    const userId = req.user.id;
    const { eventId } = req.params;
    let participate = false;

    if (await validateGuestUserAction(userId)) return respondFailure(res, convertLocaleMessage(req.user.language, trans.userAction.ANONYMOUS));

    const event = await Event.findOne({ _id: eventId, status: trans.status.ACTIVE });
    if (!event) {
      return respondFailure(res, convertLocaleMessage(req.user.language, trans.global.NOT_FOUND));
    }

    const isUserParticipated = event.participants.users.indexOf(userId);
    let participateCount = 0;
    if (isUserParticipated === -1) {
      participateCount = event.participants.count + 1;
      await Event.updateOne(
        { _id: eventId },
        {
          $set: { 'participants.count': participateCount },
          $push: { 'participants.users': userId },
        },
      );

      participate = true;

      return respondSuccess(res, null, { participate });

    } else {
      participateCount = event.participants.count - 1;
      await Event.updateOne(
        { _id: eventId },
        {
          $set: { 'participants.count': participateCount },
          $pull: { 'participants.users': userId },
        },
      );

      return respondSuccess(res, null, { participate });
    }
  },

  deleteEvent: async(req, res, next) => {
    const userId = req.user.id;
    const { eventId } = req.params;

    await Event.deleteOne({ _id: eventId, user: userId });

    return respondSuccess(res, convertLocaleMessage(req.user.language, trans.global.DELETED_SUCCESSFULLY));
  },
};

'use strict';
// models
const User = require('../../models/User');
const UsersBlocked = require('../../models/UsersBlocked');
const Report = require('../../models/Report');
const Post = require('../../models/Post');
const PostComment = require('../../models/PostComment');
const Trip = require('../../models/Trip');
const UserMatch = require('../../models/UserMatch');
const Notification = require('../../models/Notification');
const Chat = require('../../models/Chat');
const Auto = require('../../models/Auto');

// helpers
const { respondSuccess, respondFailure, respondError } = require('../../helpers/response');
const {
  getMessageFromValidationError,
  convertLocaleMessage,
  unfollowBlockedUser,
  validateGuestUserAction,
} = require('../../helpers/utils');
const { sendMail } = require('../../helpers/notification');
const { emailReport } = require('../../helpers/emailTemplate');
const {
  validateBlockUnblockUser,
  validateReportUser,
  validateReportPost,
  validateReportTrip,
  validateReportUserAction,
} = require('../../helpers/inputValidation');

const trans = require('../../helpers/constants');


module.exports = {

  report: async(req, res, next) => {
    const { language } = req;
    const body = req.body;
    const { type, reason } = body;
    const userId = req.user.id;

    if (await validateGuestUserAction(userId)) return respondFailure(res, convertLocaleMessage(req.user.language, trans.userAction.ANONYMOUS));

    if (type === 'user'){

      const { error } = validateReportUser(body);
      if (error) {
        return next(respondError(422, getMessageFromValidationError(error)));
      }
      if (userId === body.reportedUserId) {
        return respondFailure(res, convertLocaleMessage(req.user.language, trans.userAction.CANNOT_SELF_REPORT));
      }
      const userToReport = await User.findById(body.reportedUserId);
      if (!userToReport) {
        return respondFailure(res, convertLocaleMessage(req.user.language, trans.auth.USER_NOT_FOUND));
      }
      const isAlreadyReported = await Report.findOne({ user: userId, reportedUser: body.reportedUserId });
      if (isAlreadyReported) {
        return respondFailure(res, convertLocaleMessage(req.user.language, trans.userAction.USER_ALREADY_REPORTED));
      }
      const reportUser = new Report();
      reportUser.user = userId;
      reportUser.type = type;
      reportUser.reason = reason === undefined ? '' : reason;
      reportUser.reportedUser = body.reportedUserId;
      await reportUser.save();

      unfollowBlockedUser(userId, body.reportedUserId);

      await sendMail(emailReport({
        reportedBy: `${req.user.userName}(${req.user.email})`,
        reportDetails: `${userToReport.userName}(${userToReport.email})`,
        type,
        language,
        reason: reason === undefined ? '' : reason,
      }));

      return respondSuccess(res, convertLocaleMessage(req.user.language, trans.userAction.REPORTED));

    } else if (type === 'post'){

      const { error } = validateReportPost(body);
      if (error) {
        return next(respondError(422, getMessageFromValidationError(error)));
      }

      const postToReport = await Post.findById(body.reportedPostId).populate('user', 'userName email');
      if (!postToReport) {
        return respondFailure(res, convertLocaleMessage(req.user.language, trans.global.NOT_FOUND));
      }
      const isAlreadyReported = await Report.findOne({ user: userId, reportedPost: body.reportedPostId });
      if (isAlreadyReported) {
        return respondFailure(res, convertLocaleMessage(req.user.language, trans.userAction.ALREADY_REPORTED));
      }
      const reportPost = new Report();
      reportPost.user = userId;
      reportPost.type = type;
      reportPost.reportedPost = body.reportedPostId;
      await reportPost.save();

      await sendMail(emailReport({
        reportedBy: `${req.user.userName}(${req.user.email})`,
        reportDetails: postToReport,
        type,
        language,
      }));

      return respondSuccess(res, convertLocaleMessage(req.user.language, trans.userAction.REPORTED));

    } else if (type === 'trip'){

      const { error } = validateReportTrip(body);
      if (error) {
        return next(respondError(422, getMessageFromValidationError(error)));
      }

      const tripToReport = await Trip.findById(body.reportedTripId).populate('user', 'userName email');
      if (!tripToReport) {
        return respondFailure(res, convertLocaleMessage(req.user.language, trans.global.NOT_FOUND));
      }
      const isAlreadyReported = await Report.findOne({ user: userId, reportedTrip: body.reportedTripId });
      if (isAlreadyReported) {
        return respondFailure(res, convertLocaleMessage(req.user.language, trans.userAction.ALREADY_REPORTED));
      }
      const reportTrip = new Report();
      reportTrip.user = userId;
      reportTrip.type = type;
      reportTrip.reportedTrip = body.reportedTripId;
      await reportTrip.save();

      await sendMail(emailReport({
        reportedBy: `${req.user.userName}(${req.user.email})`,
        reportDetails: tripToReport,
        type,
        language,
      }));

      return respondSuccess(res, convertLocaleMessage(req.user.language, trans.userAction.REPORTED));
    } else {
      return respondFailure(res, convertLocaleMessage(req.user.language, trans.global.NOT_FOUND));
    }
  },

  reportDetails: async(req, res, next) => {
    const body = req.body;
    const { type } = body;

    const match = {
      type: type,
      status: true,
    };

    const userLookup = {
      from: 'users',
      localField: 'user',
      foreignField: '_id',
      as: 'user',
    };

    const groupFields = {
      $push: {
        _id: '$user._id',
        userName: '$user.userName',
        email: '$user.email',
        image: '$user.image',
        telephoneNumber: '$user.telephoneNumber',
      },
    };

    if (type === 'user') {
      const reportedUser = await Report.aggregate([
        {
          $match: match,
        },
        {
          $lookup: userLookup,
        },
        {
          $lookup: {
            from: 'users',
            localField: 'reportedUser',
            foreignField: '_id',
            as: 'reportedUser',
          },
        },
        {
          $unwind: { path: '$reportedUser' },
        },
        {
          $unwind: { path: '$user' },
        },
        {
          $group: {
            _id: '$reportedUser._id',
            userName: { $first: '$reportedUser.userName'},
            email: { $first: '$reportedUser.email'},
            image: { $first: '$reportedUser.image'},
            telephoneNumber: { $first: '$reportedUser.telephoneNumber'},
            data: groupFields,
          },
        },
        {
          $sort: { createdAt: -1},
        },
      ]);
      return respondSuccess(res, null, reportedUser);

    } else if (type === 'post') {

      const reportedPost = await Report.aggregate([
        {
          $match: match,
        },
        {
          $lookup: userLookup,
        },
        {
          $lookup: {
            from: 'posts',
            localField: 'reportedPost',
            foreignField: '_id',
            as: 'reportedPost',
          },
        },
        {
          $unwind: { path: '$reportedPost' },
        },
        {
          $unwind: { path: '$user' },
        },
        {
          $group: {
            _id: '$reportedPost._id',
            description: { $first: '$reportedPost.description'},
            galleryImages: { $first: '$reportedPost.galleryImages'},
            data: groupFields,
          },
        },
        {
          $sort: { createdAt: -1},
        },
      ]);
      return respondSuccess(res, null, reportedPost);

    } else if (type === 'trip') {
      const reportedTrip = await Report.aggregate([
        {
          $match: match,
        },
        {
          $lookup: userLookup,
        },
        {
          $lookup: {
            from: 'trips',
            localField: 'reportedTrip',
            foreignField: '_id',
            as: 'reportedTrip',
          },
        },
        {
          $unwind: { path: '$reportedTrip' },
        },
        {
          $unwind: { path: '$user' },
        },
        {
          $group: {
            _id: '$reportedTrip._id',
            category: { $first: '$reportedTrip.category'},
            title: { $first: '$reportedTrip.title'},
            description: { $first: '$reportedTrip.description'},
            tripDate: { $first: '$reportedTrip.tripDate'},
            image: { $first: '$reportedTrip.image'},
            startPointAddress: { $first: '$reportedTrip.startPointAddress'},
            endPointAddress: { $first: '$reportedTrip.endPointAddress'},
            totalTripDistance: { $first: '$reportedTrip.totalTripDistance'},
            data: groupFields,
          },
        },
        {
          $sort: { createdAt: -1},
        },
      ]);
      return respondSuccess(res, null, reportedTrip);

    } else {
      return respondFailure(res, convertLocaleMessage(req.user.language, trans.global.NOT_FOUND));
    }
  },

  blockUnblockUser: async(req, res, next) => {
    const body = req.body;
    const userId = req.user.id;

    if (await validateGuestUserAction(userId)) return respondFailure(res, convertLocaleMessage(req.user.language, trans.userAction.ANONYMOUS));

    const { error } = validateBlockUnblockUser(body);
    if (error) {
      return next(respondError(422, getMessageFromValidationError(error)));
    }
    if (userId === body.blockedUserId) {
      return respondFailure(res, convertLocaleMessage(req.user.language, trans.userAction.CANNOT_SELF_BLOCK));
    }
    if (body.isBlocked) {
      unfollowBlockedUser(userId, body.blockedUserId);
    }
    const blockedUser = await UsersBlocked.findOne({ user: userId, blockedUser: body.blockedUserId });
    if (blockedUser) {
      blockedUser.isBlocked = body.isBlocked;
      await blockedUser.save();

      return respondSuccess(res, convertLocaleMessage(req.user.language, trans.global.REQUEST_WAS_SUCCESSFULL));
    }

    const blockUser = new UsersBlocked();
    blockUser.user = userId;
    blockUser.isBlocked = body.isBlocked;
    blockUser.blockedUser = body.blockedUserId;
    await blockUser.save();

    return respondSuccess(res, convertLocaleMessage(req.user.language, trans.global.REQUEST_WAS_SUCCESSFULL));
  },

  reportChecked: async (req, res, next) => {
    const body = req.body.id;
    
    await Report.findOneAndUpdate({ $or:[ {reportedUser:body}, {reportedPost:body}, {reportedTrip:body} ]},{status:false},{
      new: true
    })


    return respondSuccess(res);
  },

  reportUserAction: async(req, res, next) => {
    const body = req.body;
    const { type, id } = body;

    const { error } = validateReportUserAction(body);
    if (error) {
      return next(respondError(422, getMessageFromValidationError(error)));
    }

    switch (type) {
      case 'user':
        const deleteUser = User.deleteOne({ _id: id });
        const auto = Auto.deleteMany({ user: id });
        const trip = Trip.deleteMany({ user: id });
        const userMatch = UserMatch.deleteMany({
          $or: [{ user: id }, { matchedUser: id }],
        });
        const notification = Notification.deleteMany({
          $or: [{ fromUser: id }, { toUser: id }],
        });
        const usersBlocked = UsersBlocked.deleteMany({
          $or: [{ user: id }, { blockedUser: id }],
        });
        const usersReported = Report.deleteMany({
          $or: [{ user: id }, { reportedUser: id }],
        });
        const post = Post.deleteMany({ user: id });
        const postComment = PostComment.deleteMany({ user: id });
        const chat = Chat.deleteMany({
          $or: [{ senderId: id }, { receiverId: id }],
        });

        await Promise.all([
          deleteUser,
          auto,
          trip,
          userMatch,
          notification,
          usersBlocked,
          usersReported,
          post,
          postComment,
          chat,
        ]);
        return respondSuccess(res, trans.global.DELETED_SUCCESSFULLY);
      case 'post':
        await Post.deleteOne({ _id: id });
        await Report.deleteOne({ reportedPost: id });
        return respondSuccess(res, convertLocaleMessage(req.user.language, trans.global.DELETED_SUCCESSFULLY));
      case 'trip':
        await Trip.deleteOne({ _id: id });
        await Report.deleteOne({ reportedTrip: id });
        return respondSuccess(res, convertLocaleMessage(req.user.language, trans.global.DELETED_SUCCESSFULLY));
      default:
        return respondFailure(res, convertLocaleMessage(req.user.language, trans.global.NOT_FOUND));
    }
  },
};

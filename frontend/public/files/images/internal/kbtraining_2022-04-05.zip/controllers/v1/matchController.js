'use strict';
// models
const UserMatch = require('../../models/UserMatch');

// helpers
const { respondSuccess, respondFailure, respondError } = require('../../helpers/response');
const {
  getMessageFromValidationError,
  convertLocaleMessage,
  generateChatId,
} = require('../../helpers/utils');
const {
  validateCreateOrGetAMatch,
  validateMatchDetails,
} = require('../../helpers/inputValidation');

const trans = require('../../helpers/constants');

const userData = '_id image userName';

module.exports = {

  createOrGetAMatch: async(req, res, next) => {
    const { body } = req;
    const userId = req.user.id;
    const { userToMatch } = body;

    const { error } = validateCreateOrGetAMatch(body);
    if (error) {
      return next(respondError(422, getMessageFromValidationError(error)));
    }
    if (userId === userToMatch) {
      return respondFailure(res, convertLocaleMessage(req.user.language, trans.match.CANNOT_SELF_MATCH));
    }

    const existingMatch = await UserMatch.findOne({
      $or: [
        { user: userId, matchedUser: userToMatch },
        { user: userToMatch, matchedUser: userId },
      ],
    }).populate('user', userData)
      .populate('matchedUser', userData);

    if (existingMatch) {
      if (existingMatch.user.id === userId) {
        existingMatch.userChatDetail.isInChatScreen = true;
        existingMatch.userChatDetail.unReadCount = 0;
        await existingMatch.save();
      } else {
        existingMatch.matchedUserChatDetail.isInChatScreen = true;
        existingMatch.matchedUserChatDetail.unReadCount = 0;
        await existingMatch.save();
      }
      return respondSuccess(res, null, existingMatch);
    }

    const newMatch = new UserMatch();
    newMatch.user = userId;
    newMatch.matchedUser = userToMatch;
    newMatch.chatId = generateChatId();
    if (!await newMatch.save()) {
      return next(respondError(500));
    }

    await UserMatch.updateOne({ _id: newMatch.id }, {
      $set: { 'userChatDetail.isInChatScreen': true },
    });

    const newUserMatch = await UserMatch.findById(newMatch.id)
      .populate('user', userData)
      .populate('matchedUser', userData);

    return respondSuccess(res, null, newUserMatch);
  },

  matchDetails: async(req, res, next) => {
    const { body } = req;
    const { matchId } = body;

    const { error } = validateMatchDetails(body);
    if (error) {
      return next(respondError(422, getMessageFromValidationError(error)));
    }
    const match = await UserMatch.findById(matchId)
      .populate('user', userData)
      .populate('matchedUser', userData);
    if (!match) {
      return respondFailure(res, convertLocaleMessage(req.user.language, trans.global.NOT_FOUND));
    }
    return respondSuccess(res, null, match);
  },
};

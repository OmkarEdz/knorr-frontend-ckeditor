'use strict';
const mongoose = require('mongoose');
const { ObjectId } = mongoose.Types;
// models
const User = require('../../models/User');
const Notification = require('../../models/Notification');
const Report = require('../../models/Report');
const UsersBlocked = require('../../models/UsersBlocked');
const Trip = require('../../models/Trip');
const Event = require('../../models/Event');
const Level = require('../../models/Level');

// helpers
const { respondSuccess, respondFailure, respondError } = require('../../helpers/response');
const {
  getMessageFromValidationError,
  convertLocaleMessage,
  getUserDetails,
  userBlockedBy,
  userReported,
  validateGuestUserAction,
} = require('../../helpers/utils');

const { sendPushNotification } = require('../../helpers/notification');
const {
  validateUpdateProfile,
  validateUserLiveTracking,
} = require('../../helpers/inputValidation');
const {getAllNearOnlineUsersIgnoreHomeZone} = require('./socketController');

const trans = require('../../helpers/constants');


module.exports = {

  userProfile: async(req, res, next) => {
    const userId = req.user.id;

    const userDetails = await getUserDetails(req, res, userId);

    return respondSuccess(res, null, userDetails);
  },

  saveDrivenKilometers: async(userId, drivenKilometers) => {
    const user = await User.findById(userId);
    const oldKm = user.drivenKilometers;
    user.drivenKilometers += drivenKilometers;
    if (parseInt(user.drivenKilometers / 50, 10) > parseInt(oldKm / 50, 10)){
      user.currentCoins += 1;
      user.totalCoinsEarned += 1;

      const userNextLevelDetail = await Level.findOne({ completedUsers: { $nin: userId } }).sort('coins').lean();

      if (userNextLevelDetail && user.totalCoinsEarned >= userNextLevelDetail.coins){
        user.currentLevel = userNextLevelDetail.level;
        user.currentLevelImage = userNextLevelDetail.image;
        await Level.updateOne({ level: userNextLevelDetail.level }, { $push: { completedUsers: userId }});
      }
    }
    await user.save();
  },

  otherUserProfile: async(req, res, next) => {
    const { userId } = req.params;
    const { id, following } = req.user;

    const userDetails = await getUserDetails(req, res, userId);
    const isUserfollowed = following.users.indexOf(userId);
    if (isUserfollowed === -1) {
      userDetails.followed = false;
    } else {
      userDetails.followed = true;
    }

    userDetails.reported = false;
    const checkisUserReported = await Report.findOne({reportedUser: userId });
    if (checkisUserReported){
      userDetails.reported = true;
    }

    userDetails.blocked = false;
    const checkisUserBlocked = await UsersBlocked.findOne({ user: id, blockedUser: userId, isBlocked: true });
    if (checkisUserBlocked){
      userDetails.blocked = true;
    }

    return respondSuccess(res, null, userDetails);
  },

  allUsers: async(req, res, next) => {
    const userId = req.user.id;

    const users = await User.find({_id: { $ne: userId }, status: trans.userStatus.ACTIVE }, '_id image userName email telephoneNumber');

    return respondSuccess(res, null, users);
  },

  getAllNearOnlineUsers: async(req, res, next) => {
    const userId = req.user.id;
    const latitude = req.body.latitude;
    const longitude = req.body.longitude;

    const nearUsers = await getAllNearOnlineUsersIgnoreHomeZone(userId, latitude, longitude);

    return respondSuccess(res, null, nearUsers.length + '');
  },

  getAllNearOnlineUsersList: async(req, res, next) => {
    const userId = req.user.id;
    const latitude = req.body.latitude;
    const longitude = req.body.longitude;

    const nearUsers = await getAllNearOnlineUsersIgnoreHomeZone(userId, latitude, longitude);

    return respondSuccess(res, null, nearUsers);
  },

  sendDeviceInfo: async(req, res, next) => {
    const { body } = req;
    const userId = req.user.id;

    const { system, version, model } = body;

    const user = await User.findById(userId);

    if (system && system !== '') user.system = system;
    if (version && version !== '')user.version = version;
    if (model && model !== '')user.model = model;
    await user.save();

    return respondSuccess(res, convertLocaleMessage(req.user.language, trans.global.UPDATED_SUCCESSFULLY));
  },

  updateProfile: async(req, res, next) => {
    const { body } = req;
    const userId = req.user.id;
    const language = req.user.language;

    body.dateOfBirth = JSON.parse(body.dateOfBirth);
    body.inHomeZone = false;
    body.isHomeZoneAdded = false;
    if (body.homezone) {
      body.homezone = JSON.parse(body.homezone);
      body.isHomeZoneAdded = true;
      body.inHomeZone = true;
    }

    if (res.locals.imageUrl !== ''){
      body.image = res.locals.imageUrl;
    }

    const { error } = validateUpdateProfile(body);
    if (error) {
      return next(respondError(422, getMessageFromValidationError(error)));
    }

    const user = await User.findById(userId);

    const existingUser = await User.findOne({ _id: { $ne: user._id }, email: body.email });
    if (existingUser) {
      return respondFailure(res, convertLocaleMessage(language, trans.auth.EMAIL_ALREADY_EXISTS));
    }

    const checkUserName = await User.findOne({ _id: { $ne: user._id }, userName: body.userName, status: trans.userStatus.ACTIVE });
    if (checkUserName) {
      return respondFailure(res, convertLocaleMessage(language, trans.auth.USERNAME_ALREADY_EXISTS));
    }

    if (body.telephoneNumber && body.telephoneNumber !== '') {
      const checktelephoneNumber = await User.findOne({ _id: { $ne: user._id }, telephoneNumber: body.telephoneNumber, status: trans.userStatus.ACTIVE });
      if (checktelephoneNumber) {
        return respondFailure(res, convertLocaleMessage(language, trans.auth.TELEPHONE_NUMBER_ALREADY_EXISTS));
      }
    }

    user.userName = body.userName;
    user.dateOfBirth = body.dateOfBirth;
    user.image = body.image;
    user.about = body.about;
    user.telephoneNumber = body.telephoneNumber;
    user.isHomeZoneAdded = body.isHomeZoneAdded;
    user.inHomeZone = body.inHomeZone;
    user.homezone = body.homezone;
    user.email = body.email;
    if (body.password && body.password !== '') {
      user.password = body.password;
    }
    await user.save();

    return respondSuccess(res, convertLocaleMessage(req.user.language, trans.global.UPDATED_SUCCESSFULLY));
  },

  followUser: async(req, res, next) => {
    const userId = req.user.id;
    const { otherUserId } = req.params;

    if (await validateGuestUserAction(userId)) return respondFailure(res, convertLocaleMessage(req.user.language, trans.userAction.ANONYMOUS));

    if (userId === otherUserId){
      return respondFailure(res, convertLocaleMessage(req.user.language, trans.follow.CANNOT_FOLLOW_YOURSELF));
    }
    let follow = false;

    const userDetails = await User.findById(userId);

    const otherUserDetails = await User.findById(otherUserId);
    if (!otherUserDetails) {
      return respondFailure(res, convertLocaleMessage(req.user.language, trans.auth.USER_NOT_FOUND));
    }

    const isUserFollowed = userDetails.following.users.indexOf(otherUserId);
    let followingCount = 0;
    let followerCount = 0;
    if (isUserFollowed === -1) {
      followingCount = userDetails.following.count + 1;
      followerCount = otherUserDetails.followers.count + 1;

      await User.updateOne(
        { _id: userId },
        {
          $set: { 'following.count': followingCount },
          $push: { 'following.users': otherUserId },
        },
      );

      await User.updateOne(
        { _id: otherUserId },
        {
          $set: { 'followers.count': followerCount },
          $push: { 'followers.users': userId },
        },
      );

      follow = true;

      const details = {
        token: otherUserDetails.fcmToken,
        body: {
          userName: userDetails.userName,
          type: 'follow',
          fromUser: userId,
          toUser: otherUserId,
          action: userId,
          content: await convertLocaleMessage(req.user.language, trans.FOLLOW_NOTIFY),
        },
      };
      if (otherUserDetails.isNotificationEnabled){
        await sendPushNotification(details);
      }
      const newNotification = new Notification(details.body);
      await newNotification.save();

      userDetails.following.count += 1;
      userDetails.following.users.push(userId);
      return respondSuccess(res, null, userDetails);

    } else {
      followingCount = userDetails.following.count - 1;
      followerCount = otherUserDetails.followers.count - 1;

      await User.updateOne(
        { _id: userId },
        {
          $set: { 'following.count': followingCount },
          $pull: { 'following.users': otherUserId },
        },
      );

      await User.updateOne(
        { _id: otherUserId },
        {
          $set: { 'followers.count': followerCount },
          $pull: { 'followers.users': userId },
        },
      );

      await Notification.deleteOne({fromUser: ObjectId(userId), toUser: ObjectId(otherUserId)});

      userDetails.following.count -= 1;
      userDetails.following.users = userDetails.following.users.filter(e => e !== userId);
      return respondSuccess(res, null, userDetails);
    }
  },

  homeProfileDetails: async(req, res, next) => {
    const userId = req.user.id;

    const userDetails = await User.findById(userId)
      .populate('trackStatus.trip', '_id image startPointAddress endPointAddress category stopOvers')
      .populate('trackStatus.event', '_id image eventAddress')
      .select('userName image onlineStatus trackStatus currentCoins drivenKilometers following');

    return respondSuccess(res, null, userDetails);
  },

  friendsFromContact: async(req, res, next) => {
    const { body } = req;
    const userId = req.user.id;
    const { contacts } = body;

    const updatedContacts = contacts.map(contact => {
      const updateContact = contact.replace(/\D/g, '');
      const lastEightDigits = updateContact.substr(updateContact.length - 8);
      return new RegExp(lastEightDigits, 'ig');
    });

    console.log(await Promise.all(updatedContacts));

    const users = await User.find({ _id: { $ne: userId }, telephoneNumber: { $in: await Promise.all(updatedContacts) } }).select('userName image telephoneNumber');

    return respondSuccess(res, null, users);
  },

  verifyPhoneNumber: async(req, res, next) => {
    const { body } = req;
    const { telephoneNumber } = body;
    const lastEightDigits = telephoneNumber.substr(telephoneNumber.length - 8);
    const regex = new RegExp(lastEightDigits, 'ig');

    const checkTelephoneNumer = await User.findOne({ telephoneNumber: regex });
    if (checkTelephoneNumer) {
      return respondFailure(res, convertLocaleMessage(req.user.language, trans.NUMBER_ALREADY_IN_USE));
    }
    return respondSuccess(res, convertLocaleMessage(req.user.language, trans.VALID));
  },

  randomUsers: async(req, res, next) => {
    const userId = req.user.id;
    const { limit } = req.params;

    const latitude = req.user.location.coordinates[1];
    const longitude = req.user.location.coordinates[0];
    const minDistance = 0;
    const maxDistance = 500 * 1000; // min 500km distance
    const users = await User.aggregate([
      {
        $geoNear: {
          near: {
            type: 'Point',
            coordinates: [longitude, latitude],
          },
          distanceMultiplier: 0.001,
          distanceField: 'distance',
          minDistance: minDistance,
          maxDistance: maxDistance,
          spherical: true,
          query: { 'location.type': 'Point' },
        },
      },
      // { $sample: { size: Number(limit) } },
      {
        $match: {
          _id: { $ne: ObjectId(userId)},
          status: trans.userStatus.ACTIVE,
          userName: { $ne: trans.ANONYMOUS},
        },
      },
      {
        $project: {
          _id: 1,
          image: 1,
          userName: 1,
          distance: 1,
        },
      },
      { $sort: { distance: 1 } },
      { $limit: Number(limit) },
    ]);
    return respondSuccess(res, null, users);
  },

  updateCoinPerKmValue: async(req, res, next) => {
    const { body } = req;

    await User.updateMany({}, {
      $set: { coinValue: body.coinValue },
    }).lean();

    return respondSuccess(res, convertLocaleMessage(req.user.language, trans.global.UPDATED_SUCCESSFULLY));
  },

  userLiveTracking: async(req, res, next) => {
    const { body } = req;
    const { id, language } = req.user;
    const { trackId, type, status, totalDistanceTravelled, startPointCoordinates, hasReachedEndPoint } = body;

    const { error } = validateUserLiveTracking(body);
    if (error) {
      return next(respondError(422, getMessageFromValidationError(error)));
    }

    if (status === 'startTrip' || status === 'startEvent'){

      const checkUserOngoingTracking = await User.findOne({_id: id, 'trackStatus.status': true });
      if (checkUserOngoingTracking){
        return respondFailure(res, convertLocaleMessage(language, trans.trip.ALREADY_IN_OTHER_TRIP));
      }
    }

    switch (type) {
      case 'trip':

        const trip = await Trip.findOne({ _id: trackId, tripStatus: trans.tripStatus.ACTIVE });
        if (!trip) {
          return respondFailure(res, convertLocaleMessage(req.user.language, trans.global.NOT_FOUND));
        }

        if (status === 'startTrip') {

          await User.updateOne({ _id: id },
            { $set: { 'trackStatus.status': true,
              'trackStatus.trip': trackId,
              'trackStatus.type': type,
              'trackStatus.startPointCoordinates': startPointCoordinates }});

          const ongoingUsersCount = trip.ongoingUsers.count + 1;
          await Trip.updateOne(
            { _id: trackId },
            {
              $set: { 'ongoingUsers.count': ongoingUsersCount },
              $push: { 'ongoingUsers.users': id },
            },
          );
          return respondSuccess(res, convertLocaleMessage(req.user.language, trans.global.UPDATED_SUCCESSFULLY));
        }
        if (status === 'endTrip') {

          if (hasReachedEndPoint) {
            await Trip.updateOne(
              { _id: trackId },
              {
                $set: { 'completedUsers.count': trip.completedUsers.count + 1 },
                $push: { 'completedUsers.users': id },
              },
            );
          }

          const ongoingUsersCount = trip.ongoingUsers.count - 1;
          await Trip.updateOne(
            { _id: trackId },
            {
              $set: { 'ongoingUsers.count': ongoingUsersCount },
              $pull: { 'ongoingUsers.users': id },
            },
          );
        }
        break;

      case 'event':

        const event = await Event.findOne({ _id: trackId, status: trans.status.ACTIVE }).lean();
        if (!event) {
          return respondFailure(res, convertLocaleMessage(req.user.language, trans.global.NOT_FOUND));
        }

        if (status === 'startEvent') {

          await User.updateOne({ _id: id },
            { $set: { 'trackStatus.status': true,
              'trackStatus.event': trackId,
              'trackStatus.type': type,
              'trackStatus.startPointCoordinates': startPointCoordinates }});

          const ongoingUsersCount = event.ongoingUsers.count + 1;
          await Event.updateOne(
            { _id: trackId },
            {
              $set: { 'ongoingUsers.count': ongoingUsersCount },
              $push: { 'ongoingUsers.users': id },
            },
          );
          return respondSuccess(res, convertLocaleMessage(req.user.language, trans.global.UPDATED_SUCCESSFULLY));
        }
        if (status === 'endEvent') {

          if (hasReachedEndPoint){
            await Event.updateOne(
              { _id: trackId },
              {
                $set: { 'completedUsers.count': event.completedUsers.count + 1 },
                $push: { 'completedUsers.users': id },
              },
            );
          }

          const ongoingUsersCount = event.ongoingUsers.count - 1;
          await Event.updateOne(
            { _id: trackId },
            {
              $set: { 'ongoingUsers.count': ongoingUsersCount },
              $pull: { 'ongoingUsers.users': id },
            },
          );
        }
        break;
      default:
        return respondFailure(res, convertLocaleMessage(req.user.language, trans.global.NOT_FOUND));
    }

    const user = await User.findById(id);

    if (status === 'endTrip' || status === 'endEvent') {

      await User.updateOne({ _id: id },
        {
          $set: { 'trackStatus.status': false, 'trackStatus.type': '' },
          $unset: status === 'endTrip' ?
            { 'trackStatus.trip': 1, 'trackStatus.startPointCoordinates': 1 } :
            { 'trackStatus.event': 1, 'trackStatus.startPointCoordinates': 1 },
        });
    }

    return respondSuccess(res, convertLocaleMessage(req.user.language, trans.global.UPDATED_SUCCESSFULLY), { levelUp: false, totalCoinsEarned: user.totalCoinsEarned,
      currentCoins: user.currentCoins });
  },

  getFollowingFollowerList: async(req, res, next) => {
    const { type, userId, tripId } = req.body;
    const { skip, limit } = req.params;
    const { id } = req.user;

    const blockedBy = await userBlockedBy(id);
    const reportedUser = await userReported(id, 'user');

    var user = null;
    var trip = null;
    if (userId){
      user = await User.findById(userId);
      if (!user){
        return respondFailure(res, convertLocaleMessage(req.user.language, trans.auth.USER_NOT_FOUND));
      }
    }
    if (tripId){
      trip = await Trip.findById(tripId);
      if (!trip){
        return respondFailure(res, convertLocaleMessage(req.user.language, trans.auth.TRIP_NOT_FOUND));
      }
    }
    if (user == null && trip == null) return respondFailure(res, trans.global.INVALID_REQUEST);

    let getList = null;
    if (type.toLowerCase() === 'following' || type.toLowerCase() === 'folgen') {
      getList = await User.find({
        $and: [
          { _id: { $in: user.following.users } },
          { _id: { $nin: blockedBy } },
          { _id: { $nin: reportedUser } },
        ],
      })
        .select('userName email image about onlineStatus')
        .sort({ userName: 1 })
        .skip(Number(skip))
        .limit(Number(limit));
    } else if (type.toLowerCase() === 'followers' || type.toLowerCase() === 'follower') {
      getList = await User.find({
        $and: [
          { _id: { $in: user.followers.users } },
          { _id: { $nin: blockedBy } },
          { _id: { $nin: reportedUser } },
        ],
      })
        .select('userName email image about onlineStatus')
        .sort({ userName: 1 })
        .skip(Number(skip))
        .limit(Number(limit));
    } else if (type.toLowerCase() === 'participants' || type.toLowerCase() === 'participant') {
      getList = await User.find({
        $and: [
          { _id: { $in: trip.participants.users } },
          { _id: { $nin: blockedBy } },
          { _id: { $nin: reportedUser } },
        ],
      })
        .select('userName email image about onlineStatus')
        .sort({ userName: 1 })
        .skip(Number(skip))
        .limit(Number(limit));
    }
    return respondSuccess(res, null, getList);
  },
};

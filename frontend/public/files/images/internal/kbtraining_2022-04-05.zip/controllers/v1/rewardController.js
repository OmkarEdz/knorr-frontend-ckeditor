'use strict';
// models
const User = require('../../models/User');
const Reward = require('../../models/Reward');
const RewardHistory = require('../../models/RewardHistory');

// helpers
const { respondSuccess, respondFailure, respondError } = require('../../helpers/response');
const {
  getMessageFromValidationError,
  convertLocaleMessage,
  getAllRewardDetails,
} = require('../../helpers/utils');
const {
  validateReward,
  validateUpdateReward,
  validateRedeemReward,
} = require('../../helpers/inputValidation');

const { sendMail } = require('../../helpers/notification');
const { redeemRewardEmail } = require('../../helpers/emailTemplate');

const trans = require('../../helpers/constants');

module.exports = {

  allRewards: async(req, res, next) => {
    const userId = req.user.id;

    const match = {
      status: trans.status.ACTIVE,
    };

    const rewards = await getAllRewardDetails(match, userId);

    return respondSuccess(res, null, rewards);
  },

  rewardFilter: async(req, res, next) => {
    const { body } = req;
    const { category } = body;
    const userId = req.user.id;

    const match = {
      category: { $in: category },
      status: trans.status.ACTIVE,
    };

    const rewards = await getAllRewardDetails(match, userId);

    return respondSuccess(res, null, rewards);
  },

  rewardDetails: async(req, res, next) => {
    const { rewardId } = req.params;
    const reward = await Reward.findOne({ _id: rewardId, status: trans.status.ACTIVE });
    if (!reward) {
      return respondFailure(res, convertLocaleMessage(req.user.language, trans.global.NOT_FOUND));
    }
    return respondSuccess(res, null, reward);
  },

  addReward: async(req, res, next) => {
    const { body } = req;

    if (res.locals.imageUrl !== '') {
      body.image = res.locals.imageUrl;
    }

    const { error } = validateReward(body);
    if (error) {
      return next(respondError(422, getMessageFromValidationError(error)));
    }
    body.user = req.user.id;

    const newReward = new Reward(body);
    await newReward.save();

    return respondSuccess(res, convertLocaleMessage(req.user.language, trans.global.ADDED_SUCCESSFULLY));
  },


  updateReward: async(req, res, next) => {
    const { body } = req;
    const { rewardId } = body;

    if (res.locals.imageUrl !== '') {
      body.image = res.locals.imageUrl;
    }

    const { error } = validateUpdateReward(body);
    if (error) {
      return next(respondError(422, getMessageFromValidationError(error)));
    }

    const reward = await Reward.findById(rewardId);
    if (!reward) {
      return respondFailure(res, convertLocaleMessage(req.user.language, trans.global.NOT_FOUND));
    }

    delete body.rewardId;
    await Reward.updateOne({ _id: rewardId }, body);

    return respondSuccess(res, convertLocaleMessage(req.user.language, trans.global.UPDATED_SUCCESSFULLY));
  },

  deleteReward: async(req, res, next) => {
    const userId = req.user.id;
    const { rewardId } = req.params;

    await Reward.deleteOne({ _id: rewardId, user: userId });

    return respondSuccess(res, convertLocaleMessage(req.user.language, trans.global.DELETED_SUCCESSFULLY));
  },

  redeemReward: async(req, res, next) => {
    const { body } = req;
    const { reward } = body;
    const { id, language, currentCoins } = req.user;

    const { error } = validateRedeemReward(body);
    if (error) {
      return next(respondError(422, getMessageFromValidationError(error)));
    }
    body.user = id;

    const rewards = await Reward.findById(reward);
    if (!rewards) {
      return respondFailure(res, convertLocaleMessage(language, trans.global.NOT_FOUND));
    }

    if (rewards.redeemedUsers.indexOf(id) !== -1){
      return respondFailure(res, convertLocaleMessage(language, trans.coinsAndRewards.ALREADY_REDEEMED));
    } else if (rewards.coins > currentCoins) {
      return respondFailure(res, convertLocaleMessage(language, trans.coinsAndRewards.Not_ENOUGH_COINS));
    }

    rewards.quantity -= 1;
    await rewards.save();

    const newRewardHistory = new RewardHistory(body);
    await newRewardHistory.save();

    await sendMail(redeemRewardEmail({ rewards, newRewardHistory, userName: `${req.user.userName}(${req.user.email})`, language}));

    await User.updateOne({ _id: body.user }, { $set: { currentCoins: currentCoins - rewards.coins }});
    await Reward.updateOne({ _id: reward }, { $push: { redeemedUsers: body.user }});

    return respondSuccess(res, convertLocaleMessage(language, trans.global.ADDED_SUCCESSFULLY));
  },

  rewardHistory: async(req, res, next) => {
    const { body } = req;
    const { rewardSent } = body;

    const rewards = await RewardHistory.find({ rewardSent })
      .populate('user', '_id image userName email telephoneNumber')
      .populate('reward', 'title coins quantity type category');

    return respondSuccess(res, null, rewards);
  },

  updateRewardSentStatus: async(req, res, next) => {
    const { body } = req;
    const { rewardSent, rewardHistoryId } = body;

    await RewardHistory.updateOne({_id: rewardHistoryId }, {$set: { rewardSent }});

    return respondSuccess(res, convertLocaleMessage(req.user.language, trans.global.UPDATED_SUCCESSFULLY));
  },
};

'use strict';
const mongoose = require('mongoose');
const { ObjectId } = mongoose.Types;
// models
const Post = require('../../models/Post');
const User = require('../../models/User');
const PostComment = require('../../models/PostComment');
const Notification = require('../../models/Notification');

// helpers
const { respondSuccess, respondFailure, respondError } = require('../../helpers/response');
const {
  getMessageFromValidationError,
  convertLocaleMessage,
  userBlockedBy,
  userReported,
  getUserPosts,
  getTimestamp,
  validateGuestUserAction,
} = require('../../helpers/utils');
const {
  validateAddNewPost,
  validateUpdatePost,
  validateCommentOnAPost,
  validateUpdateComment,
} = require('../../helpers/inputValidation');
const { sendPushNotification } = require('../../helpers/notification');

const trans = require('../../helpers/constants');

module.exports = {

  allPost: async(req, res, next) => {
    const { id, following, language } = req.user;
    const { skip, limit } = req.params;
    following.users.push(ObjectId(id));

    const blockedBy = await userBlockedBy(id);
    const reportedPost = await userReported(id, 'post');
    console.log('blockedBy: ', blockedBy, 'reportedPost: ', reportedPost);

    const match = {
      $and: [
        // { user: { $in: following.users } },
        { user: { $nin: blockedBy } },
        { _id: { $nin: reportedPost } },
      ],
      status: trans.status.ACTIVE,
    };

    const posts = await getUserPosts(id, match, skip, limit, language);

    return respondSuccess(res, null, posts);
  },

  myPost: async(req, res, next) => {
    const { skip, limit } = req.params;
    const userId = req.user.id;
    const language = req.user.language;

    const match = {
      user: ObjectId(userId),
      status: trans.status.ACTIVE,
    };

    const posts = await getUserPosts(userId, match, skip, limit, language);

    return respondSuccess(res, null, posts);
  },

  postDetails: async(req, res, next) => {
    const userId = req.user.id;
    const language = req.user.language;
    const { postId } = req.params;

    const match = {
      _id: ObjectId(postId),
      status: trans.status.ACTIVE,
    };

    const post = await getUserPosts(userId, match, 0, 1, language);

    return respondSuccess(res, null, post[0]);
  },

  addPost: async(req, res, next) => {
    const { body } = req;

    if (await validateGuestUserAction(req.user.id)) return respondFailure(res, convertLocaleMessage(req.user.language, trans.userAction.ANONYMOUS));

    body.user = req.user.id;
    if (body.address && body.address !== '') {
      body.address = JSON.parse(body.address);
    }
    if (res.locals.galleryImages.length > 0){
      body.galleryImages = res.locals.galleryImages;
    }
    const { error } = validateAddNewPost(body);
    if (error) {
      return next(respondError(422, getMessageFromValidationError(error)));
    }

    const newPost = new Post(body);
    await newPost.save();

    return respondSuccess(res, convertLocaleMessage(req.user.language, trans.global.ADDED_SUCCESSFULLY));
  },

  updatePost: async(req, res, next) => {
    const { body } = req;
    const { postId } = body;

    if (await validateGuestUserAction(req.user.id)) return respondFailure(res, convertLocaleMessage(req.user.language, trans.userAction.ANONYMOUS));

    body.galleryImages = res.locals.galleryImages;
    if (body.address && body.address !== '') {
      body.address = JSON.parse(body.address);
    }
    body.existingImages = JSON.parse(body.existingImages);
    body.galleryImages = body.existingImages.concat(body.galleryImages);

    const { error } = validateUpdatePost(body);
    if (error) {
      return next(respondError(422, getMessageFromValidationError(error)));
    }

    const post = await Post.findById(postId);
    if (!post) {
      return respondFailure(res, convertLocaleMessage(req.user.language, trans.global.NOT_FOUND));
    }
    if (body.address && body.address !== '') {
      post.address = body.address;
    }
    post.description = body.description;
    post.galleryImages = body.galleryImages;

    await post.save();

    return respondSuccess(res, convertLocaleMessage(req.user.language, trans.global.UPDATED_SUCCESSFULLY));
  },

  deletePost: async(req, res, next) => {
    const userId = req.user.id;
    const { postId } = req.params;

    if (await validateGuestUserAction(userId)) return respondFailure(res, convertLocaleMessage(req.user.language, trans.userAction.ANONYMOUS));

    const post = await Post.findById(postId);
    if (!post) {
      return respondFailure(res, convertLocaleMessage(req.user.language, trans.global.NOT_FOUND));
    }
    await Post.deleteOne({ _id: postId, user: userId });
    await PostComment.deleteMany({ post: postId });

    return respondSuccess(res, convertLocaleMessage(req.user.language, trans.global.DELETED_SUCCESSFULLY));
  },

  likeAPost: async(req, res, next) => {
    const userId = req.user.id;
    const { postId } = req.params;

    if (await validateGuestUserAction(userId)) return respondFailure(res, convertLocaleMessage(req.user.language, trans.userAction.ANONYMOUS));

    let like = false;

    const post = await Post.findOne({ _id: postId, status: trans.status.ACTIVE });
    if (!post) {
      return respondFailure(res, convertLocaleMessage(req.user.language, trans.global.NOT_FOUND));
    }

    const isUserLiked = post.likes.users.indexOf(userId);
    let likeCount = 0;
    if (isUserLiked === -1) {
      likeCount = post.likes.count + 1;
      await Post.updateMany(
        { _id: postId },
        {
          $set: { 'likes.count': likeCount },
          $push: { 'likes.users': userId },
        },
      );

      like = true;

      return respondSuccess(res, null, { like });
    } else {
      likeCount = post.likes.count - 1;
      await Post.updateMany(
        { _id: postId },
        {
          $set: { 'likes.count': likeCount },
          $pull: { 'likes.users': userId },
        },
      );
      return respondSuccess(res, null, { like });
    }
  },

  postComments: async(req, res, next) => {
    const { language } = req;
    const { postId } = req.params;
    const blockedBy = await userBlockedBy(req.user.id);

    const comments = await PostComment
      .find({ post: postId, user: { $nin: blockedBy } })
      .populate('user', 'image userName')
      .sort('createdAt');

    if (comments.length > 0) {
      const updatedComments = comments.map(async comment => {
        const updateComment = comment.toObject();
        updateComment.time = await getTimestamp(comment.createdAt, language);
        return updateComment;
      });
      return respondSuccess(res, null, await Promise.all(updatedComments));
    }

    return respondSuccess(res, null, comments);
  },

  commentOnAPost: async(req, res, next) => {
    const { body } = req;
    const { postId, comment } = body;
    const userId = req.user.id;
    const blockedBy = await userBlockedBy(userId);

    if (await validateGuestUserAction(userId)) return respondFailure(res, convertLocaleMessage(req.user.language, trans.userAction.ANONYMOUS));

    const { error } = validateCommentOnAPost(body);
    if (error) {
      return next(respondError(422, getMessageFromValidationError(error)));
    }

    const post = await Post.findById(postId);
    if (!post) {
      return respondFailure(res, convertLocaleMessage(req.user.language, trans.global.NOT_FOUND));
    }

    const me = await User.findById(userId);

    const newComment = new PostComment();
    newComment.user = userId;
    newComment.post = postId;
    newComment.comment = comment;

    await newComment.save();

    // Send Notification Issue #68 (save only if not commented under own Post)
    if (userId !== post.user._id){
      const notificationDetails = {
        token: post.user.fcmToken,
        body: {
          userName: me.userName,
          type: 'comment',
          fromUser: userId,
          toUser: post.user._id,
          action: postId,
          content: await convertLocaleMessage(req.user.language, trans.COMMENT_NOTIFY),
        },
      };
      if (post.user.isNotificationEnabled){
        await sendPushNotification(notificationDetails);
      }
      const newNotification = new Notification(notificationDetails.body);
      await newNotification.save();
    }

    const comments = await PostComment
      .find({ post: postId, user: { $nin: blockedBy } })
      .populate('user', 'image userName');

    return respondSuccess(res, null, comments);
  },

  updatePostComment: async(req, res, next) => {
    const { body } = req;
    const { commentId } = body;
    const { id, language} = req.user;

    if (await validateGuestUserAction(req.user.id)) return respondFailure(res, convertLocaleMessage(req.user.language, trans.userAction.ANONYMOUS));

    const { error } = validateUpdateComment(body);
    if (error) {
      return next(respondError(422, getMessageFromValidationError(error)));
    }

    const postComment = await PostComment.findOne({ _id: commentId, user: id});
    if (!postComment) {
      return respondFailure(res, convertLocaleMessage(language, trans.global.NOT_FOUND));
    }
    postComment.comment = body.comment;

    await postComment.save();

    return respondSuccess(res, convertLocaleMessage(language, trans.global.UPDATED_SUCCESSFULLY));
  },

  deletePostComment: async(req, res, next) => {
    const userId = req.user.id;
    const { commentId } = req.params;

    if (await validateGuestUserAction(userId)) return respondFailure(res, convertLocaleMessage(req.user.language, trans.userAction.ANONYMOUS));

    const postComment = await PostComment.findOne({ _id: commentId, user: userId});
    if (!postComment) {
      return respondFailure(res, convertLocaleMessage(req.user.language, trans.global.NOT_FOUND));
    }
    await PostComment.deleteOne({ _id: commentId, user: userId });

    return respondSuccess(res, convertLocaleMessage(req.user.language, trans.global.DELETED_SUCCESSFULLY));
  },

  likedUsers: async(req, res, next) => {
    const { params } = req;

    const { postId } = params;

    const postLikes = await Post.aggregate([

      {
        $match: {
          _id: ObjectId(postId),
        },
      },
      {
        $unwind: { path: '$likes.users'},
      },
      {
        $lookup: {
          from: 'users',
          localField: 'likes.users',
          foreignField: '_id',
          as: 'users',
        },
      },
      {
        $unwind: { path: '$users' },
      },
      {
        $group: {
          _id: '$users._id',
          userName: { $first: '$users.userName'},
          image: { $first: '$users.image'},
        },
      },
    ]).sort({ userName: 1 });

    return respondSuccess(res, null, postLikes);
  },

};

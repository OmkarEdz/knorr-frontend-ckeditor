'use strict';
const mongoose = require('mongoose');
const { ObjectId } = mongoose.Types;
// models
const Notification = require('../../models/Notification');

// helpers
const { respondSuccess} = require('../../helpers/response');
const {
  getTimestamp,
  convertLocaleMessage,
} = require('../../helpers/utils');

const trans = require('../../helpers/constants');

module.exports = {

  allMyNotifications: async(req, res, next) => {
    const language = req.user.language;
    const userId = req.user.id;

    await Notification.updateMany({toUser: ObjectId(userId)}, { $set: { newNotification: false}});

    const notifications = await Notification.find({ type: { $nin: 'trip' }, toUser: userId, status: trans.status.ACTIVE }).populate('fromUser', 'image').sort({createdAt: -1});

    const notificationDetails = [];
    const today = [];
    const yesterday = [];
    const older = [];
    if (notifications.length > 0){
      const todayDate = new Date();
      const formattedTodayDay = `${todayDate.getDate() + '-' + Number(todayDate.getMonth() + 1) + '-' + todayDate.getFullYear()}`;
      const yesterdayDate = new Date(Date.now() - 86400000);
      const formattedYesterdayDate = `${yesterdayDate.getDate() + '-' + Number(yesterdayDate.getMonth() + 1) + '-' + yesterdayDate.getFullYear()}`;

      const updatedNotification = notifications.map(async(notification) => {
        const updateNotification = notification.toObject();
        updateNotification.time = await getTimestamp(notification.createdAt, language);
        const postDate = new Date(notification.createdAt);
        const formattedPostDate = `${postDate.getDate() + '-' + Number(postDate.getMonth() + 1) + '-' + postDate.getFullYear()}`;
        if (formattedPostDate === formattedTodayDay) {
          today.push(updateNotification);
        } else if (formattedPostDate === formattedYesterdayDate) {
          yesterday.push(updateNotification);
        } else {
          older.push(updateNotification);
        }
        return notification;
      });

      await Promise.all(updatedNotification);

      const todayData = {
        notificationDate: convertLocaleMessage(language, trans.TODAY),
        data: today,
      };
      notificationDetails.push(todayData);

      const yesterdayData = {
        notificationDate: convertLocaleMessage(language, trans.YESTERDAY),
        data: yesterday,
      };
      notificationDetails.push(yesterdayData);

      const olderData = {
        notificationDate: convertLocaleMessage(language, trans.OLDER),
        data: older,
      };
      notificationDetails.push(olderData);

      return respondSuccess(res, null, notificationDetails);
    } else {
      return respondSuccess(res, null, notifications);
    }
  },

  deleteNotifications: async(req, res, next) => {
    const userId = req.user.id;

    await Notification.updateMany({toUser: ObjectId(userId)}, { $set: { status: trans.status.DEACTIVE}});

    const notifications = await Notification.find({ toUser: userId, status: trans.status.ACTIVE });

    return respondSuccess(res, null, notifications);
  },
};

'use strict';
// models
const CarManufacturer = require('../../models/CarManufacturer');

// helpers
const { respondSuccess, respondFailure } = require('../../helpers/response');
const {
  convertLocaleMessage,
} = require('../../helpers/utils');

const trans = require('../../helpers/constants');


module.exports = {

  allMakes: async(req, res, next) => {
    const makes = await CarManufacturer.find();
    if (!makes){
      return respondFailure(res, convertLocaleMessage(req.user.language, trans.global.NOT_FOUND));
    }
    const result = makes.map(m => m.make);
    return respondSuccess(res, null, [...new Set(result)]);
  },

  getModelsByMake: async(req, res, next) => {
    const { make } = req.params;
    const models = await CarManufacturer.find({make: make});

    if (!models){
      return respondFailure(res, convertLocaleMessage(req.user.language, trans.global.NOT_FOUND));
    }
    const result = models.map(m => m.model).sort();
    return respondSuccess(res, null, [...new Set(result)]);
  },

  addMakeAndModel: async(req, res, next) => {
    const { body } = req;

    const newMakeAndModel = new CarManufacturer(body);
    await newMakeAndModel.save();
    return respondSuccess(res, convertLocaleMessage(req.user.language, trans.global.ADDED_SUCCESSFULLY));
  },

  updateMakeAndModel: async(req, res, next) => {
    const { body } = req;
    const { id } = body;

    const carManufacturer = await CarManufacturer.findById(id);
    if (!carManufacturer) {
      return respondFailure(res, convertLocaleMessage(req.user.language, trans.global.NOT_FOUND));
    }

    carManufacturer.make = body.make;
    carManufacturer.model = body.model;

    await carManufacturer.save();

    return respondSuccess(res, convertLocaleMessage(req.user.language, trans.global.UPDATED_SUCCESSFULLY));
  },

  deleteMakeAndModel: async(req, res, next) => {
    const userId = req.user.id;
    const { id } = req.params;

    const deleteCarManufacturer = await CarManufacturer.deleteOne({_id: id, user: userId});
    if (!deleteCarManufacturer) {
      return respondFailure(res, convertLocaleMessage(req.user.language, trans.global.NOT_FOUND));
    }

    return respondSuccess(res, convertLocaleMessage(req.user.language, trans.global.DELETED_SUCCESSFULLY));
  },
};

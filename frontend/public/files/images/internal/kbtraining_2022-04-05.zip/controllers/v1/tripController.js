'use strict';
const mongoose = require('mongoose');
const { ObjectId } = mongoose.Types;
// models
const Trip = require('../../models/Trip');
const PresetTrip = require('../../models/PresetTrip');
const Notification = require('../../models/Notification');
const User = require('../../models/User');

// helpers
const { respondSuccess, respondFailure, respondError } = require('../../helpers/response');
const {
  getMessageFromValidationError,
  convertLocaleMessage,
  getUserCurrentLocation,
  getTrips,
  userReported,
  userBlockedBy,
  validateGuestUserAction,
} = require('../../helpers/utils');
const {
  validatePresetTrip,
  validateOnePointTrip,
  validateTwoPointTrip,
  validatecustomTrip,
  validateUpdatePresetTrip,
  validateUpdateOnePointTrip,
  validateUpdateTwoPointTrip,
  validateUpdatecustomTrip,
  validateAllTripList,
  validateAllTripPagination,
} = require('../../helpers/inputValidation');
const { sendPushNotification } = require('../../helpers/notification');

const trans = require('../../helpers/constants');

const totalTripDistance = '$totalTripDistance';

const tripSelectData = 'title tripDate image totalTripDistance';

module.exports = {

  allTrips: async(req, res, next) => {
    const currentDate = new Date();
    const YesterdayDate = new Date(currentDate.setDate(currentDate.getDate() - 1));

    const trips = await Trip
      .find({ tripStatus: trans.tripStatus.ACTIVE, tripDate: { $gt: YesterdayDate } }, tripSelectData)
      .sort({ tripDate: 1, totalTripDistance: 1 });
    if (trips && trips.length === 0) {
      return respondFailure(res, convertLocaleMessage(req.user.language, trans.global.NOT_FOUND));
    }
    return respondSuccess(res, null, trips);
  },

  myUpcomingTrips: async(req, res, next) => {
    const userId = req.user.id;
    const currentDate = new Date();
    const YesterdayDate = new Date(currentDate.setDate(currentDate.getDate() - 1));
    const trips = await Trip
      .find({ user: userId, tripStatus: trans.tripStatus.ACTIVE, tripDate: { $gt: YesterdayDate } }, tripSelectData)
      .sort({ tripDate: 1, totalTripDistance: 1 });
    if (trips && trips.length === 0) {
      return respondFailure(res, convertLocaleMessage(req.user.language, trans.global.NOT_FOUND));
    }
    return respondSuccess(res, null, trips);
  },

  myPastTrips: async(req, res, next) => {
    const userId = req.user.id;
    const trips = await Trip
      .find({ user: userId, tripStatus: trans.tripStatus.ACTIVE, tripDate: { $lt: new Date } }, tripSelectData)
      .sort({ tripDate: 1, totalTripDistance: 1 });
    if (trips && trips.length === 0) {
      return respondFailure(res, convertLocaleMessage(req.user.language, trans.global.NOT_FOUND));
    }
    return respondSuccess(res, null, trips);
  },

  allPresetTrips: async(req, res, next) => {
    const presetTrip = await PresetTrip
      .find({ status: trans.status.ACTIVE })
      .sort({ createdAt: -1 });
    if (presetTrip && presetTrip.length === 0) {
      return respondFailure(res, convertLocaleMessage(req.user.language, trans.global.NOT_FOUND));
    }
    return respondSuccess(res, null, presetTrip);
  },

  allTripList: async(req, res, next) => {
    const { body } = req;
    const userId = req.user.id;

    const currentDate = new Date();
    const yesterdayDate = new Date(currentDate.setDate(currentDate.getDate() - 1));

    var minDate = yesterdayDate;
    if (body.timezoneOffset != null){
      const myOffset = new Date().getTimezoneOffset();
      minDate = new Date();
      minDate.setMinutes(-120);
      minDate.setMinutes(myOffset + (body.timezoneOffset * -1));
    }

    const { error } = validateAllTripList(body);
    if (error) {
      return next(respondError(422, getMessageFromValidationError(error)));
    }

    const blockedBy = await userBlockedBy(userId);
    const reportedTrip = await userReported(userId, 'trip');

    const { latitude, longitude, minDistance, maxDistance } = getUserCurrentLocation(req);

    const fields = {
      $push: {
        _id: '$_id',
        title: '$title',
        tripDate: '$tripDate',
        image: '$image',
        distance: '$distance',
        totalTripDistance: '$totalTripDistance',
        participantsCount: '$participants.count',
        maxParticipants: '$maxParticipants',
      },
    };

    const match = {
      _id: { $nin: reportedTrip },
      user: { $nin: blockedBy },
      tripStatus: trans.tripStatus.ACTIVE,
      tripDate: { $gt: minDate },
    };

    const nearByTrips = await Trip.aggregate([
      {
        $geoNear: {
          near: {
            type: 'Point',
            coordinates: [longitude, latitude],
          },
          distanceMultiplier: 0.001,
          distanceField: 'distance',
          minDistance: minDistance,
          maxDistance: maxDistance,
          spherical: true,
        },
      },
      {
        $match: match,
      },
      {
        $group: {
          _id: 'deiner Nahe',
          data: fields,
        },
      },
      { $sort: { 'data.distance': 1 } },
      {
        $project: {
          total: { $size: '$data' },
          data: { $slice: ['$data', 0, 10 ] },
        },
      },
    ]);

    const stateWiseTrips = await Trip.aggregate([
      {
        $geoNear: {
          near: {
            type: 'Point',
            coordinates: [longitude, latitude],
          },
          distanceMultiplier: 0.001,
          distanceField: 'distance',
          minDistance: minDistance,
          spherical: true,
        },
      },
      {
        $match: match,
      },
      {
        $group: {
          _id: '$startPointAddress.state',
          data: fields,
        },
      },
      { $sort: { 'data.distance': 1 } },
      {
        $project: {
          total: { $size: '$data' },
          data: { $slice: ['$data', 0, 10 ] },
        },
      },
    ]);

    const trips = nearByTrips.concat(stateWiseTrips);

    return respondSuccess(res, null, trips);
  },

  allTripPagination: async(req, res, next) => {
    const { body } = req;
    const userId = req.user.id;

    const currentDate = new Date();
    const YesterdayDate = new Date(currentDate.setDate(currentDate.getDate() - 1));

    const { error } = validateAllTripPagination(body);
    if (error) {
      return next(respondError(422, getMessageFromValidationError(error)));
    }

    const { latitude, longitude, minDistance, maxDistance } = getUserCurrentLocation(req);

    const blockedBy = await userBlockedBy(userId);
    const reportedTrip = await userReported(userId, 'trip');

    const fields = {
      $push: {
        _id: '$_id',
        title: '$title',
        tripDate: '$tripDate',
        image: '$image',
        distance: '$distance',
        totalTripDistance: totalTripDistance,
      },
    };

    const match = {
      _id: { $nin: reportedTrip },
      user: { $nin: blockedBy },
      tripStatus: trans.tripStatus.ACTIVE,
      tripDate: { $gt: YesterdayDate },
    };

    const trips = await Trip.aggregate([
      {
        $geoNear: {
          near: {
            type: 'Point',
            coordinates: [longitude, latitude],
          },
          distanceMultiplier: 0.001,
          distanceField: 'distance',
          minDistance: minDistance,
          maxDistance: maxDistance,
          spherical: true,
        },
      },
      {
        $match: match,
      },
      {
        $group: {
          _id: body.type,
          data: fields,
        },
      },
      { $sort: { 'data.distance': 1 } },
      {
        $project: {
          total: { $size: '$data' },
          data: { $slice: ['$data', Number(body.skip), Number(body.limit) ] },
        },
      },
    ]);

    return respondSuccess(res, null, trips);
  },

  tripFilter: async(req, res, next) => {
    const { body } = req;
    const userId = req.user.id;

    const currentDate = new Date();
    const yesterdayDate = new Date(currentDate.setDate(currentDate.getDate() - 1));

    var minDate = yesterdayDate;
    if (body.timezoneOffset != null){
      const myOffset = new Date().getTimezoneOffset();
      minDate = new Date();
      minDate.setMinutes(-120);
      minDate.setMinutes(myOffset + (body.timezoneOffset * -1));
    }

    const { latitude, longitude, minDistance, maxDistance } = getUserCurrentLocation(req);

    const blockedBy = await userBlockedBy(userId);
    const reportedTrip = await userReported(userId, 'trip');

    const fields = {
      $push: {
        _id: '$_id',
        title: '$title',
        tripDate: '$tripDate',
        image: '$image',
        distance: '$distance',
        totalTripDistance: totalTripDistance,
        user: '$user._id',
      },
    };

    const match = {
      _id: { $nin: reportedTrip },
      user: { $nin: blockedBy },
      tripStatus: trans.tripStatus.ACTIVE,
      tripDate: { $gt: minDate },
    };

    if (body.city && body.city !== '') {
      match['startPointAddress.city'] = body.city;
    }
    if (body.state && body.state !== '') {
      match['startPointAddress.state'] = body.state;
    }
    if (body.startPoint && body.startPoint !== '') {
      match['startPointAddress.place'] = body.startPoint;
    }
    if (body.endPoint && body.endPoint !== '') {
      match['endPointAddress.place'] = body.endPoint;
    }
    if (body.user && body.user.length !== 0) {
      match['user.email'] = { $in: body.user };
    }
    if (body.auto && body.auto.length !== 0) {
      match['auto.brand'] = { $in: body.auto };
    }
    if (body.autoModel && body.autoModel.length !== 0) {
      match['auto.model'] = { $in: body.autoModel };
    }

    const geoNear = {
      near: {
        type: 'Point',
        coordinates: [longitude, latitude],
      },
      distanceMultiplier: 0.001,
      distanceField: 'distance',
      minDistance: minDistance,
      spherical: true,
    };

    const tripObj = {
      match,
      fields,
      geoNear,
    };
    let nearByTrips = [];
    if (body.distance && body.distance !== 0){
      geoNear['maxDistance'] = maxDistance;
      nearByTrips = await getTrips(tripObj, 'deiner Nahe');
    }
    const cityWiseTrips = await getTrips(tripObj, '$startPointAddress.city');
    const stateWiseTrips = await getTrips(tripObj, '$startPointAddress.state');

    const trips = nearByTrips.concat(cityWiseTrips).concat(stateWiseTrips);

    return respondSuccess(res, null, trips);
  },

  tripDetails: async(req, res, next) => {
    const userId = req.user.id;
    const { tripId } = req.params;
    const trip = await Trip.findOne({ _id: tripId, tripStatus: trans.tripStatus.ACTIVE })
      .populate('user', ' _id userName image email language loginType');
    if (!trip) {
      return respondFailure(res, convertLocaleMessage(req.user.language, trans.global.NOT_FOUND));
    }
    const updatedTripDetails = trip.toObject();
    const isUserParticipated = trip.participants.users.indexOf(userId);
    updatedTripDetails.participate = true;
    if (isUserParticipated === -1) {
      updatedTripDetails.participate = false;
    }
    const isUserStartedTrip = trip.ongoingUsers.users.indexOf(userId);
    updatedTripDetails.inTrip = true;
    if (isUserStartedTrip === -1) {
      updatedTripDetails.inTrip = false;
    }

    const isUserCompletedTrip = trip.completedUsers.users.indexOf(userId);
    updatedTripDetails.isTripCompleted = true;
    if (isUserCompletedTrip === -1) {
      updatedTripDetails.isTripCompleted = false;
    }
    return respondSuccess(res, null, updatedTripDetails);
  },

  presetTripDetails: async(req, res, next) => {
    const { presetTripId } = req.params;
    const presetTrip = await PresetTrip.findOne({ _id: presetTripId, status: trans.status.ACTIVE });
    if (!presetTrip) {
      return respondFailure(res, convertLocaleMessage(req.user.language, trans.global.NOT_FOUND));
    }
    return respondSuccess(res, null, presetTrip);
  },

  addPresetTrip: async(req, res, next) => {
    const { body } = req;

    if (res.locals.imageUrl !== '') {
      body.image = res.locals.imageUrl;
    }

    const { error } = validatePresetTrip(body);
    if (error) {
      return next(respondError(422, getMessageFromValidationError(error)));
    }
    body.user = req.user.id;

    const newPresetTrip = new PresetTrip(body);
    await newPresetTrip.save();

    return respondSuccess(res, convertLocaleMessage(req.user.language, trans.global.ADDED_SUCCESSFULLY));
  },

  addTrip: async(req, res, next) => {
    const { body } = req;
    const { category } = body;
    body.user = req.user.id;

    if (await validateGuestUserAction(req.user.id)) return respondFailure(res, convertLocaleMessage(req.user.language, trans.userAction.ANONYMOUS));

    if (res.locals.imageUrl !== '') {
      body.image = res.locals.imageUrl;
    }

    if (category === '1 point') {

      body.startPointAddress = JSON.parse(body.startPointAddress);
      const { error } = validateOnePointTrip(body);
      if (error) {
        return next(respondError(422, getMessageFromValidationError(error)));
      }
    }
    if (category === '2 point') {

      body.startPointAddress = JSON.parse(body.startPointAddress);
      body.endPointAddress = JSON.parse(body.endPointAddress);
      const { error } = validateTwoPointTrip(body);
      if (error) {
        return next(respondError(422, getMessageFromValidationError(error)));
      }
    }
    if (category === 'custom') {

      body.startPointAddress = JSON.parse(body.startPointAddress);
      body.endPointAddress = JSON.parse(body.endPointAddress);
      body.stopOvers = JSON.parse(body.stopOvers);
      const { error } = validatecustomTrip(body);
      if (error) {
        return next(respondError(422, getMessageFromValidationError(error)));
      }
    }

    const latitude = req.body.startPointAddress.location.coordinates[1];
    const longitude = req.body.startPointAddress.location.coordinates[0];

    const distanceAlreadyCreated = 1000;
    var minDateAlreadyCreated = new Date(body.tripDate);
    minDateAlreadyCreated.setMinutes(-480);

    var maxDateAlreadyCreated = new Date(body.tripDate);
    maxDateAlreadyCreated.setTime(maxDateAlreadyCreated.getTime() + (12 * 60 * 60 * 1000));

    const tripsWithThisPosition = await Trip.aggregate([
      {
        $geoNear: {
          near: {
            type: 'Point',
            coordinates: [longitude, latitude],
          },
          distanceField: 'distance',
          minDistance: 0,
          maxDistance: distanceAlreadyCreated,
          spherical: true,
        },
      },
      {
        $match: {
          user: ObjectId(body.user),
          tripStatus: trans.tripStatus.ACTIVE,
          tripDate: { $gt: minDateAlreadyCreated, $lt: maxDateAlreadyCreated },
        },
      },
    ]);

    if (tripsWithThisPosition && tripsWithThisPosition.length > 0){
      console.log('Trip already exists');
      return next(respondError(422, convertLocaleMessage(req.user.language, trans.TRIP_ALREADY_ADDED)));
    }

    const newTrip = new Trip(body);
    await newTrip.save();

    // const blockedBy = await userBlockedBy(body.user);
    // const reportedUser = await userReported(body.user, 'user');

    const distance = 20 * 1000;
    const users = await User.aggregate([
      {
        $geoNear: {
          near: {
            type: 'Point',
            coordinates: [longitude, latitude],
          },
          distanceField: 'distance',
          minDistance: 0,
          maxDistance: distance,
          spherical: true,
        },
      },
      {
        $match: {
          _id: { $ne: ObjectId(body.user)},
          status: trans.status.ACTIVE,
        },
      },
      {
        $project: {
          _id: 1,
          distance: 1,
          fcmToken: 1,
          isNotificationEnabled: 1,
        },
      },
      { $sort: { distance: 1 } },
    ]);

    users.map(async(userData) => {
      const details = {
        token: userData.fcmToken,
        body: {
          userName: newTrip.title,
          type: 'trip',
          fromUser: body.user,
          toUser: userData._id,
          action: newTrip._id,
          content: await convertLocaleMessage(req.user.language, trans.TRIP_ADDED_NEAR_TO_YOU),
        },
      };
      if (userData.isNotificationEnabled){
        await sendPushNotification(details);
      }
      const newNotification = new Notification(details.body);
      await newNotification.save();
    });
    return respondSuccess(res, convertLocaleMessage(req.user.language, trans.global.ADDED_SUCCESSFULLY), users);
  },

  updatePresetTrip: async(req, res, next) => {
    const { body } = req;
    const { presetTripId } = body;

    if (res.locals.imageUrl !== '') {
      body.image = res.locals.imageUrl;
    }

    const { error } = validateUpdatePresetTrip(body);
    if (error) {
      return next(respondError(422, getMessageFromValidationError(error)));
    }

    const presetTrip = await PresetTrip.findById(presetTripId);
    if (!presetTrip) {
      return respondFailure(res, convertLocaleMessage(req.user.language, trans.global.NOT_FOUND));
    }
    presetTrip.title = body.title;
    presetTrip.image = body.image;
    await presetTrip.save();

    return respondSuccess(res, convertLocaleMessage(req.user.language, trans.global.UPDATED_SUCCESSFULLY));
  },

  updateTrip: async(req, res, next) => {
    const { body } = req;
    const { category, tripId } = body;

    if (await validateGuestUserAction(req.user.id)) return respondFailure(res, convertLocaleMessage(req.user.language, trans.userAction.ANONYMOUS));

    if (res.locals.imageUrl !== '') {
      body.image = res.locals.imageUrl;
    }

    if (category === '1 point') {

      body.startPointAddress = JSON.parse(body.startPointAddress);

      const { error } = validateUpdateOnePointTrip(body);
      if (error) {
        return next(respondError(422, getMessageFromValidationError(error)));
      }

      const onePointTrip = await Trip.findById(tripId);
      if (!onePointTrip) {
        return respondFailure(res, convertLocaleMessage(req.user.language, trans.global.NOT_FOUND));
      }
      onePointTrip.title = body.title;
      onePointTrip.description = body.description;
      onePointTrip.tripDate = body.tripDate;
      onePointTrip.image = body.image;
      onePointTrip.startPointAddress = body.startPointAddress;
      onePointTrip.maxParticipants = body.maxParticipants;
      await onePointTrip.save();

      return respondSuccess(res, convertLocaleMessage(req.user.language, trans.global.UPDATED_SUCCESSFULLY));

    } else if (category === '2 point') {

      body.startPointAddress = JSON.parse(body.startPointAddress);
      body.endPointAddress = JSON.parse(body.endPointAddress);

      const { error } = validateUpdateTwoPointTrip(body);
      if (error) {
        return next(respondError(422, getMessageFromValidationError(error)));
      }

      const twoPointTrip = await Trip.findById(tripId);
      if (!twoPointTrip) {
        return respondFailure(res, convertLocaleMessage(req.user.language, trans.global.NOT_FOUND));
      }
      twoPointTrip.title = body.title;
      twoPointTrip.description = body.description;
      twoPointTrip.tripDate = body.tripDate;
      twoPointTrip.image = body.image;
      twoPointTrip.startPointAddress = body.startPointAddress;
      twoPointTrip.endPointAddress = body.endPointAddress;
      twoPointTrip.totalTripDistance = body.totalTripDistance;
      twoPointTrip.maxParticipants = body.maxParticipants;

      await twoPointTrip.save();

      return respondSuccess(res, convertLocaleMessage(req.user.language, trans.global.UPDATED_SUCCESSFULLY));

    } else if (category === 'custom') {

      body.startPointAddress = JSON.parse(body.startPointAddress);
      body.endPointAddress = JSON.parse(body.endPointAddress);
      body.stopOvers = JSON.parse(body.stopOvers);

      const { error } = validateUpdatecustomTrip(body);
      if (error) {
        return next(respondError(422, getMessageFromValidationError(error)));
      }

      const customTrip = await Trip.findById(tripId);
      if (!customTrip) {
        return respondFailure(res, convertLocaleMessage(req.user.language, trans.global.NOT_FOUND));
      }
      customTrip.title = body.title;
      customTrip.description = body.description;
      customTrip.tripDate = body.tripDate;
      customTrip.image = body.image;
      customTrip.startPointAddress = body.startPointAddress;
      customTrip.endPointAddress = body.endPointAddress;
      customTrip.stopOvers = body.stopOvers;
      customTrip.totalTripDistance = body.totalTripDistance;
      customTrip.maxParticipants = body.maxParticipants;

      await customTrip.save();

      return respondSuccess(res, convertLocaleMessage(req.user.language, trans.global.UPDATED_SUCCESSFULLY));
    } else {
      return respondFailure(res, convertLocaleMessage(req.user.language, trans.global.NOT_FOUND));
    }
  },

  tripParticipate: async(req, res, next) => {
    const userId = req.user.id;
    const { tripId } = req.params;
    let participate = false;

    if (await validateGuestUserAction(userId)) return respondFailure(res, convertLocaleMessage(req.user.language, trans.userAction.ANONYMOUS));

    const trip = await Trip.findOne({ _id: tripId, tripStatus: trans.tripStatus.ACTIVE });
    if (!trip) {
      return respondFailure(res, convertLocaleMessage(req.user.language, trans.global.NOT_FOUND));
    }

    const isUserParticipated = trip.participants.users.indexOf(userId);
    let participateCount = 0;
    if (isUserParticipated === -1) {
      participateCount = trip.participants.count + 1;
      if (trip.maxParticipants !== 0){
        if (participateCount <= trip.maxParticipants) {

          await Trip.updateOne(
            { _id: tripId },
            {
              $set: { 'participants.count': participateCount },
              $push: { 'participants.users': userId },
            },
          );

          participate = true;

          return respondSuccess(res, null, { participate });
        } else {
          return respondFailure(res, convertLocaleMessage(req.user.language, trans.trip.MAX_PARTICIPANTS_LIMIT_REACHED));
        }
      } else {
        await Trip.updateOne(
          { _id: tripId },
          {
            $set: { 'participants.count': participateCount },
            $push: { 'participants.users': userId },
          },
        );

        participate = true;

        return respondSuccess(res, null, { participate });
      }
    } else {
      participateCount = trip.participants.count - 1;

      await Trip.updateOne(
        { _id: tripId },
        {
          $set: { 'participants.count': participateCount },
          $pull: { 'participants.users': userId },
        },
      );

      return respondSuccess(res, null, { participate });
    }
  },

  deleteTrip: async(req, res, next) => {
    const userId = req.user.id;
    const { tripId } = req.params;

    if (await validateGuestUserAction(userId)) return respondFailure(res, convertLocaleMessage(req.user.language, trans.userAction.ANONYMOUS));

    await Trip.deleteOne({ _id: tripId, user: userId });

    return respondSuccess(res, convertLocaleMessage(req.user.language, trans.global.DELETED_SUCCESSFULLY));
  },

  deletePresetTrip: async(req, res, next) => {
    const { presetTripId } = req.params;

    await PresetTrip.deleteOne({ _id: presetTripId });

    return respondSuccess(res, convertLocaleMessage(req.user.language, trans.global.DELETED_SUCCESSFULLY));
  },
};

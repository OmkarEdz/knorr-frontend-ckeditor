'use strict';
const mongoose = require('mongoose');
const { ObjectId } = mongoose.Types;
const fetch = require('node-fetch');

// models
const User = require('../../models/User');
const PredefinedTripImage = require('../../models/PredefinedTripImage');
const PresetTrip = require('../../models/PresetTrip');
const Trip = require('../../models/Trip');
const Event = require('../../models/Event');
const Post = require('../../models/Post');
const UsersBlocked = require('../../models/UsersBlocked');
const Report = require('../../models/Report');
const PostComment = require('../../models/PostComment');
const UserMatch = require('../../models/UserMatch');
const Notification = require('../../models/Notification');
const Chat = require('../../models/Chat');
const Auto = require('../../models/Auto');
const CarManufacturer = require('../../models/CarManufacturer');
const { LoginTypes } = require('../..//helpers/constants');
const { sendMail } = require('../../helpers/notification');
const { emailDeletedProfile } = require('../../helpers/emailTemplate');

// helpers
const { respondSuccess, respondFailure, respondError } = require('../../helpers/response');
const { sendPushNotification } = require('../../helpers/notification');
const {
  getMessageFromValidationError,
  convertLocaleMessage,
} = require('../../helpers/utils');

const {
  validatePredefinedTripImage,
  validateUpdatePredefinedTripImage,
} = require('../../helpers/inputValidation');

const trans = require('../../helpers/constants');


module.exports = {

  allPredefinedTripImage: async(req, res, next) => {

    const predefinedTripImage = await PredefinedTripImage.find({status: trans.status.ACTIVE }, '_id image');

    return respondSuccess(res, null, predefinedTripImage);
  },

  predefinedTripImageDetail: async(req, res, next) => {
    const { PredefinedTripImageId } = req.params;
    const predefinedTripImage = await PredefinedTripImage.findOne({ _id: PredefinedTripImageId, status: trans.status.ACTIVE });
    if (!predefinedTripImage) {
      return respondFailure(res, convertLocaleMessage(req.user.language, trans.global.NOT_FOUND));
    }
    return respondSuccess(res, null, predefinedTripImage);
  },

  addPredefinedTripImage: async(req, res, next) => {
    const { body } = req;
    const userId = req.user.id;
    const language = req.user.language;

    body.user = userId;
    body.image = res.locals.imageUrl;

    const { error } = validatePredefinedTripImage(body);
    if (error) {
      return next(respondError(422, getMessageFromValidationError(error)));
    }

    const newPredefinedTripImage = new PredefinedTripImage(body);
    await newPredefinedTripImage.save();

    return respondSuccess(res, convertLocaleMessage(language, trans.global.ADDED_SUCCESSFULLY));
  },

  updatePredefinedTripImage: async(req, res, next) => {
    const { body } = req;
    const language = req.user.language;

    if (res.locals.imageUrl !== ''){
      body.image = res.locals.imageUrl;
    }

    const { error } = validateUpdatePredefinedTripImage(body);
    if (error) {
      return next(respondError(422, getMessageFromValidationError(error)));
    }

    const predefinedTripImage = await PredefinedTripImage.findById(body.predefinedTripImageId);
    if (!predefinedTripImage) {
      return respondFailure(res, convertLocaleMessage(language, trans.global.NOT_FOUND));
    }

    predefinedTripImage.image = body.image;
    await predefinedTripImage.save();

    return respondSuccess(res, convertLocaleMessage(req.user.language, trans.global.UPDATED_SUCCESSFULLY));
  },

  deletePredefinedTripImage: async(req, res, next) => {
    const { predefinedTripImageId } = req.params;

    await PredefinedTripImage.deleteOne({ _id: predefinedTripImageId });

    return respondSuccess(res, convertLocaleMessage(req.user.language, trans.global.DELETED_SUCCESSFULLY));
  },

  dashboardHome: async(req, res, next) => {
    const users = await User.countDocuments();
    const predefinedTripImage = await PredefinedTripImage.countDocuments();
    const presetTrip = await PresetTrip.countDocuments();
    const trip = await Trip.countDocuments();
    const event = await Event.countDocuments();
    const post = await Post.countDocuments();
    const coins = await User.findOne({});

    return respondSuccess(res, null, {
      users,
      predefinedTripImage,
      presetTrip,
      trip,
      event,
      post,
      coinValue: coins.coinValue,
    });
  },

  deleteUser: async(req, res, next) => {
    const { body, user } = req;
    const { userId, reason } = body;
    const language = user.language;

    console.log(user._id);
    console.log(userId);

    // eslint-disable-next-line eqeqeq
    const selfDelete = user._id == userId;

    if (user.loginType !== LoginTypes.ADMIN && !selfDelete) {
      return next(respondError(403, 'forbidden'));
    }

    const userFromDb = await User.findOne({ _id: userId, status: trans.userStatus.ACTIVE });
    if (!userFromDb) {
      return respondFailure(res, convertLocaleMessage(language, trans.auth.USER_NOT_FOUND));
    }

    await Trip.deleteOne({ user: userId });
    await Auto.deleteMany({ user: userId });
    await Trip.deleteMany({ user: userId });
    await UserMatch.deleteMany({
      $or: [{ user: userId }, { matchedUser: userId }],
    });
    await Notification.deleteMany({
      $or: [{ fromUser: userId }, { toUser: userId }],
    });
    await UsersBlocked.deleteMany({
      $or: [{ user: userId }, { blockedUser: userId }],
    });
    await Report.deleteMany({
      $or: [{ user: userId }, { reportedUser: userId }],
    });
    await Post.deleteMany({ user: userId });
    await PostComment.deleteMany({ user: userId });
    await Chat.deleteMany({
      $or: [{ senderId: userId }, { receiverId: userId }],
    });

    await User.updateMany({ 'followers.users': { $in: [ObjectId(userId)] } },
      {
        $inc: { 'followers.count': -1 },
      },
    );

    await User.updateMany({ 'followers.users': { $in: [ObjectId(userId)] } },
      {
        $pull: { 'followers.users': userId },
      },
    );

    await User.updateMany({ 'following.users': { $in: [ObjectId(userId)] } },
      {
        $inc: { 'following.count': -1 },
      },
    );

    await User.updateMany({ 'following.users': { $in: [ObjectId(userId)] } },
      {
        $pull: { 'following.users': userId },
      },
    );

    await User.deleteOne({ _id: userId });

    if (selfDelete){
      await sendMail(emailDeletedProfile({
        user: userFromDb,
        reason: reason,
      }));
    }

    return respondSuccess(res, convertLocaleMessage(language, trans.global.DELETED_SUCCESSFULLY));
  },

  synchronizeMakesAndModels: async(req, res, next) => {
    await CarManufacturer.deleteMany({});

    const maxLimit = 10000;
    const limit = 100;

    var skip = 0;
    while (skip < maxLimit){
      const response = await fetch(
        'https://parseapi.back4app.com/classes/Carmodels_Car_Model_List?skip=' + skip + '&limit=' + limit + '&order=Make&keys=Make,Model',
        {
          headers: {
            'X-Parse-Application-Id': 'HG65y6fG1tOLZ72xNMTJcUazBSPOzLhUbH9dRaEY',
            'X-Parse-REST-API-Key': 'qtm52aISS01LhJOAMwvV6UvjF5nynVJ3gW11AJmO',
          },
        },
      );
      const data = await response.json();
      console.log(data.results);

      var elements = [];
      for (var i = 0; i < data.results.length; i++){
        const element = data.results[i];
        if (elements.filter(e => e.make === element.Make && e.model === element.Model).length > 0) {
          continue;
        }

        elements.push({
          make: element.Make,
          model: element.Model,
        });
      }
      CarManufacturer.create(elements, function(err){
        if (err){
          console.log(err);
        }
      });
      skip += limit;
      console.log('Imported ' + limit + ' records to Makes and Models');
    }
    return respondSuccess(res, 'Import von Fahrzeugherstellern und Modellen erfolgreich durchgeführt.');
  },

  sendNotificationToAllUsers: async(req, res, next) => {
    const { body } = req;
    const messages = body.messages;

    if (messages === undefined || messages.length === 0 || messages['en'] === undefined || messages['en'].length === 0) {
      return next(respondError(422, 'Keine gültigen Nachrichten für die Nutzer übergeben. Es muss mindestens der Text in englischer Sprache vorliegen.'));
    }

    // Get Admin User
    const admin = await User.find({userName: 'admin' }, '_id fcmToken userName language');

    // Get available Messages by filled translations
    const messagesKeys = Object.keys(messages);
    var availableLanguages = [];
    for (let i = 0; i < messagesKeys.length; i++){
      if (messages[i] !== undefined && messages[i].trim().length > 0){
        availableLanguages.push(messagesKeys[i]);
      }
    }

    const users = await User.find({_id: { $ne: admin._id }, status: trans.userStatus.ACTIVE }, '_id fcmToken userName');
    // const users = await User.find({_id: '61dfa3d3bfe102491ec364b1', status: trans.userStatus.ACTIVE }, '_id fcmToken userName language');

    for (let i = 0; i < users.length; i++){
      const otherUserDetails = users[i];
      const lang = otherUserDetails.language;
      const message = availableLanguages.includes(lang) ? messages[lang] : messages['en'];
      const details = {
        token: otherUserDetails.fcmToken,
        body: {
          userName: 'Admin',
          type: 'follow',
          fromUser: admin._id,
          toUser: otherUserDetails._id,
          action: null,
          content: message,
        },
      };
      if (otherUserDetails.isNotificationEnabled){
        await sendPushNotification(details);
      }
    }

    return respondSuccess(res, 'Die Nachricht wurde an alle Benutzer gesendet');
  },
};

'use strict';
// models
const Level = require('../../models/Level');

// helpers
const { respondSuccess, respondFailure, respondError } = require('../../helpers/response');
const {
  getMessageFromValidationError,
  convertLocaleMessage,
} = require('../../helpers/utils');
const {
  validateLevel,
  validateUpdateLevel,
} = require('../../helpers/inputValidation');

const trans = require('../../helpers/constants');
const User = require('../../models/User');

module.exports = {

  allLevels: async(req, res, next) => {
    const levels = await Level.find({ status: trans.status.ACTIVE });
    return respondSuccess(res, null, levels);
  },

  levelDetails: async(req, res, next) => {
    const { levelId } = req.params;

    const level = await Level.findOne({ _id: levelId, status: trans.status.ACTIVE });
    if (!level) {
      return respondFailure(res, convertLocaleMessage(req.user.language, trans.global.NOT_FOUND));
    }

    const checkIfLevelIsActive = await User.findOne({ currentLevel: level.level, status: trans.status.ACTIVE });
    if (checkIfLevelIsActive){
      return respondFailure(res, convertLocaleMessage(req.user.language, trans.global.LEVEL_ALREADY_ACTIVE));
    }

    return respondSuccess(res, null, level);
  },

  addLevel: async(req, res, next) => {
    const { body } = req;

    if (res.locals.imageUrl !== '') {
      body.image = res.locals.imageUrl;
    }

    const { error } = validateLevel(body);
    if (error) {
      return next(respondError(422, getMessageFromValidationError(error)));
    }
    body.user = req.user.id;

    const findHighestLevelCoin = await Level.findOne({ status: trans.status.ACTIVE }, 'level coins').sort({ level: -1 });

    if (findHighestLevelCoin && body.coins < findHighestLevelCoin.coins) {
      return respondFailure(res, convertLocaleMessage(req.user.language, trans.global.LEVEL_ALREADY_EXISTS_WITH_THE_COIN));
    }

    const newLevel = new Level(body);
    await newLevel.save();

    return respondSuccess(res, convertLocaleMessage(req.user.language, trans.global.ADDED_SUCCESSFULLY));
  },

  updateLevel: async(req, res, next) => {
    const { body } = req;
    const { levelId } = body;

    delete body.file;

    if (res.locals.imageUrl !== '') {
      body.image = res.locals.imageUrl;
    }
    const { error } = validateUpdateLevel(body);
    if (error) {
      return next(respondError(422, getMessageFromValidationError(error)));
    }

    const level = await Level.findOne({ _id: levelId, status: trans.status.ACTIVE });
    if (!level) {
      return respondFailure(res, convertLocaleMessage(req.user.language, trans.global.NOT_FOUND));
    }
    const previousLevel = level.level - 1;
    const nextLevel = level.level + 1;
    const previousLevelDetail = await Level.findOne({ level: previousLevel, status: trans.status.ACTIVE });
    const nextLevelDetail = await Level.findOne({ level: nextLevel, status: trans.status.ACTIVE });

    // console.log(previousLevelDetail, nextLevelDetail);

    if (((previousLevelDetail && nextLevelDetail) && (body.coins <= previousLevelDetail.coins || body.coins >= nextLevelDetail.coins))
        || (!previousLevelDetail && nextLevelDetail && body.coins >= nextLevelDetail.coins)
        || (previousLevelDetail && !nextLevelDetail && body.coins <= previousLevelDetail.coins)) {
      return respondFailure(res, convertLocaleMessage(req.user.language, trans.global.UPDATE_FALIED));
    }

    delete body.levelId;
    await Level.updateOne({ _id: levelId }, body);

    return respondSuccess(res, convertLocaleMessage(req.user.language, trans.global.UPDATED_SUCCESSFULLY));
  },

  deleteLevel: async(req, res, next) => {
    const { levelId } = req.params;

    const level = await Level.findOne({ _id: levelId, status: trans.status.ACTIVE });
    if (!level) {
      return respondFailure(res, convertLocaleMessage(req.user.language, trans.global.NOT_FOUND));
    }

    if (level.completedUsers.length > 0){
      return respondFailure(res, convertLocaleMessage(req.user.language, trans.global.LEVEL_ALREADY_ACTIVE));
    }

    await Level.deleteOne({ _id: levelId });

    return respondSuccess(res, convertLocaleMessage(req.user.language, trans.global.DELETED_SUCCESSFULLY));
  },
};

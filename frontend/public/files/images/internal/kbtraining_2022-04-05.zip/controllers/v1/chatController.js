'use strict';
// models
const User = require('../../models/User');
const UserMatch = require('../../models/UserMatch');
const Chat = require('../../models/Chat');
const Report = require('../../models/Report');
const UsersBlocked = require('../../models/UsersBlocked');

// helpers
const { respondSuccess, respondFailure, respondError } = require('../../helpers/response');
const {
  getMessageFromValidationError,
  convertLocaleMessage,
  generateChatId,
  getUserDetails,
} = require('../../helpers/utils');
const {
  validateNewMessage,
  validateAllChats,
} = require('../../helpers/inputValidation');
const { sendPushNotification } = require('../../helpers/notification');

const trans = require('../../helpers/constants');


module.exports = {

  newMessage: async(messageData, next) => {
    const { chatId, senderId, receiverId, message } = messageData;

    const { error } = validateNewMessage(messageData);
    if (error) {
      return next(respondError(422, getMessageFromValidationError(error)));
    }

    const senderDetails = await User.findById(senderId);
    if (!senderDetails) {
      console.log('not found');
    }

    const receiverDetails = await User.findById(receiverId);
    if (!receiverDetails) {
      console.log('not found');
    }

    const updateLatestMessage = await UserMatch.findOne({ chatId });
    if (!updateLatestMessage) {
      console.log('not found');
    }
    const newMessage = new Chat();
    newMessage.chatId = chatId;
    newMessage.senderId = senderId;
    newMessage.receiverId = receiverId;
    newMessage.message = message;
    if (!await newMessage.save()) {
      return next(respondError(500));
    }
    const userMatchUpdate = await UserMatch.updateOne({ chatId }, {
      $unset: { deletedBy: 1 },
    });
    if (!userMatchUpdate) {
      console.log(trans.global.UPDATE_FALIED);
    }
    updateLatestMessage.latestMessage = message;
    updateLatestMessage.lastChatOn = new Date();

    const receiverLanguage = await User.findOne({_id: receiverId}).select('language');
    const messageToNotify = message.includes('ETS-IMAGE=') ? convertLocaleMessage(receiverLanguage, trans.chat.SENT_IMAGE) : message.includes('ETS-VIDEO=') ? convertLocaleMessage(receiverLanguage, trans.chat.SENT_VIDEO) : message;

    const NotificationDetails = {
      token: receiverDetails.fcmToken,
      body: {
        userName: senderDetails.userName,
        type: 'chat',
        fromUser: senderId,
        toUser: receiverId,
        action: chatId,
        content: messageToNotify,
      },
    };

    if (String(updateLatestMessage.user) === receiverId && updateLatestMessage.userChatDetail.isInChatScreen === false) {
      updateLatestMessage.userChatDetail.unReadCount += 1;
      if (receiverDetails.isNotificationEnabled) {
        await sendPushNotification(NotificationDetails);
      }
    } else if (String(updateLatestMessage.matchedUser) === receiverId && updateLatestMessage.matchedUserChatDetail.isInChatScreen === false) {
      updateLatestMessage.matchedUserChatDetail.unReadCount += 1;
      if (receiverDetails.isNotificationEnabled) {
        await sendPushNotification(NotificationDetails);
      }
    }

    await updateLatestMessage.save();

    return newMessage;
  },

  newSharedPostMessage: async(messageData) => {
    const { senderId, receiverId, message, post } = messageData;

    const senderDetails = await User.findById(senderId);
    if (!senderDetails) {
      console.log('not found');
    }

    const receiverDetails = await User.findById(receiverId);
    if (!receiverDetails) {
      console.log('not found');
    }
    let updateLatestMessage = null;
    updateLatestMessage = await UserMatch.findOne({
      $or: [
        { user: senderId, matchedUser: receiverId },
        { user: receiverId, matchedUser: senderId },
      ],
    });

    if (!updateLatestMessage && senderId && receiverId) {
      const newMatch = new UserMatch();
      newMatch.user = senderId;
      newMatch.matchedUser = receiverId;
      newMatch.chatId = generateChatId();
      await newMatch.save();

      updateLatestMessage = await UserMatch.findById(newMatch.id);
    }
    const newMessage = new Chat();
    newMessage.chatId = updateLatestMessage && updateLatestMessage.chatId;
    newMessage.senderId = senderId;
    newMessage.receiverId = receiverId;
    newMessage.message = message;
    newMessage.isSharedPost = true;
    newMessage.post = post;
    await newMessage.save();

    const userMatchUpdate = await UserMatch.updateOne({ chatId: updateLatestMessage && updateLatestMessage.chatId }, {
      $unset: { deletedBy: 1 },
    });
    if (!userMatchUpdate) {
      console.log(trans.global.UPDATE_FALIED);
    }
    updateLatestMessage.latestMessage = message;
    updateLatestMessage.lastChatOn = new Date();

    const NotificationDetails = {
      token: receiverDetails.fcmToken,
      body: {
        userName: senderDetails.userName,
        type: 'chat',
        fromUser: senderId,
        toUser: receiverId,
        action: updateLatestMessage && updateLatestMessage.chatId,
        content: message,
      },
    };

    if (String(updateLatestMessage.user) === receiverId && updateLatestMessage.userChatDetail.isInChatScreen === false) {
      updateLatestMessage.userChatDetail.unReadCount += 1;
      if (receiverDetails.isNotificationEnabled) {
        await sendPushNotification(NotificationDetails);
      }
    } else if (String(updateLatestMessage.matchedUser) === receiverId && updateLatestMessage.matchedUserChatDetail.isInChatScreen === false) {
      updateLatestMessage.matchedUserChatDetail.unReadCount += 1;
      if (receiverDetails.isNotificationEnabled) {
        await sendPushNotification(NotificationDetails);
      }
    }

    await updateLatestMessage.save();

    return Chat.findOne({ _id: newMessage.id }).populate('post', 'description galleryImages');
  },

  allChatList: async(req, res, next) => {
    const { body } = req;
    const { userId } = body;

    const chatList = await UserMatch.find({
      $or: [
        { user: userId },
        { matchedUser: userId },
      ],
      deletedBy: { $ne: userId },
      latestMessage: { $ne: '' },
    }).populate('user', '_id image userName onlineStatus')
      .populate('matchedUser', '_id image userName onlineStatus')
      .sort({lastChatOn: -1});

    if (chatList.length === 0) {
      return respondFailure(res, convertLocaleMessage(req.user.language, trans.global.NOT_FOUND));
    }
    const updatedChatList = [];
    const updateChatList = chatList.map((chatData) => {
      if (chatData.user.id === userId) {
        const obj = {
          user: chatData.matchedUser,
          chatId: chatData.chatId,
          latestMessage: chatData.latestMessage,
          unreadCount: chatData.userChatDetail.unReadCount,
          lastMessageAt: chatData.lastChatOn,
        };
        updatedChatList.push(obj);
      } else {
        const obj = {
          user: chatData.user,
          chatId: chatData.chatId,
          latestMessage: chatData.latestMessage,
          unreadCount: chatData.matchedUserChatDetail.unReadCount,
          lastMessageAt: chatData.lastChatOn,
        };
        updatedChatList.push(obj);
      }
      return updatedChatList;
    });

    await Promise.all(updateChatList);

    return respondSuccess(res, null, updatedChatList);
  },

  allChatDetails: async(req, res, next) => {
    const { body } = req;
    const { chatId, otherUserId } = body;
    const { skip, limit } = req.params;
    const userId = req.user.id;
    const following = req.user.following;
    let followed = false;
    let reported = false;
    let blocked = false;
    const isUserfollowed = following.users.indexOf(otherUserId);
    if (isUserfollowed !== -1) {
      followed = true;
    }
    const checkisUserReported = await Report.findOne({reportedUser: otherUserId });
    if (checkisUserReported){
      reported = true;
    }

    const checkisUserBlocked = await UsersBlocked.findOne({ $or: [ {user: otherUserId, blockedUser: userId}, { user: userId, blockedUser: otherUserId }], isBlocked: true });
    if (checkisUserBlocked){
      blocked = true;
    }

    const { error } = validateAllChats(body);
    if (error) {
      return next(respondError(422, getMessageFromValidationError(error)));
    }

    const TotalMessageCount = await Chat.countDocuments({ chatId, deletedBy: { $ne: userId } });

    const allChats = await Chat.find({ chatId, deletedBy: { $ne: userId } }).populate('post', 'description galleryImages')
      .sort({createdAt: -1})
      .skip(Number(skip))
      .limit(Number(limit));
    if (!allChats) {
      return respondFailure(res, convertLocaleMessage(req.user.language, trans.global.NOT_FOUND));
    }

    return respondSuccess(res, null, {
      chats: allChats,
      blockedBy: checkisUserBlocked ? checkisUserBlocked.user : '',
      followed,
      reported,
      blocked,
      TotalMessageCount,
    });
  },

  deleteChat: async(req, res, next) => {
    const { body } = req;
    const { chatId, receiverId } = body;
    const userId = req.user.id;

    const getChatList = await UserMatch.findOne({ chatId });
    if (!getChatList) {
      return respondFailure(res, convertLocaleMessage(req.user.language, trans.global.NOT_FOUND));
    }

    if (String(getChatList.deletedBy) === userId){
      await UserMatch.updateOne({ chatId }, {
        $set: { deletedBy: userId },
      });
    } else if (getChatList.deletedBy !== '') {
      await UserMatch.deleteOne({ chatId });
    } else {
      await UserMatch.updateOne({ chatId }, {
        $set: { deletedBy: userId },
      });
    }

    await Chat.updateMany({ chatId, deletedBy: '' }, {
      $set: { deletedBy: userId },
    });
    await Chat.deleteMany({ chatId, deletedBy: receiverId });


    return respondSuccess(res, convertLocaleMessage(req.user.language, trans.global.DELETED_SUCCESSFULLY));
  },

  deleteMessageFromUser: async(req, res, next) => {
    const { body } = req;
    const { chatId, receiverId, messageIds } = body;
    const userId = req.user.id;

    await Chat.updateMany({ chatId, senderId: userId, deletedBy: '', _id: { $in: messageIds } }, {
      $set: { deletedBy: userId },
    });

    await Chat.deleteMany({ chatId, senderId: userId, deletedBy: receiverId, _id: { $in: messageIds } });

    const getLatestMessage = await Chat.findOne({chatId, $or: [
      { deletedBy: receiverId },
      { deletedBy: '' },
    ]}).sort({createdAt: -1});

    await UserMatch.updateOne({chatId}, {
      $set: {
        latestMessage: getLatestMessage ? getLatestMessage.message : '',
        lastChatOn: getLatestMessage ? getLatestMessage.createdAt : '',
      },
    });


    return respondSuccess(res, convertLocaleMessage(req.user.language, trans.global.DELETED_SUCCESSFULLY));
  },

  deleteMessageFromBothUser: async(req, res, next) => {
    const { body } = req;
    const { chatId, messageIds } = body;
    const userId = req.user.id;

    await Chat.deleteMany({ chatId, senderId: userId, _id: { $in: messageIds } });

    const getLatestMessage = await Chat.findOne({chatId, $or: [
      { deletedBy: { $ne: { userId }}},
      { deletedBy: '' },
    ]}).sort({createdAt: -1});

    await UserMatch.updateOne({chatId}, {
      $set: {
        latestMessage: getLatestMessage ? getLatestMessage.message : '',
        lastChatOn: getLatestMessage ? getLatestMessage.createdAt : '',
      },
    });

    return respondSuccess(res, convertLocaleMessage(req.user.language, trans.global.DELETED_SUCCESSFULLY));
  },

  updateChatScreen: async(req, res, next) => {
    const { body } = req;
    const { chatId } = body;
    const userId = req.user.id;

    const getChatList = await UserMatch.findOne({ chatId });
    if (!getChatList) {
      return respondFailure(res, convertLocaleMessage(req.user.language, trans.global.NOT_FOUND));
    }
    if (String(getChatList.user) === userId) {
      getChatList.userChatDetail.isInChatScreen = false;
      getChatList.userChatDetail.unReadCount = 0;
    } else {
      getChatList.matchedUserChatDetail.isInChatScreen = false;
      getChatList.matchedUserChatDetail.unReadCount = 0;
    }
    if (!await getChatList.save()) {
      return next(respondError(500));
    }
    return respondSuccess(res, convertLocaleMessage(req.user.language, trans.global.UPDATED_SUCCESSFULLY));
  },

  getUploadedImagePath: async(req, res, next) => {
    if (res.locals.imageUrl !== '') {
      return respondSuccess(res, {
        imageUrl: res.locals.imageUrl,
      });
    }
    return respondError(500);
  },
};

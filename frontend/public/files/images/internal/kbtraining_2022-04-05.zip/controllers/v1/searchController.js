'use strict';
const mongoose = require('mongoose');
const { ObjectId } = mongoose.Types;
const _ = require('lodash');
// models
const User = require('../../models/User');
const Trip = require('../../models/Trip');
const Event = require('../../models/Event');
const Auto = require('../../models/Auto');
const Post = require('../../models/Post');

// helpers
const { respondSuccess, respondFailure, respondError } = require('../../helpers/response');
const {
  getMessageFromValidationError,
  convertLocaleMessage,
  getUserCurrentLocation,
  userBlockedBy,
  userReported,
  getTimestamp
} = require('../../helpers/utils');
const {
  validateSearch,
  validateSearchStartAndEndPoint,
  validateSearchStateAndCity,
} = require('../../helpers/inputValidation');

const trans = require('../../helpers/constants');

module.exports = {

  search: async(req, res, next) => {
    const { body } = req;
    const { type, keyword } = body;
    var { skip, limit } = req.params;
    const { id, language} = req.user;
    const { latitude, longitude, minDistance } = getUserCurrentLocation(req);
    const searchKey = new RegExp(keyword, 'ig');

    const currentDate = new Date();

    skip = skip == null ? 0 : skip;
    limit = limit == null ? 1000 : limit;

    console.log('Search ' + keyword + ' with Skip ' + skip + ' and Limit ' + limit);

    const YesterdayDate = new Date(currentDate.setDate(currentDate.getDate() - 1));

    const { error } = validateSearch(body);
    if (error) {
      return next(respondError(422, getMessageFromValidationError(error)));
    }

    const blockedBy = await userBlockedBy(id);

    switch (type) {
      case 'user':
        // Search for Users
        const users = await User.aggregate([
          {
            $geoNear: {
              near: {
                type: 'Point',
                coordinates: [longitude, latitude],
              },
              distanceMultiplier: 0.001,
              distanceField: 'distance',
              minDistance: minDistance,
              spherical: true,
              query: { 'location.type': 'Point' },
            },
          },
          {
            $match: {
              $and: [
                { _id: { $ne: ObjectId(id)} },
                { userName: { $ne: 'anonymous'} },
                { _id: { $nin: blockedBy } },
                // { _id: { $nin: reportedUser } },
              ],
              status: trans.status.ACTIVE,
              userName: {$regex: searchKey },
            },
          },
          {
            $project: {
              _id: 1,
              userName: 1,
              image: 1,
              about: 1,
              email: 1,
              distance: 1,
            },
          },
          { $sort: { distance: 1 } },
        ]).skip(Number(skip))
          .limit(Number(limit));

        return respondSuccess(res, null, users);

      case 'post':
        // Seach for Posts
        const posts = await Post.aggregate([
          {
            $match: {
              status: trans.status.ACTIVE,
              description: searchKey,
            },
          },
          {
            $lookup: {
              from: 'users',
              localField: 'user',
              foreignField: '_id',
              as: 'user',
            },
          },
          {
            $lookup: {
              from: 'postcomments',
              localField: '_id',
              foreignField: 'post',
              as: 'comments',
            },
          },
          { $unwind: '$user' },
          {
            $project: {
              _id: 1,
              description: 1,
              likes: 1,
              address: 1,
              galleryImages: 1,
              'user._id': 1,
              'user.image': 1,
              'user.userName': 1,
              createdAt: 1,
              updatedAt: 1,
              type: 'post',
              commentsCount: { $size: '$comments' },
            },
          },
          { $sort: { createdAt: -1 } },
        ]).skip(Number(skip))
          .limit(Number(limit));

        for (var i = 0; i < posts.length; i++){
          posts[i].like = posts[i].likes.users.some((user) => String(user) === String(id));
          posts[i].time = await getTimestamp(posts[i].createdAt, language);
        }

        return respondSuccess(res, null, posts);
      case 'trip':
        // Search for Trips
        const reportedTrip = await userReported(id, 'trip');

        const trips = await Trip
          .find({ $and: [
            { user: { $nin: blockedBy } },
            { _id: { $nin: reportedTrip } },
          ], tripStatus: trans.tripStatus.ACTIVE, tripDate: { $gt: YesterdayDate }, title: searchKey }, 'title tripDate image totalTripDistance participants maxParticipants')
          .sort({ tripDate: 1, totalTripDistance: 1 })
          .skip(Number(skip))
          .limit(Number(limit));

        if (trips.length > 0){
          const updateTrip = trips.map(trip => {
            const updatedTripDetails = trip.toObject();
            const isUserParticipated = trip.participants.users.indexOf(id);
            if (isUserParticipated === -1) {
              updatedTripDetails.participate = false;
            } else {
              updatedTripDetails.participate = true;
            }
            return updatedTripDetails;
          });
          const updatedTrips = await Promise.all(updateTrip);

          return respondSuccess(res, null, updatedTrips);
        }

        return respondSuccess(res, null, trips);

      case 'event':
        // Search for Events
        const events = await Event
          .find({ user: { $nin: blockedBy }, status: trans.status.ACTIVE, eventDate: { $gte: YesterdayDate }, title: searchKey }, 'title eventDate image participants')
          .sort({ eventDate: 1 })
          .skip(Number(skip))
          .limit(Number(limit));

        if (events.length > 0){
          const updateEvent = events.map(event => {
            const updatedEventDetails = event.toObject();
            const isUserParticipated = event.participants.users.indexOf(id);
            if (isUserParticipated === -1) {
              updatedEventDetails.participate = false;
            } else {
              updatedEventDetails.participate = true;
            }
            return updatedEventDetails;
          });
          const updatedEvents = await Promise.all(updateEvent);

          return respondSuccess(res, null, updatedEvents);
        }

        return respondSuccess(res, null, events);

      case 'auto':
        // Search for Cars, not available in the App atm
        if (keyword === ''){
          return respondSuccess(res, null, []);
        }

        const autos = await Auto.aggregate([
          {
            $match: {
              brand: { $regex: searchKey },
            },
          },
          {
            $project: {
              _id: 0,
              brand: { $trim : { input: "$brand"}},
              model: 1,
              year: 1,
            },
          },
          { $sort: { brand: 1 } },
        ])

        console.log(autos);

        return respondSuccess(res, null, autos);

      default:
        return respondFailure(res, convertLocaleMessage(language, trans.global.NOT_FOUND));
    }
  },

  searchStartAndEndPoint: async(req, res, next) => {
    const { body } = req;
    const { type, keyword } = body;
    const { id, language} = req.user;
    const searchKey = new RegExp(keyword, 'ig');

    const { error } = validateSearchStartAndEndPoint(body);
    if (error) {
      return next(respondError(422, getMessageFromValidationError(error)));
    }

    const blockedBy = await userBlockedBy(id);
    const reportedTrip = await userReported(id, 'trip');

    let trip = [];
    if (keyword === ''){
      return respondSuccess(res, null, trip);
    }

    switch (type) {
      case 'startTrip':

        trip = await Trip
          .find({ $and: [
            { user: { $nin: blockedBy } },
            { _id: { $nin: reportedTrip } },
          ], tripStatus: trans.tripStatus.ACTIVE, 'startPointAddress.place': searchKey }, 'startPointAddress.place')
          .sort({ tripDate: 1, totalTripDistance: 1 });

        return respondSuccess(res, null, trip);

      case 'endTrip':

        trip = await Trip
          .find({ $and: [
            { user: { $nin: blockedBy } },
            { _id: { $nin: reportedTrip } },
          ], tripStatus: trans.tripStatus.ACTIVE, 'endPointAddress.place': searchKey }, 'endPointAddress.place')
          .sort({ tripDate: 1, totalTripDistance: 1 });

        return respondSuccess(res, null, trip);

      default:
        return respondFailure(res, convertLocaleMessage(language, trans.global.NOT_FOUND));
    }
  },

  searchStateAndCity: async(req, res, next) => {
    const { body } = req;
    const { type, keyword, state } = body;
    const { id, language } = req.user;
    const searchKey = new RegExp(keyword, 'ig');

    const { error } = validateSearchStateAndCity(body);
    if (error) {
      return next(respondError(422, getMessageFromValidationError(error)));
    }

    const blockedBy = await userBlockedBy(id);
    const reportedTrip = await userReported(id, 'trip');

    let data = [];
    if (keyword === ''){
      return respondSuccess(res, null, data);
    }

    switch (type) {
      case 'state':

        const getStartPointState = await Trip.aggregate([
          {
            $match: {
              $and: [
                { user: { $nin: blockedBy } },
                { _id: { $nin: reportedTrip } },
              ],
              tripStatus: trans.tripStatus.ACTIVE, 'startPointAddress.state': searchKey,
            },
          },
          {
            $group: {
              _id: '$startPointAddress.state',
            },
          },
        ]);

        const getEndPointState = await Trip.aggregate([
          {
            $match: {
              $and: [
                { user: { $nin: blockedBy } },
                { _id: { $nin: reportedTrip } },
              ],
              tripStatus: trans.tripStatus.ACTIVE, 'endPointAddress.state': searchKey,
            },
          },
          {
            $group: {
              _id: '$endPointAddress.state',
            },
          },
        ]);

        data = getStartPointState.concat(getEndPointState);

        const updateStateData = _.uniqBy(data, '_id');
        const updatedStateData = _.sortBy(updateStateData, '_id');

        return respondSuccess(res, null, updatedStateData);

      case 'city':

        const match1 = {
          $and: [
            { user: { $nin: blockedBy } },
            { _id: { $nin: reportedTrip } },
          ],
          tripStatus: trans.tripStatus.ACTIVE, 'startPointAddress.city': searchKey,
        };

        const match2 = {
          $and: [
            { user: { $nin: blockedBy } },
            { _id: { $nin: reportedTrip } },
          ],
          tripStatus: trans.tripStatus.ACTIVE, 'endPointAddress.city': searchKey,
        };

        if (state !== '') {
          match1['startPointAddress.state'] = state;
          match2['endPointAddress.state'] = state;
        }

        const getStartPointCity = await Trip.aggregate([
          {
            $match: match1,
          },
          {
            $group: {
              _id: '$startPointAddress.city',
            },
          },
        ]);

        const getEndPointCity = await Trip.aggregate([
          {
            $match: match2,
          },
          {
            $group: {
              _id: '$endPointAddress.city',
            },
          },
        ]);

        data = getStartPointCity.concat(getEndPointCity);

        const updateCityData = _.uniqBy(data, '_id');
        const updatedCityData = _.sortBy(updateCityData, '_id');

        return respondSuccess(res, null, updatedCityData);

      default:
        return respondFailure(res, convertLocaleMessage(language, trans.global.NOT_FOUND));
    }
  },
};

'use strict';
const passport = require('passport');
const router = require('express-promise-router')();
const multer = require('multer');
// controllers
const adminController = require('../controllers/v1/adminController');
const authController = require('../controllers/v1/authController');
const userController = require('../controllers/v1/userController');
const tripController = require('../controllers/v1/tripController');
const chatController = require('../controllers/v1/chatController');
const matchController = require('../controllers/v1/matchController');
const postController = require('../controllers/v1/postController');
const autoController = require('../controllers/v1/autoController');
const carManufacturerController = require('../controllers/v1/carManufacturerController');
const userActionController = require('../controllers/v1/userActionController');
const searchController = require('../controllers/v1/searchController');
const eventController = require('../controllers/v1/eventController');
const notificationController = require('../controllers/v1/notificationController');
const rewardController = require('../controllers/v1/rewardController');
const levelController = require('../controllers/v1/levelController');

// middlewares
const { admin } = require('../middlewares/checkRole');
const { uploadMultipleImages, uploadSingleImage, deleteImages } = require('../middlewares/multermultiplefileUpload');

// passport
require('../helpers/passport');

const requireAuth = passport.authenticate('jwt', { session: false });
const requireSignin = passport.authenticate('local', { session: false });

router.get('/', (req, res, next) => {
  res.json({
    message: 'Street API V1',
  });
});

var storage = multer.memoryStorage({
  destination: function(req, file, callback) {
    callback(null, '');
  },
});

var multipleUpload = multer({ storage: storage, limits: {
  fileSize: 50000000, // 50 MB
}}).array('file');
var singleUpload = multer({ storage: storage, limits: {
  fileSize: 20000000, // 20 MB
}}).single('file');

// Approutes
// auth controller
router.post('/signUp', singleUpload, authController.signUp);
router.post('/signUpAnonymous', authController.createAnonymousUser);
router.post('/signIn', requireSignin, authController.signIn);
router.post('/changePasswordRequest', authController.changePasswordRequest);
router.post('/verifyOTP', authController.verifyOTP);
router.post('/passwordChange', authController.passwordChange);
router.get('/signOut', requireAuth, authController.signOut);

// user controller
router.get('/user/profile/my/:skip/:limit', requireAuth, userController.userProfile);
router.get('/user/profile/:userId/:skip/:limit', requireAuth, userController.otherUserProfile);
router.get('/user/all', requireAuth, userController.allUsers);
router.post('/user/nearAndActive', requireAuth, userController.getAllNearOnlineUsers);
router.post('/user/nearAndActive/list/:skip/:limit', requireAuth, userController.getAllNearOnlineUsersList);
router.get('/user/follow/:otherUserId', requireAuth, userController.followUser);
router.put('/user/profile/update', requireAuth, singleUpload, uploadSingleImage, userController.updateProfile);
router.post('/user/find/friendsFromContact', requireAuth, userController.friendsFromContact);
router.post('/user/deviceinfo', requireAuth, userController.sendDeviceInfo);
router.post('/user/verify/phoneNumber', requireAuth, userController.verifyPhoneNumber);
router.get('/user/ramdom/:limit', requireAuth, userController.randomUsers);
router.get('/home/user/profile/my', requireAuth, userController.homeProfileDetails);
router.post('/liveTracking/startAndEnd', requireAuth, userController.userLiveTracking);
router.post('/user/FollowingFollowerList/:skip/:limit', requireAuth, userController.getFollowingFollowerList);

// userAction controller
router.post('/user/block', requireAuth, userActionController.blockUnblockUser);
router.post('/report', requireAuth, userActionController.report);

// trip controller
router.post('/trip/add', requireAuth, singleUpload, uploadSingleImage, tripController.addTrip);
router.get('/trip/all', requireAuth, tripController.allTrips);
router.post('/trip/nearBy-stateWise/all', requireAuth, tripController.allTripList);
router.post('/trip/pagination', requireAuth, tripController.allTripPagination);
router.get('/trip/upcoming/my', requireAuth, tripController.myUpcomingTrips);
router.get('/trip/past/my', requireAuth, tripController.myPastTrips);
router.get('/trip/detail/:tripId', requireAuth, tripController.tripDetails);
router.put('/trip/update', requireAuth, singleUpload, uploadSingleImage, tripController.updateTrip);
router.get('/trip/participate/:tripId', requireAuth, tripController.tripParticipate);
router.get('/trip/presetTrip/all', requireAuth, tripController.allPresetTrips);
router.get('/trip/presetTrip/detail/:presetTripId', requireAuth, tripController.presetTripDetails);
router.delete('/trip/delete/:tripId', requireAuth, tripController.deleteTrip);
router.post('/trip/filter', requireAuth, tripController.tripFilter);

// post Controller
router.post('/post/add', requireAuth, multipleUpload, uploadMultipleImages, postController.addPost);
router.get('/post/all/:skip/:limit', requireAuth, postController.allPost);
router.get('/post/my/:skip/:limit', requireAuth, postController.myPost);
router.get('/post/detail/:postId', requireAuth, postController.postDetails);
router.put('/post/update', requireAuth, multipleUpload, uploadMultipleImages, deleteImages, postController.updatePost);
router.delete('/post/delete/:postId', requireAuth, postController.deletePost);
router.get('/post/like/:postId', requireAuth, postController.likeAPost);
router.post('/post/comment/new', requireAuth, postController.commentOnAPost);
router.put('/post/comment/update', requireAuth, postController.updatePostComment);
router.get('/post/comments/:postId', requireAuth, postController.postComments);
router.delete('/post/comment/delete/:commentId', requireAuth, postController.deletePostComment);
router.get('/post/likedUsers/:postId', requireAuth, postController.likedUsers);

// match controller
router.post('/user/match/new', requireAuth, matchController.createOrGetAMatch);
router.post('/user/match/detail', requireAuth, matchController.matchDetails);

// chat controller
router.post('/chat/list', requireAuth, chatController.allChatList);
router.post('/chat/detail/:skip/:limit', requireAuth, chatController.allChatDetails);
router.post('/chat/delete', requireAuth, chatController.deleteChat);
router.post('/chat/update/status', requireAuth, chatController.updateChatScreen);
router.post('/chat/delete/fromUser', requireAuth, chatController.deleteMessageFromUser);
router.post('/chat/delete/fromBothUser', requireAuth, chatController.deleteMessageFromBothUser);
router.post('/chat/uploadImage', requireAuth, singleUpload, uploadSingleImage, chatController.getUploadedImagePath);

// auto controller
router.post('/auto/add', requireAuth, multipleUpload, uploadMultipleImages, autoController.addAuto);
router.get('/auto/all', requireAuth, autoController.allAutos);
router.get('/auto/my', requireAuth, autoController.myAutos);
router.get('/auto/detail/:autoId', requireAuth, autoController.autoDetails);
router.put('/auto/update', requireAuth, multipleUpload, uploadMultipleImages, deleteImages, autoController.updateAuto);
router.delete('/auto/delete/:autoId', requireAuth, autoController.deleteAuto);

// CarManufacturer Controller
router.get('/make', requireAuth, carManufacturerController.allMakes);
router.get('/make/:make', requireAuth, carManufacturerController.getModelsByMake);
router.post('/make', requireAuth, carManufacturerController.addMakeAndModel);
router.put('/make', requireAuth, carManufacturerController.updateMakeAndModel);
router.delete('/make/:id', requireAuth, carManufacturerController.deleteMakeAndModel);

// search controller
router.post('/search', requireAuth, searchController.search);
router.post('/search/:skip/:limit', requireAuth, searchController.search);
router.post('/trip/search/startEndPoint', requireAuth, searchController.searchStartAndEndPoint);
router.post('/trip/search/StateAndCity', requireAuth, searchController.searchStateAndCity);

// notification controller
router.get('/user/notification/all', requireAuth, notificationController.allMyNotifications);
router.delete('/user/notification/delete', requireAuth, notificationController.deleteNotifications);

// event controller
router.get('/event/all', requireAuth, eventController.allEvents);
router.post('/event/nearBy-stateWise/all', requireAuth, eventController.allEventList);
router.get('/event/upcoming/my', requireAuth, eventController.myUpcomingEvents);
router.get('/event/past/my', requireAuth, eventController.myPastEvents);
router.get('/event/detail/:eventId', requireAuth, eventController.eventDetails);
router.get('/event/participate/:eventId', requireAuth, eventController.eventParticipate);

// rewards controller
router.get('/reward/all', requireAuth, rewardController.allRewards);
router.post('/reward/filter', requireAuth, rewardController.rewardFilter);
router.get('/reward/detail/:rewardId', requireAuth, rewardController.rewardDetails);
router.post('/reward/redeem', requireAuth, rewardController.redeemReward);


// Admin routes
// auth controller
router.post('/signInDashboard', requireSignin, authController.signInDashboard);

// trip controller
router.post('/trip/presetTrip/add', requireAuth, admin, singleUpload, uploadSingleImage, tripController.addPresetTrip);
router.put('/trip/presetTrip/update', requireAuth, admin, singleUpload, uploadSingleImage, tripController.updatePresetTrip);
router.delete('/trip/presetTrip/delete/:presetTripId', requireAuth, admin, tripController.deletePresetTrip);

// event controller
router.post('/event/add', requireAuth, admin, singleUpload, uploadSingleImage, eventController.addEvent);
router.put('/event/update', requireAuth, admin, singleUpload, uploadSingleImage, eventController.updateEvent);
router.delete('/event/delete/:eventId', requireAuth, admin, eventController.deleteEvent);

// admin controller
router.get('/trip/predefinedImages/all', requireAuth, adminController.allPredefinedTripImage);
router.get('/trip/predefinedImages/detail/:PredefinedTripImageId', requireAuth, admin, adminController.predefinedTripImageDetail);
router.post('/trip/predefinedImages/add', requireAuth, admin, singleUpload, uploadSingleImage, adminController.addPredefinedTripImage);
router.put('/trip/predefinedImages/update', requireAuth, admin, singleUpload, uploadSingleImage, adminController.updatePredefinedTripImage);
router.delete('/trip/predefinedImages/delete/:predefinedTripImageId', requireAuth, admin, adminController.deletePredefinedTripImage);
router.get('/home/dashboard', requireAuth, admin, adminController.dashboardHome);
router.post('/coinPerKm/value', requireAuth, admin, userController.updateCoinPerKmValue);
router.post('/user/delete', requireAuth, adminController.deleteUser);
router.put('/report/checked', requireAuth, userActionController.reportChecked);
router.post('/make/sync', requireAuth, admin, adminController.synchronizeMakesAndModels);
// router.post('/make/sync', adminController.synchronizeMakesAndModels);
router.post('/user/notifyAll', requireAuth, admin, adminController.sendNotificationToAllUsers);
// router.post('/user/notifyAll', adminController.sendNotificationToAllUsers);


// userAction controller
router.post('/report/detail', requireAuth, userActionController.reportDetails);
router.post('/report/takeAction', requireAuth, userActionController.reportUserAction);

// rewards controller
router.post('/reward/add', requireAuth, admin, singleUpload, uploadSingleImage, rewardController.addReward);
router.put('/reward/update', requireAuth, admin, singleUpload, uploadSingleImage, rewardController.updateReward);
router.delete('/reward/delete/:rewardId', requireAuth, admin, rewardController.deleteReward);
router.post('/reward/history/all', requireAuth, admin, rewardController.rewardHistory);
router.post('/reward/history/status/update', requireAuth, admin, rewardController.updateRewardSentStatus);

// level controller
router.post('/level/add', requireAuth, admin, singleUpload, uploadSingleImage, levelController.addLevel);
router.get('/level/all', requireAuth, admin, levelController.allLevels);
router.get('/level/detail/:levelId', requireAuth, admin, levelController.levelDetails);
router.put('/level/update', requireAuth, admin, singleUpload, uploadSingleImage, levelController.updateLevel);
router.delete('/level/delete/:levelId', requireAuth, admin, levelController.deleteLevel);


module.exports = router;

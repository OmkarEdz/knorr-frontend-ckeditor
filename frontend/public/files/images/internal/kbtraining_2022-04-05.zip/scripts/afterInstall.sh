#!/bin/bash
cd /home/ubuntu/street-node
yarn install
# Copy source files to DEVELOPMENT environment
if [ "$DEPLOYMENT_GROUP_NAME" == "street-staging-group" ]; then
pm2 start ../node_services/staging.json
fi
# Copy source files to PRODUCTION environment
if [ "$DEPLOYMENT_GROUP_NAME" == "street-production-group" ]; then
pm2 start ../node_services/production.json
fi

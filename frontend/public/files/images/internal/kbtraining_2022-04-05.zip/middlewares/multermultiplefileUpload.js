'use strict';
// npm modules
const AWS = require('aws-sdk');
var imagesize = require('imagesize');
var http = require('https');

const s3bucket = new AWS.S3({
  signatureVersion: 'v4',
  accessKeyId: process.env.AWS_ACCESS_KEY_ID,
  secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  region: 'eu-central-1',
});

function getSize(data, ResponseData) {
  return new Promise((resolve, reject) => {
    var request = http.get(`${data.Location}`, async function(response) {
      imagesize(response, async function(_err, result) {
        ResponseData.push(data);
        resolve(result);
        request.abort();
      });
    });
  });
}

const uploadMultipleImages = (req, res, next) => {

  const file = req.files;
  const userId = req.user.id;

  console.log('file data: ', req.files);
  console.log('body data: ', req.body);
  const galleryImages = [];

  if (req.files !== undefined) {
    if (req.files.length > 0) {
      s3bucket.createBucket(function() {
        const ResponseData = [];
        file.map((item) => {
          const keyName = `${userId}/gallery_${Date.now()}.jpg`;
          const params = {
            Bucket: process.env.AWS_BUCKET,
            Key: 'street/' + keyName,
            Body: item.buffer,
            ACL: 'public-read',
          };
          s3bucket.upload(params, async function(err, data) {
            if (err) {
              console.log('Error Uploading a file', err);
            } else {
              const imageSize = await getSize(data, ResponseData);
              galleryImages.push({
                url: keyName,
                width: imageSize.width,
                height: imageSize.height,
              });
              if (ResponseData.length === file.length) {
                res.locals.galleryImages = galleryImages;
                return next();
              }
            }
          });
        });
      });
    } else {
      res.locals.galleryImages = galleryImages;
      return next();
    }
  } else {
    res.locals.galleryImages = galleryImages;
    return next();
  }
  return false;
};

const uploadSingleImage = (req, res, next) => {

  const file = req.file;
  const userId = req.user.id;
  console.log(file);
  var imageUrl = '';
  console.log('file data: ', req.file);
  console.log('body data: ', req.body);
  if (req.file !== undefined) {
    const type = file.mimetype.includes('jpeg') ? 'jpg' : file.mimetype.substring(file.mimetype.indexOf('/') + 1);
    s3bucket.createBucket(function() {
      const keyName = `${userId}/gallery_${Date.now()}.${type}`;
      const params = {
        Bucket: process.env.AWS_BUCKET,
        Key: 'street/' + keyName,
        Body: file.buffer,
        ACL: 'public-read',
        ContentType: file.mimetype,
      };
      s3bucket.upload(params, function(err, data) {
        if (err) {
          console.log('Error Uploading a file', err);
        } else {
          imageUrl = keyName;

          res.locals.imageUrl = imageUrl;
          return next();
        }
      });
    });
  } else {
    res.locals.imageUrl = imageUrl;
    return next();
  }
  return false;
};

const deleteImages = (req, res, next) => {

  const { body } = req;

  body.deletedImages = JSON.parse(body.deletedImages);

  if (body.deletedImages.length > 0) {

    body.deletedImages.map((item) => {
      const params = {
        Bucket: process.env.AWS_BUCKET,
        Key: 'street/' + item.url,
      };

      s3bucket.deleteObject(params, (s3Error, data) => {
        if (s3Error) {
          return new Error(s3Error);
        }
        return null;
      });
    });
    return next();
  } else {
    return next();
  }
};

module.exports = {
  uploadMultipleImages, uploadSingleImage, deleteImages,
};

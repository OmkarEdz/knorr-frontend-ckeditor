'use strict';
const { respondError } = require('../helpers/response');
const generalLogger = require('../config/winston');

module.exports = {
  requireApiKey: (req, res, next) => {
    const apiKey = req.header('x-api-key');
    generalLogger.log('info', JSON.stringify(req.headers));
    generalLogger.log('info', JSON.stringify(req.body));
    req.language = req.header('language') ? String(req.header('language')).toLowerCase() : 'de';
    if (!apiKey) {
      return next(respondError(400, 'x-api-key is required in header'));
    }

    if (apiKey !== process.env.API_KEY) {
      return next(respondError(400, 'invalid api-key'));
    }

    return next();
  },
};

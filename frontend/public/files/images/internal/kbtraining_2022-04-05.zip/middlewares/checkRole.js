'use strict';
const { respondError } = require('../helpers/response');

const { LoginTypes } = require('../helpers/constants');

module.exports = {
  admin: (req, res, next) => {
    const { user } = req;

    if (user.loginType !== LoginTypes.ADMIN) {
      return next(respondError(403, 'forbidden'));
    }

    return next();
  },
};
